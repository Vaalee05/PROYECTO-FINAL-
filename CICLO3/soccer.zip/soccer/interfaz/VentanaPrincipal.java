package interfaz;

import javax.swing.*;
import java.awt.*;

/**
 * Representa la ventana principal del videojuego DOPOSoccer.
 * Permite acceder a las opciones iniciales del juego.
 */
public class VentanaPrincipal extends JFrame
{
    private JLabel titulo;
    private JButton botonIniciar;
    private JButton botonSalir;

    /**
     * Construye la ventana principal del videojuego.
     */
    public VentanaPrincipal()
    {
        setTitle("DOPOSoccer");
        setSize(800, 500);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);
    
        JPanel panelPrincipal = new JPanel();
        panelPrincipal.setLayout(new BorderLayout());
        panelPrincipal.setBackground(new Color(30, 80, 120));
    
        titulo = new JLabel("DOPOSOCCER", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 42));
        titulo.setForeground(Color.WHITE);
    
        JPanel panelBotones = new JPanel();
        panelBotones.setBackground(new Color(30, 80, 120));
    
        botonIniciar = new JButton("Iniciar partida");
        botonSalir = new JButton("Salir");
    
        botonIniciar.setFont(new Font("Arial", Font.BOLD, 18));
        botonSalir.setFont(new Font("Arial", Font.BOLD, 18));
    
        panelBotones.add(botonIniciar);
        panelBotones.add(botonSalir);
    
        panelPrincipal.add(titulo, BorderLayout.CENTER);
        panelPrincipal.add(panelBotones, BorderLayout.SOUTH);
    
        add(panelPrincipal);
    
        botonIniciar.addActionListener(e -> {
            SeleccionPersonajes ventana = new SeleccionPersonajes();
            ventana.setVisible(true);
            dispose();
        });
    
        botonSalir.addActionListener(e -> dispose());
    
        setVisible(true);
    }
}
