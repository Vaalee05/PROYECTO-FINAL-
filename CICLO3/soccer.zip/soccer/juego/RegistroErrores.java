package juego;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Registra errores de ejecucion en el directorio de datos del juego.
 *
 * Diccionario de atributos:
 * REGISTRO: escritor central para el archivo de errores.
 * configurado: evita crear multiples manejadores para el mismo archivo.
 */
public final class RegistroErrores
{
    private static final Logger REGISTRO = Logger.getLogger("doposoccer");
    private static boolean configurado;

    private RegistroErrores()
    {
    }

    public static synchronized void registrar(String mensaje,
                                               Throwable error)
    {
        if (!configurado) {
            try {
                File carpeta = new File("datos/logs");
                if (!carpeta.exists() && !carpeta.mkdirs()) {
                    throw new IOException(
                        "No se pudo crear " + carpeta.getAbsolutePath()
                    );
                }
                FileHandler archivo = new FileHandler(
                    new File(carpeta, "doposoccer.log").getPath(),
                    true
                );
                archivo.setFormatter(new SimpleFormatter());
                REGISTRO.addHandler(archivo);
                REGISTRO.setUseParentHandlers(false);
                configurado = true;
            }
            catch (IOException problemaRegistro) {
                REGISTRO.log(Level.SEVERE,
                    "No se pudo crear el archivo de errores.",
                    problemaRegistro);
            }
        }

        if (error == null) {
            REGISTRO.severe(mensaje);
        }
        else {
            REGISTRO.log(Level.SEVERE, mensaje, error);
        }
    }
}
