package juego;




/**
 * Representa el balon utilizado durante los partidos
 * del videojuego DOPOSoccer.
 *
 * Administra su posicion, velocidad, movimiento y rebotes.
 *
 * Diccionario de atributos:
 * x: posicion horizontal del balon.
 * y: posicion vertical del balon.
 * vx: velocidad horizontal del balon.
 * vy: velocidad vertical del balon.
 * radio: radio del balon.
 * rebote: proporcion de velocidad conservada en cada choque.
 * RADIO_JUGADOR: radio de colision pasiva que cubre el sprite del jugador.
 * GRAVEDAD: aceleracion vertical aplicada al balon.
 * REBOTE: factor de conservacion de velocidad al rebotar.
 */
public class Balon implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;
    private static final int GRAVEDAD = 1;
    private static final int RADIO_JUGADOR = 32;
    private static final double REBOTE_NORMAL = 0.85;

    private int x;
    private int y;
    private int vx;
    private int vy;
    private int radio;
    private double rebote;

    /**
     * Construye un balon en una posicion determinada.
     *
     * @param x posicion horizontal inicial.
     * @param y posicion vertical inicial.
     * @param radio radio del balon.
     * @throws IllegalArgumentException si el radio no es valido.
     */
    public Balon(int x, int y, int radio)
    {
        if (radio <= 0) {
            throw new IllegalArgumentException(
                "El radio debe ser mayor que cero."
            );
        }

        this.x = x;
        this.y = y;
        this.radio = radio;
        vx = 0;
        vy = 0;
        rebote = REBOTE_NORMAL;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }

    public int getVx()
    {
        return vx;
    }

    public int getVy()
    {
        return vy;
    }

    public int getRadio()
    {
        return radio;
    }

    /**
     * Establece la velocidad horizontal y vertical.
     *
     * @param vx nueva velocidad horizontal.
     * @param vy nueva velocidad vertical.
     */
    public void setVelocidad(int vx, int vy)
    {
        this.vx = vx;
        this.vy = vy;
    }

    /**
     * Ajusta la fuerza de rebote del balon.
     *
     * @param factor conservacion de velocidad entre 0 y 1.2.
     */
    public void setRebote(double factor)
    {
        if (factor < 0 || factor > 1.2) {
            throw new IllegalArgumentException(
                "El rebote debe estar entre 0 y 1.2."
            );
        }
        rebote = factor;
    }

    /**
     * Actualiza la posicion usando las velocidades actuales.
     */
    public void actualizar()
    {
        x += vx;
        y += vy;
    }

    /**
     * Actualiza el movimiento del balon dentro de la cancha.
     *
     * Aplica gravedad y rebotes en el techo, suelo y laterales.
     * Permite que el balon atraviese los laterales cuando
     * se encuentra en la zona vertical de una porteria.
     *
     * @param cancha cancha donde se mueve el balon.
     * @throws IllegalArgumentException si la cancha es nula.
     */
    public void actualizar(Cancha cancha)
    {
        if (cancha == null) {
            throw new IllegalArgumentException(
                "La cancha no puede ser nula."
            );
        }

        int posicionVerticalAnterior = y;

        // Aplicar gravedad.
        vy += GRAVEDAD;

        // Actualizar posicion.
        x += vx;
        y += vy;

        rebotarContraTravesano(posicionVerticalAnterior, cancha);

        // Rebote contra el techo.
        if (y - radio < 0) {
            y = radio;
            vy = (int) (Math.abs(vy) * rebote);
        }

        // Rebote contra el suelo.
        if (y + radio > cancha.getSueloY()) {
            y = cancha.getSueloY() - radio;
            vy = -(int) (Math.abs(vy) * rebote);

            if (Math.abs(vy) < 1) {
                vy = 0;
            }
        }

        // Comprobar si el balon esta en la zona de porteria.
        boolean enPorteria = cancha.estaEnZonaPorteria(y);

        // Rebote contra el lateral izquierdo.
        if (x - radio < 0 && !enPorteria) {
            x = radio;
            vx = Math.abs(vx);
        }

        // Rebote contra el lateral derecho.
        if (x + radio > cancha.getAncho() && !enPorteria) {
            x = cancha.getAncho() - radio;
            vx = -Math.abs(vx);
        }
    }

    /**
     * Resuelve el choque con el travesano superior de cada porteria.
     *
     * @param yAnterior posicion vertical antes del avance.
     * @param cancha cancha que define la ubicacion de los arcos.
     */
    private void rebotarContraTravesano(int yAnterior, Cancha cancha)
    {
        int bordeIzquierdo = cancha.getAnchoPorteria();
        int bordeDerecho = cancha.getAncho() - cancha.getAnchoPorteria();
        boolean sobreArcoIzquierdo = x + radio >= 0
            && x - radio <= bordeIzquierdo;
        boolean sobreArcoDerecho = x + radio >= bordeDerecho
            && x - radio <= cancha.getAncho();

        if (!sobreArcoIzquierdo && !sobreArcoDerecho) {
            return;
        }

        int parteSuperior = cancha.getPosicionPorteriaY();
        if (vy > 0 && yAnterior + radio < parteSuperior
            && y + radio >= parteSuperior) {
            y = parteSuperior - radio;
            vy = -(int) Math.max(1, Math.round(Math.abs(vy) * rebote));
        }
        else if (vy < 0 && yAnterior - radio > parteSuperior
            && y - radio <= parteSuperior) {
            y = parteSuperior + radio;
            vy = (int) Math.max(1, Math.round(Math.abs(vy) * rebote));
        }
    }

    /**
     * Resuelve el choque entre el balon y el cuerpo de un jugador.
     *
     * Separa los objetos para que no se atraviesen y refleja
     * la velocidad del balon segun el angulo del impacto.
     *
     * @param jugador jugador que toca el balon.
     * @param cancha cancha donde ocurre el choque.
     * @return true si el balon y el jugador chocaron.
     * @throws IllegalArgumentException si algun dato es nulo.
     */
    public boolean colisionarConJugador(Jugador jugador, Cancha cancha)
    {
        if (jugador == null || cancha == null) {
            throw new IllegalArgumentException(
                "El jugador y la cancha son obligatorios."
            );
        }

        double diferenciaX = x - jugador.getX();
        // El hitbox pasivo acompana la altura completa del sprite.
        double diferenciaY = y - (jugador.getY() - 36);
        double distancia = Math.sqrt(
            diferenciaX * diferenciaX + diferenciaY * diferenciaY
        );
        double distanciaMinima = radio + RADIO_JUGADOR;

        if (distancia >= distanciaMinima) {
            return false;
        }

        if (distancia == 0) {
            diferenciaX = 1;
            diferenciaY = 0;
            distancia = 1;
        }

        double normalX = diferenciaX / distancia;
        double normalY = diferenciaY / distancia;
        double penetracion = distanciaMinima - distancia;

        x += (int) Math.round(normalX * penetracion);
        y += (int) Math.round(normalY * penetracion);

        double velocidadNormal = vx * normalX + vy * normalY;

        if (velocidadNormal < 0) {
            double impulso = (1 + rebote) * velocidadNormal;
            vx = (int) Math.round(vx - impulso * normalX);
            vy = (int) Math.round(vy - impulso * normalY);
        }
        else if (vx == 0 && vy == 0) {
            vx = (int) Math.round(normalX * 5);
            vy = (int) Math.round(normalY * 5);

            if (vx == 0 && vy == 0) {
                vx = 5;
            }
        }

        ajustarLimites(cancha);
        return true;
    }

    /**
     * Mantiene el balon dentro de los limites que no son porteria.
     *
     * @param cancha cancha que contiene el balon.
     */
    private void ajustarLimites(Cancha cancha)
    {
        if (y - radio < 0) {
            y = radio;
            vy = Math.abs(vy);
        }

        if (y + radio > cancha.getSueloY()) {
            y = cancha.getSueloY() - radio;

            if (vy > 0) {
                vy = -(int) (vy * rebote);
            }
        }

        boolean enPorteria = cancha.estaEnZonaPorteria(y);

        if (x - radio < 0 && !enPorteria) {
            x = radio;
            vx = Math.abs(vx);
        }

        if (x + radio > cancha.getAncho() && !enPorteria) {
            x = cancha.getAncho() - radio;
            vx = -Math.abs(vx);
        }
    }

    /**
     * Reinicia el balon en una posicion determinada
     * y detiene su movimiento.
     *
     * @param x nueva posicion horizontal.
     * @param y nueva posicion vertical.
     */
    public void reiniciar(int x, int y)
    {
        this.x = x;
        this.y = y;
        vx = 0;
        vy = 0;
        rebote = REBOTE_NORMAL;
    }

    /**
     * Detiene completamente el movimiento del balon.
     */
    public void detener()
    {
        vx = 0;
        vy = 0;
    }
}
