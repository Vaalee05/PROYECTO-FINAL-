package juego;





/**
 * Representa y coordina el desarrollo de un partido
 * del videojuego DOPOSoccer.
 *
 * Administra los jugadores, el balon, la cancha,
 * el marcador y el estado de la partida.
 *
 * Diccionario de atributos:
 * jugador1: primer jugador del partido.
 * jugador2: segundo jugador del partido.
 * balon: balon utilizado durante el partido.
 * cancha: terreno donde se desarrolla el partido.
 * marcador: resultado actual del partido.
 * partidoActivo: indica si el partido esta activo.
 * golesParaGanar: cantidad de goles necesarios para ganar.
 * cargaPoderJugador1: fraccion de carga del poder azul.
 * cargaPoderJugador2: fraccion de carga del poder rojo.
 * auraJugador1: indica si el jugador 1 tiene poder listo.
 * auraJugador2: indica si el jugador 2 tiene poder listo.
 * propietarioDisparoPoder: jugador que ejecuta el tiro especial.
 * balonesFantasma: copias temporales del poder Ilusion.
 * perfilMaquina: estrategia seleccionada para el rival automatico.
 * recompensasEntregadas: evita entregar puntos mas de una vez.
 */
public class Juego implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;
    private static final double SEGUNDOS_CARGA_PODER = 10.0;
    private Jugador jugador1;
    private Jugador jugador2;
    private Balon balon;
    private Cancha cancha;
    private Marcador marcador;
    private boolean partidoActivo;
    private int golesParaGanar;
    private Patada patada;
    private Poder poderJugador1;
    private Poder poderJugador2;
    private AdministradorEfectos efectosJugador1;
    private AdministradorEfectos efectosJugador2;
    private Proyectil proyectilJugador1;
    private Proyectil proyectilJugador2;  
    private ConfiguracionPartido configuracion;
    private double tiempoTranscurrido;
    private boolean muerteSubita;
    private double cargaPoderJugador1;
    private double cargaPoderJugador2;
    private boolean auraJugador1;
    private boolean auraJugador2;
    private int propietarioDisparoPoder;
    private java.util.ArrayList<BalonFantasma> balonesFantasma;
    private PerfilMaquina perfilMaquina;
    private double tiempoDecisionMaquina;
    private int ciclosMaquina;
    private boolean recompensasEntregadas;
    private boolean progresoGuardado;
    private boolean finalizadoManual;


    /**
     * Construye un partido con dos jugadores y una cancha.
     *
     * @param jugador1 primer jugador.
     * @param jugador2 segundo jugador.
     * @param cancha terreno de juego.
     * @throws IllegalArgumentException si algun dato es invalido.
     */
    public Juego(Jugador jugador1, Jugador jugador2, Cancha cancha)
    {
        if (jugador1 == null || jugador2 == null || cancha == null
            || jugador1 == jugador2) {
            throw new IllegalArgumentException(
                "Los jugadores y la cancha deben ser validos."
            );
        }
    
        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.cancha = cancha;
        jugador1.setDireccionMirada(1);
        jugador2.setDireccionMirada(-1);
    
        // Posiciones iniciales de los jugadores.
        jugador1.establecerPosicion(
            cancha.getAncho() / 2 - 180,
            cancha.getSueloY() - 10
        );
        
        jugador2.establecerPosicion(
            cancha.getAncho() / 2 + 180,
            cancha.getSueloY() - 10
        );
        
        // Balón en el centro del campo.
        balon = new Balon(
            cancha.getAncho() / 2,
            cancha.getSueloY() / 2,
            15
        );
            
        marcador = new Marcador();
        partidoActivo = false;
        golesParaGanar = 5;
        patada = new Patada();
    
        // Obtener los poderes de los personajes seleccionados.
        poderJugador1 = jugador1.getPersonaje().getPoder();
        poderJugador2 = jugador2.getPersonaje().getPoder();
    
        // Crear un administrador de efectos para cada jugador.
        efectosJugador1 = new AdministradorEfectos(jugador1);
        efectosJugador2 = new AdministradorEfectos(jugador2);
    
        proyectilJugador1 = null;
        proyectilJugador2 = null;
    
        configuracion = null;
        tiempoTranscurrido = 0;
        muerteSubita = false;
        cargaPoderJugador1 = 0;
        cargaPoderJugador2 = 0;
        auraJugador1 = false;
        auraJugador2 = false;
        propietarioDisparoPoder = 0;
        balonesFantasma = new java.util.ArrayList<>();
        perfilMaquina = PerfilMaquina.OFENSIVA;
        tiempoDecisionMaquina = 0;
        ciclosMaquina = 0;
        recompensasEntregadas = false;
        progresoGuardado = false;
        finalizadoManual = false;
    }

    public Jugador getJugador1()
    {
        return jugador1;
    }

    public Jugador getJugador2()
    {
        return jugador2;
    }

    public Balon getBalon()
    {
        return balon;
    }

    public Cancha getCancha()
    {
        return cancha;
    }

    public Marcador getMarcador()
    {
        return marcador;
    }

    public boolean isPartidoActivo()
    {
        return partidoActivo;
    }

    public int getGolesParaGanar()
    {
        return golesParaGanar;
    }

    /**
     * Configura la cantidad de goles necesarios para ganar.
     *
     * @param cantidad cantidad de goles.
     */
    public void setGolesParaGanar(int cantidad)
    {
        if (cantidad <= 0) {
            throw new IllegalArgumentException(
                "La cantidad de goles debe ser positiva."
            );
        }

        if (partidoActivo) {
            throw new IllegalStateException(
                "No se puede cambiar durante un partido."
            );
        }

        golesParaGanar = cantidad;
    }

    /**
     * Inicia el partido y reinicia el control del tiempo.
     */
    public void iniciarPartido()
    {
        if (partidoActivo) {
            return;
        }
    
        if (configuracion != null) {
            tiempoTranscurrido = 0;
            muerteSubita = false;
        }
    
        if (!haTerminado()) {
            partidoActivo = true;
        }
    }

    /**
     * Finaliza el partido.
     */
    public void finalizarPartido()
    {
        if (!partidoActivo) {
            return;
        }
        partidoActivo = false;
        finalizadoManual = true;
        balon.detener();
        entregarRecompensas();
    }

    /** Finaliza por resultado y entrega los puntos una sola vez. */
    private void finalizarPorResultado()
    {
        partidoActivo = false;
        finalizadoManual = false;
        balon.detener();
        entregarRecompensas();
    }

    private void entregarRecompensas()
    {
        if (recompensasEntregadas) {
            return;
        }
        Jugador ganador = getGanador();
        if (ganador == null) {
            return;
        }
        Jugador perdedor = ganador == jugador1 ? jugador2 : jugador1;
        ganador.agregarPuntos(100);
        perdedor.agregarPuntos(25);
        recompensasEntregadas = true;
    }

    public boolean isRecompensaEntregada()
    {
        return recompensasEntregadas;
    }

    public boolean isProgresoGuardado()
    {
        return progresoGuardado;
    }

    public void marcarProgresoGuardado()
    {
        progresoGuardado = true;
    }

    /**
     * Actualiza el estado general del partido.
     */
    public void actualizar()
    {
        actualizar(0.016);
    }

    /**
     * Actualiza la partida usando el tiempo real transcurrido.
     *
     * @param segundos tiempo desde la actualizacion anterior.
     * @throws IllegalArgumentException si el tiempo es negativo.
     */
    public void actualizar(double segundos)
    {
        if (segundos < 0) {
            throw new IllegalArgumentException(
                "El tiempo no puede ser negativo."
            );
        }

        if (!partidoActivo) {
            return;
        }

        actualizarMaquina(segundos);
        actualizarCargasPoder(segundos);
    
        balon.actualizar(cancha);
    
        jugador1.actualizarSalto(cancha.getSueloY());
        jugador2.actualizarSalto(cancha.getSueloY());
        jugador1.actualizarAturdimiento(segundos);
        jugador2.actualizarAturdimiento(segundos);

        if (propietarioDisparoPoder == 0) {
            boolean tocaJugador1 = balon.colisionarConJugador(
                jugador1, cancha
            );
            if (tocaJugador1 && auraJugador1) {
                activarDisparoPoder(1, jugador1.getDireccionMirada());
            }
            boolean tocaJugador2 = balon.colisionarConJugador(
                jugador2, cancha
            );
            if (tocaJugador2 && auraJugador2) {
                activarDisparoPoder(2, jugador2.getDireccionMirada());
            }
        }
        else if (propietarioDisparoPoder == 1) {
            boolean golpeaJugador2 = balon.colisionarConJugador(
                jugador2, cancha
            );
            if (golpeaJugador2 && propietarioDisparoPoder == 1) {
                impactarPoderJugador1();
            }
        }
        else {
            boolean golpeaJugador1 = balon.colisionarConJugador(
                jugador1, cancha
            );
            if (golpeaJugador1) {
                impactarPoderJugador2();
            }
        }

        actualizarBalonesFantasma(segundos);
    
        actualizarProyectiles();
    
        actualizarEfectos(segundos);
        if (jugador1.estaVivo() && jugador1.isEmpujado()
            && jugador1.getDireccionEmpuje() != 0) {
            jugador1.aplicarEmpuje(jugador1.getDireccionEmpuje());
            ajustarPosicion(jugador1);
        }
        if (jugador2.estaVivo() && jugador2.isEmpujado()
            && jugador2.getDireccionEmpuje() != 0) {
            jugador2.aplicarEmpuje(jugador2.getDireccionEmpuje());
            ajustarPosicion(jugador2);
        }
    
        detectarGol();
        actualizarTiempo(segundos);
    }

    /**
     * Reinicia el marcador, los jugadores, el balon y los efectos.
     */
    public void reiniciarPartido()
    {
        marcador.reiniciar();

        efectosJugador1.finalizar();
        efectosJugador2.finalizar();

        jugador1.reiniciarPartido(
            cancha.getAncho() / 2 - 180,
            cancha.getSueloY() - 10
        );
        jugador2.reiniciarPartido(
            cancha.getAncho() / 2 + 180,
            cancha.getSueloY() - 10
        );
        jugador1.setDireccionMirada(1);
        jugador2.setDireccionMirada(-1);

        balon.reiniciar(
            cancha.getAncho() / 2,
            cancha.getSueloY() / 2
        );

        proyectilJugador1 = null;
        proyectilJugador2 = null;
        tiempoTranscurrido = 0;
        muerteSubita = false;
        cargaPoderJugador1 = 0;
        cargaPoderJugador2 = 0;
        auraJugador1 = false;
        auraJugador2 = false;
        propietarioDisparoPoder = 0;
        balonesFantasma.clear();
        recompensasEntregadas = false;
        progresoGuardado = false;
        finalizadoManual = false;
        partidoActivo = true;
    }
    
    /**
     * Actualiza los proyectiles y comprueba sus impactos.
     */
    private void actualizarProyectiles()
    {
        if (proyectilJugador1 != null
            && proyectilJugador1.isActivo()) {
    
            proyectilJugador1.actualizar();
    
            if (proyectilJugador1.impactar(efectosJugador2)) {
                proyectilJugador1 = null;
            }
            else if (!cancha.estaDentroHorizontal(
                proyectilJugador1.getX())) {
                proyectilJugador1.desactivar();
                proyectilJugador1 = null;
            }
        }
    
        if (proyectilJugador2 != null
            && proyectilJugador2.isActivo()) {
    
            proyectilJugador2.actualizar();
    
            if (proyectilJugador2.impactar(efectosJugador1)) {
                proyectilJugador2 = null;
            }
            else if (!cancha.estaDentroHorizontal(
                proyectilJugador2.getX())) {
                proyectilJugador2.desactivar();
                proyectilJugador2 = null;
            }
        }
    }

    /**
     * Mantiene cargadas las barras especiales y ejecuta las decisiones
     * del rival automatico cuando la partida es jugador contra maquina.
     *
     * @param segundos tiempo transcurrido desde el ciclo anterior.
     */
    private void actualizarCargasPoder(double segundos)
    {
        cargaPoderJugador1 = Math.min(1.0,
            cargaPoderJugador1 + segundos / SEGUNDOS_CARGA_PODER);
        cargaPoderJugador2 = Math.min(1.0,
            cargaPoderJugador2 + segundos / SEGUNDOS_CARGA_PODER);
    }

    private void actualizarMaquina(double segundos)
    {
        if (configuracion == null
            || configuracion.getModo() != ModoPartida.JUGADOR_VS_MAQUINA) {
            return;
        }

        tiempoDecisionMaquina += segundos;
        ciclosMaquina++;
        int direccion = perfilMaquina.decidirDireccion(
            jugador2, balon, cancha, ciclosMaquina
        );

        if (direccion < 0) {
            moverJugador2Izquierda();
        }
        else if (direccion > 0) {
            moverJugador2Derecha();
        }

        if (perfilMaquina.debeSaltar(jugador2, balon)) {
            saltarJugador2();
        }

        if (tiempoDecisionMaquina >= 0.16) {
            tiempoDecisionMaquina = 0;

            if (Math.abs(balon.getX() - jugador2.getX())
                <= perfilMaquina.alcancePatada()
                && Math.abs(balon.getY() - (jugador2.getY() - 36)) < 70) {
                patadaJugador2();
            }

            if (cargaPoderJugador2 >= 1.0 && !auraJugador2
                && Math.abs(balon.getX() - jugador2.getX()) < 220) {
                lanzarPoderJugador2();
            }
        }
    }

    private void actualizarBalonesFantasma(double segundos)
    {
        java.util.Iterator<BalonFantasma> iterador =
            balonesFantasma.iterator();
        while (iterador.hasNext()) {
            BalonFantasma fantasma = iterador.next();
            fantasma.actualizar(segundos, cancha);
            if (!fantasma.estaActivo()) {
                iterador.remove();
            }
        }
    }

    private void crearIlusiones()
    {
        balonesFantasma.clear();
        for (int i = 0; i < 7; i++) {
            int desplazamientoY = (i % 2 == 0 ? -1 : 1)
                * (12 + (i / 2) * 9);
            int desplazamientoX = ((i % 3) - 1) * 16;
            balonesFantasma.add(new BalonFantasma(
                balon.getX() + desplazamientoX,
                balon.getY() + desplazamientoY,
                balon.getVx(), balon.getVy(), 2.5
            ));
        }
    }

    public java.util.List<BalonFantasma> getBalonesFantasma()
    {
        return java.util.Collections.unmodifiableList(balonesFantasma);
    }

    public boolean esModoMaquina()
    {
        return configuracion != null
            && configuracion.getModo() == ModoPartida.JUGADOR_VS_MAQUINA;
    }

    public PerfilMaquina getPerfilMaquina()
    {
        return perfilMaquina;
    }

    /**
     * Detecta si el balon ha atravesado alguna porteria.
     *
     * Si sale por la izquierda, anota el jugador 2.
     * Si sale por la derecha, anota el jugador 1.
     */
    private void detectarGol()
    {
        if (!cancha.estaEnZonaPorteria(balon.getY())) {
            return;
        }

        if (balon.getX() + balon.getRadio() < 0) {
            anotarGolJugador2();
        }
        else if (balon.getX() - balon.getRadio()
            > cancha.getAncho()) {
            anotarGolJugador1();
        }
    }

    /**
     * Registra un gol para el primer jugador.
     */
    public void anotarGolJugador1()
    {
        if (!partidoActivo) {
            return;
        }

        marcador.anotarGolJugador1();
        cargaPoderJugador2 = Math.min(1.0, cargaPoderJugador2 + 0.25);
        reiniciarPosicionesJugadores();
        reiniciarBalon();
        comprobarFinalPartido();
    }

    /**
     * Registra un gol para el segundo jugador.
     */
    public void anotarGolJugador2()
    {
        if (!partidoActivo) {
            return;
        }

        marcador.anotarGolJugador2();
        cargaPoderJugador1 = Math.min(1.0, cargaPoderJugador1 + 0.25);
        reiniciarPosicionesJugadores();
        reiniciarBalon();
        comprobarFinalPartido();
    }

    /**
     * Coloca a ambos jugadores en sus posiciones iniciales tras un gol.
     */
    private void reiniciarPosicionesJugadores()
    {
        jugador1.aterrizar();
        jugador1.establecerPosicion(
            cancha.getAncho() / 2 - 180,
            cancha.getSueloY() - 10
        );

        jugador2.aterrizar();
        jugador2.establecerPosicion(
            cancha.getAncho() / 2 + 180,
            cancha.getSueloY() - 10
        );

        proyectilJugador1 = null;
        proyectilJugador2 = null;
    }

    /**
     * Reinicia el balon en el centro de la cancha.
     */
    private void reiniciarBalon()
    {
        propietarioDisparoPoder = 0;
        balonesFantasma.clear();
        balon.reiniciar(
            cancha.getAncho() / 2,
            cancha.getSueloY() / 2
        );
    }

    /**
     * Comprueba si el partido ha terminado.
     *
     * @return true si existe un ganador y el partido terminó.
     */
    public boolean haTerminado()
    {
        if (finalizadoManual) {
            return true;
        }
        if (configuracion == null || configuracion.esPorGoles()) {
            return marcador.getGolesJugador1() >= golesParaGanar
                || marcador.getGolesJugador2() >= golesParaGanar;
        }
    
        return !partidoActivo && !marcador.estaEmpatado();
    }

    /**
     * Comprueba si se debe finalizar el partido.
     */
    private void comprobarFinalPartido()
    {
        if (configuracion == null || configuracion.esPorGoles()) {
            if (haTerminado()) {
                finalizarPorResultado();
            }
        }
        else if (muerteSubita && !marcador.estaEmpatado()) {
            finalizarPorResultado();
        }
    }

    /**
     * Obtiene el ganador del partido.
     *
     * @return jugador ganador o null si no hay ganador.
     */
    public Jugador getGanador()
    {
        if (!haTerminado()) {
            return null;
        }

        if (marcador.getGolesJugador1()
            > marcador.getGolesJugador2()) {
            return jugador1;
        }

        if (marcador.getGolesJugador2()
            > marcador.getGolesJugador1()) {
            return jugador2;
        }

        return null;
    }
    
    /**
     * Ejecuta una patada del primer jugador hacia la derecha.
     *
     * @return true si la patada alcanza un objetivo.
     */
    public boolean patadaJugador1()
    {
        if (!partidoActivo || !jugador1.estaVivo()
            || jugador1.estaAturdido() || jugador1.isInconsciente()) {
            return false;
        }
    
        boolean disparoEspecial = auraJugador1
            && estaBalonAlAlcanceDelPie(jugador1, 1);
        boolean resultado = patada.ejecutar(
            jugador1, jugador2, balon, 1
        );
        if (resultado && disparoEspecial) {
            poderJugador1.prepararDisparo(balon, 1);
            auraJugador1 = false;
            propietarioDisparoPoder = 1;
            balonesFantasma.clear();
        }
        return resultado;
    }
    
    /**
     * Ejecuta una patada del segundo jugador hacia la izquierda.
     *
     * @return true si la patada alcanza un objetivo.
     */
    public boolean patadaJugador2()
    {
        if (!partidoActivo || !jugador2.estaVivo()
            || jugador2.estaAturdido() || jugador2.isInconsciente()) {
            return false;
        }
    
        boolean disparoEspecial = auraJugador2
            && estaBalonAlAlcanceDelPie(jugador2, -1);
        boolean resultado = patada.ejecutar(
            jugador2, jugador1, balon, -1
        );
        if (resultado && disparoEspecial) {
            poderJugador2.prepararDisparo(balon, -1);
            auraJugador2 = false;
            propietarioDisparoPoder = 2;
            balonesFantasma.clear();
        }
        return resultado;
    }

    private boolean estaBalonAlAlcanceDelPie(Jugador jugador,
                                              int direccion)
    {
        int pieX = jugador.getX() + direccion * 25;
        int pieY = jugador.getY() + 5;
        int dx = balon.getX() - pieX;
        int dy = balon.getY() - pieY;
        return Math.sqrt(dx * dx + dy * dy) <= 36;
    }

    private void activarDisparoPoder(int numeroJugador, int direccion)
    {
        Poder poder = numeroJugador == 1
            ? poderJugador1 : poderJugador2;
        if (poder == null) {
            return;
        }
        poder.prepararDisparo(balon, direccion);
        propietarioDisparoPoder = numeroJugador;
        balonesFantasma.clear();
        if (numeroJugador == 1) {
            auraJugador1 = false;
        }
        else {
            auraJugador2 = false;
        }
    }
    
    
    /**
     * Mueve al primer jugador hacia la izquierda.
     */
    public void moverJugador1Izquierda()
    {
        if (partidoActivo) {
            jugador1.moverIzquierda();
            ajustarPosicion(jugador1);
        }
    }
    
    /**
     * Mueve al primer jugador hacia la derecha.
     */
    public void moverJugador1Derecha()
    {
        if (partidoActivo) {
            jugador1.moverDerecha();
            ajustarPosicion(jugador1);
        }
    }
    
    /**
     * Mueve al segundo jugador hacia la izquierda.
     */
    public void moverJugador2Izquierda()
    {
        if (partidoActivo) {
            jugador2.moverIzquierda();
            ajustarPosicion(jugador2);
        }
    }
    
    /**
     * Mueve al segundo jugador hacia la derecha.
     */
    public void moverJugador2Derecha()
    {
        if (partidoActivo) {
            jugador2.moverDerecha();
            ajustarPosicion(jugador2);
        }
    }
    
    /**
     * Mantiene al jugador dentro de los limites horizontales
     * de la cancha.
     *
     * @param jugador jugador cuya posicion se ajusta.
     */
    private void ajustarPosicion(Jugador jugador)
    {
        int nuevaX = jugador.getX();
    
        if (nuevaX < 0) {
            nuevaX = 0;
        }
    
        if (nuevaX > cancha.getAncho()) {
            nuevaX = cancha.getAncho();
        }
    
        jugador.establecerPosicion(nuevaX, jugador.getY());
    }
    
    /**
     * Aplica el poder del primer jugador sobre el segundo.
     *
     * Se invoca cuando el tiro especial del primer jugador
     * alcanza al segundo.
     */
    public void impactarPoderJugador1()
    {
        if (!partidoActivo || poderJugador1 == null) {
            return;
        }
    
        propietarioDisparoPoder = 0;
        poderJugador1.aplicar(
            jugador1,
            jugador2,
            efectosJugador2
        );
        if (poderJugador1 instanceof Ilusion) {
            crearIlusiones();
        }
        if (jugador2.isEmpujado()) {
            jugador2.setDireccionEmpuje(1);
        }
    }
    
    /**
     * Aplica el poder del segundo jugador sobre el primero.
     *
     * Se invoca cuando el tiro especial del segundo jugador
     * alcanza al primero.
     */
    public void impactarPoderJugador2()
    {
        if (!partidoActivo || poderJugador2 == null) {
            return;
        }
    
        propietarioDisparoPoder = 0;
        poderJugador2.aplicar(
            jugador2,
            jugador1,
            efectosJugador1
        );
        if (poderJugador2 instanceof Ilusion) {
            crearIlusiones();
        }
        if (jugador1.isEmpujado()) {
            jugador1.setDireccionEmpuje(-1);
        }
    }
    
    /**
     * Actualiza la duracion de los efectos especiales.
     *
     * @param segundos tiempo transcurrido.
     */
    public void actualizarEfectos(double segundos)
    {
        if (!partidoActivo) {
            return;
        }
    
        efectosJugador1.actualizar(segundos);
        efectosJugador2.actualizar(segundos);
    }
    
    /**
     * Obtiene el administrador de efectos del primer jugador.
     *
     * @return administrador de efectos.
     */
    public AdministradorEfectos getEfectosJugador1()
    {
        return efectosJugador1;
    }
    
    /**
     * Obtiene el administrador de efectos del segundo jugador.
     *
     * @return administrador de efectos.
     */
    public AdministradorEfectos getEfectosJugador2()
    {
        return efectosJugador2;
    }

    /**
     * Activa el aura del primer jugador cuando la barra esta llena.
     *
     * @return true si el aura quedo activa.
     */
    public boolean lanzarPoderJugador1()
    {
        if (!partidoActivo || poderJugador1 == null
            || auraJugador1 || cargaPoderJugador1 < 1.0
            || !jugador1.estaVivo() || jugador1.isInconsciente()) {
            return false;
        }
        auraJugador1 = true;
        cargaPoderJugador1 = 0;
        return true;
    }
    
    /**
     * Activa el aura del segundo jugador cuando la barra esta llena.
     *
     * @return true si el aura quedo activa.
     */
    public boolean lanzarPoderJugador2()
    {
        if (!partidoActivo || poderJugador2 == null
            || auraJugador2 || cargaPoderJugador2 < 1.0
            || !jugador2.estaVivo() || jugador2.isInconsciente()) {
            return false;
        }
        auraJugador2 = true;
        cargaPoderJugador2 = 0;
        return true;
    }

    public double getCargaPoderJugador1()
    {
        return cargaPoderJugador1;
    }

    public double getCargaPoderJugador2()
    {
        return cargaPoderJugador2;
    }

    public boolean tieneAuraJugador1()
    {
        return auraJugador1;
    }

    public boolean tieneAuraJugador2()
    {
        return auraJugador2;
    }
    
    /**
     * Obtiene el proyectil del primer jugador.
     *
     * @return proyectil del jugador 1.
     */
    public Proyectil getProyectilJugador1()
    {
        return proyectilJugador1;
    }
    
    /**
     * Obtiene el proyectil del segundo jugador.
     *
     * @return proyectil del jugador 2.
     */
    public Proyectil getProyectilJugador2()
    {
        return proyectilJugador2;
    }
    
    /**
     * Establece la configuración de la partida.
     *
     * @param configuracion configuración del partido.
     */
    public void setConfiguracion(ConfiguracionPartido configuracion)
    {
        if (configuracion == null) {
            throw new IllegalArgumentException(
                "La configuración no puede ser nula."
            );
        }
    
        if (partidoActivo) {
            throw new IllegalStateException(
                "No se puede cambiar la configuración durante el partido."
            );
        }
    
        this.configuracion = configuracion;
        perfilMaquina = configuracion.getPerfilMaquina();
        this.tiempoTranscurrido = 0;
        this.muerteSubita = false;
        recompensasEntregadas = false;
        progresoGuardado = false;
        finalizadoManual = false;
    
        if (configuracion.esPorGoles()) {
            this.golesParaGanar = configuracion.getGolesParaGanar();
        }
    }
    
    /**
     * Actualiza el tiempo transcurrido del partido.
     *
     * @param segundos tiempo transcurrido desde la actualización anterior.
     */
    public void actualizarTiempo(double segundos)
    {
        if (segundos < 0) {
            throw new IllegalArgumentException(
                "El tiempo no puede ser negativo."
            );
        }
    
        if (!partidoActivo || configuracion == null) {
            return;
        }
    
        tiempoTranscurrido += segundos;

        if (!configuracion.esPorTiempo()) {
            return;
        }
    
        if (tiempoTranscurrido >= configuracion.getTiempoLimite()) {
            if (marcador.estaEmpatado()) {
                muerteSubita = true;
            }
            else {
            finalizarPorResultado();
            }
        }
    }
    
    /**
     * Comprueba si el partido se encuentra en muerte súbita.
     *
     * @return true si el partido continúa después de un empate por tiempo.
     */
    public boolean estaEnMuerteSubita()
    {
        return muerteSubita;
    }
    
    /**
     * Obtiene el tiempo transcurrido del partido.
     *
     * @return tiempo transcurrido en segundos.
     */
    public double getTiempoTranscurrido()
    {
        return tiempoTranscurrido;
    }

    /**
     * Obtiene los segundos restantes para el final del partido.
     *
     * @return segundos restantes o -1 si se juega por goles.
     */
    public int getTiempoRestante()
    {
        if (configuracion == null || !configuracion.esPorTiempo()) {
            return -1;
        }

        double restante = configuracion.getTiempoLimite()
            - tiempoTranscurrido;

        return Math.max(0, (int) Math.ceil(restante));
    }
    
    /**
     * Permite que el primer jugador salte.
     */
    public void saltarJugador1()
    {
        if (partidoActivo) {
            jugador1.saltar();
        }
    }
    
    /**
     * Permite que el segundo jugador salte.
     */
    public void saltarJugador2()
    {
        if (partidoActivo) {
            jugador2.saltar();
        }
    }
    
}
