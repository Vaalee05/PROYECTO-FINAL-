package juego;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;

/**
 * Pruebas de las reglas centrales del partido.
 *
 * Diccionario de atributos:
 * juego: partido de prueba con dos participantes.
 */
public class JuegoTest
{
    private Juego crearJuego()
    {
        Jugador uno = new Jugador("Azul",
            FabricaPersonajes.crear(0), new Estadisticas());
        Jugador dos = new Jugador("Rojo",
            FabricaPersonajes.crear(1), new Estadisticas());
        return new Juego(uno, dos, new Cancha(800, 400, "800x400"));
    }

    @Test
    public void laBarraSeLlenaEnDiezSegundosYActivaElAura()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5));
        juego.iniciarPartido();

        assertFalse(juego.lanzarPoderJugador1());
        juego.actualizar(10.0);

        assertEquals(1.0, juego.getCargaPoderJugador1(), 0.0001);
        assertTrue(juego.lanzarPoderJugador1());
        assertTrue(juego.tieneAuraJugador1());
        assertEquals(0.0, juego.getCargaPoderJugador1(), 0.0001);
    }

    @Test
    public void elGolCargaUnCuartoLaBarraDelJugadorAfectado()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5));
        juego.iniciarPartido();

        juego.anotarGolJugador1();

        assertEquals(0.25, juego.getCargaPoderJugador2(), 0.0001);
    }

    @Test
    public void elTiroEspecialSeActivaAlPatearElBalon()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5));
        juego.iniciarPartido();
        juego.actualizar(10.0);
        assertTrue(juego.lanzarPoderJugador1());

        Jugador jugador = juego.getJugador1();
        juego.getBalon().reiniciar(
            jugador.getX() + 25, jugador.getY() + 5);
        assertTrue(juego.patadaJugador1());

        assertFalse(juego.tieneAuraJugador1());
        assertEquals(19, juego.getBalon().getVx());
    }

    @Test
    public void elContactoDelCuerpoTambienDisparaElPoderActivo()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5));
        juego.iniciarPartido();
        juego.actualizar(10.0);
        assertTrue(juego.lanzarPoderJugador1());

        Jugador jugador = juego.getJugador1();
        juego.getBalon().reiniciar(jugador.getX(), jugador.getY() - 36);
        juego.actualizar();

        assertFalse(juego.tieneAuraJugador1());
        assertEquals(19, juego.getBalon().getVx());
    }

    @Test
    public void elDanoDelPoderAplicaLaEscalaYKick()
    {
        Jugador atacante = new Jugador("Camerun",
            FabricaPersonajes.crear(1), new Estadisticas(1, 5, 1, 1));
        Jugador objetivo = new Jugador("Rival",
            FabricaPersonajes.crear(0), new Estadisticas());
        AdministradorEfectos efectos = new AdministradorEfectos(objetivo);

        new Rayo().aplicar(atacante, objetivo, efectos);

        assertEquals(16, objetivo.getVidaActual());
        assertTrue(objetivo.isElectrocutado());
    }

    @Test
    public void unaMejoraDuplicaElSiguienteCosto()
    {
        ProgresoJugador perfil = new ProgresoJugador();
        perfil.establecer(new Estadisticas(), 1500, 500);

        assertTrue(perfil.mejorar(AtributoJugador.KICK));
        assertEquals(1000, perfil.getPuntos());
        assertEquals(1000, perfil.getCostoSiguienteMejora());
        assertEquals(2, perfil.getEstadisticas().getKick());
    }

    @Test
    public void elPerfilMaquinaOfensivoPersigueElBalon()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5, ModoPartida.JUGADOR_VS_MAQUINA,
            PerfilMaquina.OFENSIVA));
        juego.iniciarPartido();
        int xInicial = juego.getJugador2().getX();

        juego.actualizar();

        assertTrue(juego.getJugador2().getX() < xInicial);
    }
}
