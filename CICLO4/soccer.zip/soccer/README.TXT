PROYECTO: DOPOSoccer
VERSION: Version 3 - 2026-11-23

PROPOSITO
DOPOSoccer es un juego de futbol 2D para dos jugadores en el mismo teclado,
o para una persona contra una maquina. Cada jugador puede correr, saltar,
patear y cargar el poder especial de su personaje para marcar en el arco rival.

COMO ABRIR EN BLUEJ
1. Abre BlueJ y selecciona Proyecto > Abrir proyecto.
2. Abre la carpeta soccer que esta en el Escritorio.
3. Espera a que BlueJ actualice los paquetes juego e interfaz.
4. Abre el paquete interfaz, haz clic derecho en VentanaPrincipal y crea
   un objeto. El constructor abre la pantalla de inicio.
5. Si BlueJ indica que el proyecto necesita compilarse, compila primero
   los paquetes juego e interfaz.

CONFIGURACION
Elige nombres y personajes, modo de juego, perfil de maquina, resolucion y
final por tiempo o por goles. Los perfiles de jugador conservan puntos y
mejoras entre sesiones.

CONTROLES
Jugador 1: A/D mover, W saltar, S patear, Q activar poder.
Jugador 2: flechas izquierda/derecha mover, flecha arriba saltar,
flecha abajo patear, Ctrl activar poder.
Esc o el boton Pausa abre el menu. Desde el menu se puede continuar,
reiniciar, guardar, abrir otra partida, finalizar, volver a seleccion o salir.

REGLAS PRINCIPALES
La barra de poder tarda 10 segundos en llenarse. Al activarla aparece un aura;
el siguiente contacto con el balon produce el tiro especial. Si el tiro toca
al rival, aplica su daño y efecto; un gol sin impacto solo cuenta como gol.
Cada punto de Kick aumenta el daño un 10%; los poderes aplican el factor de
escala x5 indicado en el proyecto. El ganador recibe 100 puntos y el otro
jugador 25. Las mejoras cuestan 500, 1000, 2000 y asi sucesivamente.
Al quedar sin vida, el jugador vuelve con vida maxima despues de tres segundos.

ARCHIVOS DE DATOS
El progreso se guarda en datos/progreso.properties.
Los partidos se guardan como archivos .dopo elegidos desde el menu de pausa.
Los errores se registran en datos/logs/doposoccer.log.

RECURSOS
Las imagenes de la cancha y los personajes se encuentran en imagenes/.
No muevas esa carpeta fuera del proyecto BlueJ.

DOCUMENTACION Y ENTREGA
PLANIFICACION_VERSIONES.md describe versiones y miniciclos.
DIAGRAMAS_DOPOSOCCER.md contiene diagramas de clases y secuencias.
PRUEBAS_ACEPTACION_V3.md contiene los escenarios iniciales de aceptacion.
El paquete pruebas contiene las pruebas unitarias de las reglas, la interfaz
de inicio y la persistencia. Haz clic derecho en cada clase de prueba y elige
"Probar todo" desde BlueJ para ejecutar la suite.
