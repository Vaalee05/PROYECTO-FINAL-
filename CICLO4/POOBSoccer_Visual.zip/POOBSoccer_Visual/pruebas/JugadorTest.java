package pruebas;




import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import juego.*;

/**
 * Pruebas unitarias de la clase Jugador.
 *
 * Verifica la vida, el movimiento, el salto,
 * los efectos y la recuperacion del jugador.
 */
public class JugadorTest
{
    private Jugador jugador;
    private Estadisticas estadisticas;

    /**
     * Prepara un jugador nuevo antes de cada prueba.
     */
    @BeforeEach
    public void setUp()
    {
        estadisticas = new Estadisticas();

        Personaje personaje = new Personaje(
            "Corea del Sur",
            "Aura Azul",
            "auraAzul.png"
        );

        jugador = new Jugador(
            "Jugador 1",
            personaje,
            estadisticas
        );
    }

    /**
     * Comprueba que el jugador inicia con 100 puntos de vida.
     */
    @Test
    public void testVidaInicial()
    {
        assertEquals(100, jugador.getVidaActual());
        assertEquals(100, jugador.getVidaMaxima());
    }

    /**
     * Comprueba que la supervivencia aumenta la vida maxima.
     */
    @Test
    public void testVidaSegunSupervivencia()
    {
        for (int i = 0; i < 9; i++) {
            estadisticas.mejorarSurvival();
        }

        Jugador jugadorMejorado = new Jugador(
            "Jugador 2",
            new Personaje("Nigeria", "Tornado", "tornado.png"),
            estadisticas
        );

        assertEquals(190, jugadorMejorado.getVidaMaxima());
    }

    /**
     * Comprueba que el jugador se mueve hacia la derecha.
     */
    @Test
    public void testMoverDerecha()
    {
        jugador.moverDerecha();

        assertEquals(4, jugador.getX());
    }

    /**
     * Comprueba que el jugador no puede saltar electrocutado.
     */
    @Test
    public void testNoPuedeSaltarElectrocutado()
    {
        jugador.setElectrocutado(true);
        jugador.saltar();

        assertFalse(jugador.estaSaltando());
    }

    /**
     * Comprueba que el daño puede dejar al jugador aturdido.
     */
    @Test
    public void testAturdimientoPorDanio()
    {
        jugador.recibirDanio(200);

        assertEquals(0, jugador.getVidaActual());
        assertTrue(jugador.estaAturdido());
        assertFalse(jugador.estaVivo());
    }

    /**
     * Comprueba que el jugador se recupera despues de tres segundos.
     */
    @Test
    public void testRecuperacionDespuesDeTresSegundos()
    {
        jugador.recibirDanio(200);
        jugador.actualizarAturdimiento(3.0);

        assertFalse(jugador.estaAturdido());
        assertEquals(100, jugador.getVidaActual());
        assertTrue(jugador.estaVivo());
    }

    /**
     * Comprueba que el jugador no se recupera antes de tres segundos.
     */
    @Test
    public void testNoSeRecuperaAntesDeTresSegundos()
    {
        jugador.recibirDanio(200);
        jugador.actualizarAturdimiento(2.0);

        assertTrue(jugador.estaAturdido());
        assertEquals(0, jugador.getVidaActual());
    }
}
