package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.KeyboardFocusManager;
import java.awt.Window;
import java.awt.event.KeyEvent;
import java.awt.image.BufferedImage;
import java.io.File;
import java.lang.reflect.Field;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.nio.file.Path;
import java.util.Set;
import java.util.HashSet;
import java.util.concurrent.atomic.AtomicReference;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JFileChooser;
import javax.swing.JPanel;
import javax.swing.JSpinner;
import javax.swing.JTextField;
import javax.swing.SpinnerNumberModel;
import javax.swing.SwingUtilities;
import javax.swing.Timer;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import juego.*;
import interfaz.*;

/**
 * Prueba la navegacion Swing, el selector y el dibujo del partido.
 *
 * Diccionario de atributos:
 * temporal: directorio aislado para guardar datos de las pruebas.
 * dialogo: temporizador que cierra cuadros modales durante la prueba.
 */
public class InterfazIntegracionTest
{
    @TempDir
    Path temporal;

    @AfterEach
    public void cerrarVentanas()
    {
        for (Window ventana : Window.getWindows()) {
            if (ventana instanceof VentanaPartido) {
                detenerPartido((VentanaPartido) ventana);
            }
            ventana.dispose();
        }
    }

    @Test
    public void laPortadaAbreElSelectorYElBotonSalirCierraLaVentana()
    {
        AtomicReference<VentanaPrincipal> principal = new AtomicReference<>();
        ejecutarEnEDT(() -> principal.set(new VentanaPrincipal()));
        assertEquals("DOPOSoccer", principal.get().getTitle());
        assertTrue(principal.get().isVisible());
        assertTrue(principal.get().getContentPane() instanceof PantallaInicio);

        ejecutarEnEDT(() -> ((PantallaInicio) principal.get()
            .getContentPane()).getBotonIniciar().doClick());
        assertFalse(principal.get().isDisplayable());
        assertTrue(ventanaVisible(SeleccionPersonajes.class));
    }

    @Test
    public void selectorActualizaModoPerfilYFinalizacion()
    {
        AtomicReference<SeleccionPersonajes> selector = new AtomicReference<>();
        RepositorioProgreso repositorio = repositorioTemporal();
        ejecutarEnEDT(() -> selector.set(new SeleccionPersonajes(repositorio)));

        ejecutarEnEDT(() -> {
            JComboBox<?> modo = campo(selector.get(), "seleccionModo",
                JComboBox.class);
            JComboBox<?> perfil = campo(selector.get(), "seleccionPerfil",
                JComboBox.class);
            JTextField nombre2 = campo(selector.get(), "nombreJugador2",
                JTextField.class);
            JComboBox<?> modalidad = campo(selector.get(), "seleccionModalidad",
                JComboBox.class);
            JSpinner duracion = campo(selector.get(), "duracion", JSpinner.class);

            modo.setSelectedItem(ModoPartida.JUGADOR_VS_MAQUINA);
            assertTrue(perfil.isEnabled());
            assertFalse(nombre2.isEditable());
            assertEquals("CPU Torpe", nombre2.getText());
            perfil.setSelectedItem(PerfilMaquina.EXPERTA);
            assertEquals("CPU Experta", nombre2.getText());

            modo.setSelectedItem(ModoPartida.JUGADOR_VS_JUGADOR);
            assertFalse(perfil.isEnabled());
            assertTrue(nombre2.isEditable());
            modalidad.setSelectedIndex(1);
            assertEquals(20, ((SpinnerNumberModel) duracion.getModel())
                .getMaximum());
            assertEquals("Goles necesarios para ganar", duracion.getToolTipText());
            modalidad.setSelectedIndex(0);
            assertEquals(30, ((SpinnerNumberModel) duracion.getModel())
                .getMaximum());

            JTextField nombre1 = campo(selector.get(), "nombreJugador1",
                JTextField.class);
            nombre1.setText("   ");
            llamar(selector.get(), "actualizarResumen",
                new Class<?>[] {int.class}, 1);
            assertTrue(campo(selector.get(), "progreso1",
                javax.swing.JLabel.class).getText().contains("Escribe un nombre"));
        });
    }

    @Test
    public void selectorRechazaNombresInvalidosYPermiteIniciarPartida()
    {
        AtomicReference<SeleccionPersonajes> selector = new AtomicReference<>();
        ejecutarEnEDT(() -> selector.set(new SeleccionPersonajes(
            repositorioTemporal())));
        JButton iniciar = buscarBoton(selector.get(), "Iniciar partido");

        ejecutarEnEDT(() -> {
            campo(selector.get(), "nombreJugador1", JTextField.class).setText("");
            campo(selector.get(), "nombreJugador2", JTextField.class).setText("");
        });
        programarCierreDialogos();
        ejecutarEnEDT(iniciar::doClick);

        ejecutarEnEDT(() -> {
            JTextField nombre1 = campo(selector.get(), "nombreJugador1",
                JTextField.class);
            JTextField nombre2 = campo(selector.get(), "nombreJugador2",
                JTextField.class);
            nombre1.setText("Mismo");
            nombre2.setText("mismo");
        });
        programarCierreDialogos();
        ejecutarEnEDT(iniciar::doClick);

        ejecutarEnEDT(() -> {
            JTextField nombre1 = campo(selector.get(), "nombreJugador1",
                JTextField.class);
            JTextField nombre2 = campo(selector.get(), "nombreJugador2",
                JTextField.class);
            nombre1.setText("Equipo Azul");
            nombre2.setText("Equipo Rojo");
        });
        ejecutarEnEDT(iniciar::doClick);
        assertTrue(ventanaVisible(VentanaPartido.class));
    }

    @Test
    public void elPartidoDibujaPoderesEstadosPersonajesYMarcadores()
    {
        for (int pais = 0; pais < 4; pais++) {
            Juego juego = crearJuego(pais, (pais + 1) % 4);
            juego.setConfiguracion(new ConfiguracionPartido(
                "GOLES", 60, 5));
            VentanaPartido ventana = crearVentanaPartido(juego);
            juego.actualizar(10.0);
            assertTrue(juego.lanzarPoderJugador1());
            pintarCancha(ventana);

            Jugador azul = juego.getJugador1();
            juego.getBalon().reiniciar(azul.getX() + 25, azul.getY() + 5);
            assertTrue(juego.patadaJugador1());
            pintarCancha(ventana);
            assertEquals(1, juego.getPropietarioDisparoPoder());
            juego.impactarPoderJugador1();
            pintarCancha(ventana);

            Proyectil proyectil1 = new Proyectil(azul,
                juego.getJugador2(), new AuraAzul(), 8);
            Proyectil proyectil2 = new Proyectil(juego.getJugador2(),
                azul, new Rayo(), 8);
            establecerCampo(juego, "proyectilJugador1", proyectil1);
            establecerCampo(juego, "proyectilJugador2", proyectil2);
            pintarCancha(ventana);

            if (pais == 0) {
                azul.recibirDanio(200);
                pintarCancha(ventana);
            }
        }

        Personaje desconocido = new Personaje("Perú", "Invitado",
            "jugador_azul.png");
        Juego otro = new Juego(new Jugador("Invitado", desconocido,
            new Estadisticas()), jugador(1), new Cancha(800, 400, "800x400"));
        otro.setConfiguracion(new ConfiguracionPartido("TIEMPO", 120, 5));
        VentanaPartido tiempo = crearVentanaPartido(otro);
        otro.actualizarTiempo(12);
        pintarCancha(tiempo);
        otro.actualizarTiempo(108);
        pintarCancha(tiempo);

        Juego ganador = crearJuego(0, 1);
        ganador.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 1));
        VentanaPartido resultado = crearVentanaPartido(ganador);
        ganador.anotarGolJugador1();
        pintarCancha(resultado);

        Juego empate = crearJuego(0, 1);
        VentanaPartido empateVentana = crearVentanaPartido(empate);
        empate.finalizarPartido();
        pintarCancha(empateVentana);
    }

    @Test
    public void controlesPausaTiempoYSelectoresDelPartidoResponden()
    {
        Juego juego = crearJuego(0, 1);
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 5));
        VentanaPartido ventana = crearVentanaPartido(juego);
        ejecutarEnEDT(() -> ventana.setVisible(true));
        Set<Integer> teclas = campo(ventana, "teclasPresionadas", Set.class);
        int x1 = juego.getJugador1().getX();
        int x2 = juego.getJugador2().getX();
        teclas.add(KeyEvent.VK_A);
        teclas.add(KeyEvent.VK_RIGHT);
        llamar(ventana, "procesarMovimiento", new Class<?>[0]);
        assertTrue(juego.getJugador1().getX() < x1);
        assertTrue(juego.getJugador2().getX() > x2);
        assertTrue((boolean) llamar(ventana, "esTeclaDelJuego",
            new Class<?>[] {int.class}, KeyEvent.VK_Q));
        assertFalse((boolean) llamar(ventana, "esTeclaDelJuego",
            new Class<?>[] {int.class}, KeyEvent.VK_Z));
        assertTrue((boolean) llamar(ventana, "esTeclaJugador2",
            new Class<?>[] {int.class}, KeyEvent.VK_CONTROL));
        assertFalse((boolean) llamar(ventana, "esTeclaJugador2",
            new Class<?>[] {int.class}, KeyEvent.VK_A));

        assertEquals("Partido por goles · 00:00",
            llamar(ventana, "crearTextoTiempo", new Class<?>[0]));
        juego.finalizarPartido();
        juego.setConfiguracion(new ConfiguracionPartido("TIEMPO", 30, 5));
        juego.iniciarPartido();
        assertEquals("Tiempo restante: 00:30",
            llamar(ventana, "crearTextoTiempo", new Class<?>[0]));
        juego.actualizarTiempo(30);
        assertEquals("Muerte subita - 00:00",
            llamar(ventana, "crearTextoTiempo", new Class<?>[0]));

        programarBotonPausa("Continuar");
        ejecutarEnEDT(() -> {
            llamar(ventana, "mostrarMenuPausa", new Class<?>[0]);
        });
        assertTrue(juego.isPartidoActivo());
        assertTrue(campo(ventana, "temporizador", Timer.class).isRunning());
        detenerPartido(ventana);

        programarCancelarSelector();
        ejecutarEnEDT(() -> {
            llamar(ventana, "guardarPartida", new Class<?>[0]);
        });
        programarCancelarSelector();
        Object resultado = ejecutarEnEDTConResultado(() -> llamar(ventana,
            "abrirPartida", new Class<?>[0]));
        assertFalse((Boolean) resultado);
    }

    @Test
    public void partidaGuardaResultadoEnElRepositorioInyectado()
        throws Exception
    {
        Juego juego = crearJuego(0, 1);
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 1));
        RepositorioProgreso repositorio = repositorioTemporal();
        VentanaPartido ventana = crearVentanaPartido(juego, repositorio);

        llamar(ventana, "guardarProgresoSiTermino", new Class<?>[0]);
        assertFalse(juego.isProgresoGuardado());
        juego.anotarGolJugador1();
        llamar(ventana, "guardarProgresoSiTermino", new Class<?>[0]);
        assertTrue(juego.isProgresoGuardado());
        assertEquals(100, repositorio.cargar("Jugador 0").getPuntos());
        assertEquals(25, repositorio.cargar("Jugador 1").getPuntos());
        llamar(ventana, "guardarProgresoSiTermino", new Class<?>[0]);
        assertEquals(100, repositorio.cargar("Jugador 0").getPuntos());

        assertEquals("partida.Dopo", ((File) llamar(ventana,
            "ajustarExtension", new Class<?>[] {File.class},
            new File("partida.Dopo"))).getName());
        assertTrue(((File) llamar(ventana, "ajustarExtension",
            new Class<?>[] {File.class}, new File("partida")))
                .getName().endsWith("partida.dopo"));
        assertTrue(llamar(ventana, "crearSelectorPartida", new Class<?>[0])
            instanceof JFileChooser);
        llamar(ventana, "actualizarDimensionCancha", new Class<?>[0]);
    }

    private Juego crearJuego(int azul, int rojo)
    {
        return new Juego(jugador(azul), jugador(rojo),
            new Cancha(800, 400, "800x400"));
    }

    private Jugador jugador(int seleccion)
    {
        return new Jugador("Jugador " + seleccion,
            FabricaPersonajes.crear(seleccion), new Estadisticas());
    }

    private RepositorioProgreso repositorioTemporal()
    {
        return new RepositorioProgreso(temporal.resolve("perfiles.properties")
            .toFile());
    }

    private VentanaPartido crearVentanaPartido(Juego juego)
    {
        return crearVentanaPartido(juego, repositorioTemporal());
    }

    private VentanaPartido crearVentanaPartido(Juego juego,
        RepositorioProgreso repositorio)
    {
        AtomicReference<VentanaPartido> referencia = new AtomicReference<>();
        ejecutarEnEDT(() -> {
            referencia.set(new VentanaPartido(juego, repositorio));
            campo(referencia.get(), "temporizador", Timer.class).stop();
        });
        return referencia.get();
    }

    private void pintarCancha(VentanaPartido ventana)
    {
        ejecutarEnEDT(() -> {
            JPanel panel = campo(ventana, "panelCancha", JPanel.class);
            panel.setSize(800, 500);
            acomodar(panel);
            BufferedImage imagen = new BufferedImage(800, 500,
                BufferedImage.TYPE_INT_ARGB);
            Graphics2D grafico = imagen.createGraphics();
            panel.paint(grafico);
            grafico.dispose();
            assertNotEquals(0, imagen.getRGB(400, 240));
        });
    }

    private void detenerPartido(VentanaPartido ventana)
    {
        Timer temporizador = campo(ventana, "temporizador", Timer.class);
        if (temporizador != null) {
            temporizador.stop();
        }
        java.awt.KeyEventDispatcher manejador = campo(ventana,
            "manejadorTeclado", java.awt.KeyEventDispatcher.class);
        if (manejador != null) {
            KeyboardFocusManager.getCurrentKeyboardFocusManager()
                .removeKeyEventDispatcher(manejador);
        }
    }

    private void acomodar(Container contenedor)
    {
        contenedor.doLayout();
        for (Component componente : contenedor.getComponents()) {
            if (componente instanceof Container) {
                acomodar((Container) componente);
            }
        }
    }

    private JButton buscarBoton(Container contenedor, String texto)
    {
        for (Component componente : contenedor.getComponents()) {
            if (componente instanceof JButton
                && texto.equals(((JButton) componente).getText())) {
                return (JButton) componente;
            }
            if (componente instanceof Container) {
                JButton encontrado = buscarBoton((Container) componente, texto);
                if (encontrado != null) {
                    return encontrado;
                }
            }
        }
        return null;
    }

    private boolean ventanaVisible(Class<?> tipo)
    {
        for (Window ventana : Window.getWindows()) {
            if (tipo.isInstance(ventana) && ventana.isVisible()) {
                return true;
            }
        }
        return false;
    }

    private void programarBotonPausa(String texto)
    {
        Timer cerrar = new Timer(100, evento -> {
            for (Window ventana : Window.getWindows()) {
                if (ventana instanceof JDialog && ventana.isVisible()
                    && "Partido pausado".equals(((JDialog) ventana).getTitle())) {
                    JButton boton = buscarBoton((Container) ventana, texto);
                    if (boton != null) {
                        boton.doClick();
                        ((Timer) evento.getSource()).stop();
                        return;
                    }
                }
            }
        });
        cerrar.setRepeats(true);
        cerrar.start();
    }

    private void programarCierreDialogos()
    {
        Timer cerrar = new Timer(100, evento -> {
            for (Window ventana : Window.getWindows()) {
                if (ventana instanceof JDialog && ventana.isVisible()) {
                    ventana.dispose();
                    ((Timer) evento.getSource()).stop();
                    return;
                }
            }
        });
        cerrar.setRepeats(true);
        cerrar.start();
    }

    private void programarCancelarSelector()
    {
        Timer cerrar = new Timer(100, evento -> {
            for (Window ventana : Window.getWindows()) {
                if (ventana instanceof JDialog && ventana.isVisible()) {
                    JFileChooser selector = buscarSelector((Container) ventana);
                    if (selector != null) {
                        selector.cancelSelection();
                        ((Timer) evento.getSource()).stop();
                        return;
                    }
                }
            }
        });
        cerrar.setRepeats(true);
        cerrar.start();
    }

    private JFileChooser buscarSelector(Container contenedor)
    {
        for (Component componente : contenedor.getComponents()) {
            if (componente instanceof JFileChooser) {
                return (JFileChooser) componente;
            }
            if (componente instanceof Container) {
                JFileChooser encontrado = buscarSelector((Container) componente);
                if (encontrado != null) {
                    return encontrado;
                }
            }
        }
        return null;
    }

    private <T> T campo(Object objeto, String nombre, Class<T> tipo)
    {
        try {
            Field campo = objeto.getClass().getDeclaredField(nombre);
            campo.setAccessible(true);
            return tipo.cast(campo.get(objeto));
        }
        catch (ReflectiveOperationException error) {
            throw new AssertionError("No se pudo leer " + nombre, error);
        }
    }

    private void establecerCampo(Object objeto, String nombre, Object valor)
    {
        try {
            Field campo = objeto.getClass().getDeclaredField(nombre);
            campo.setAccessible(true);
            campo.set(objeto, valor);
        }
        catch (ReflectiveOperationException error) {
            throw new AssertionError("No se pudo cambiar " + nombre, error);
        }
    }

    private Object llamar(Object objeto, String nombre, Class<?>[] parametros,
                          Object... argumentos)
    {
        try {
            Method metodo = objeto.getClass().getDeclaredMethod(nombre,
                parametros);
            metodo.setAccessible(true);
            return metodo.invoke(objeto, argumentos);
        }
        catch (InvocationTargetException error) {
            Throwable causa = error.getCause();
            if (causa instanceof RuntimeException) {
                throw (RuntimeException) causa;
            }
            if (causa instanceof Error) {
                throw (Error) causa;
            }
            throw new AssertionError(causa);
        }
        catch (ReflectiveOperationException error) {
            throw new AssertionError("No se pudo ejecutar " + nombre, error);
        }
    }

    private Object ejecutarEnEDTConResultado(
        java.util.concurrent.Callable<?> accion)
    {
        AtomicReference<Object> resultado = new AtomicReference<>();
        ejecutarEnEDT(() -> {
            try {
                resultado.set(accion.call());
            }
            catch (RuntimeException | Error error) {
                throw error;
            }
            catch (Exception error) {
                throw new AssertionError(error);
            }
        });
        return resultado.get();
    }

    private void ejecutarEnEDT(Runnable accion)
    {
        if (SwingUtilities.isEventDispatchThread()) {
            accion.run();
            return;
        }
        try {
            SwingUtilities.invokeAndWait(accion);
        }
        catch (InterruptedException error) {
            Thread.currentThread().interrupt();
            throw new AssertionError(error);
        }
        catch (InvocationTargetException error) {
            Throwable causa = error.getCause();
            if (causa instanceof RuntimeException) {
                throw (RuntimeException) causa;
            }
            if (causa instanceof Error) {
                throw (Error) causa;
            }
            throw new AssertionError(causa);
        }
    }
}
