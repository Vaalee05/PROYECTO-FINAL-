package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import juego.*;

/**
 * Recorre las reglas de comienzo, marcador, reloj y control de un partido.
 *
 * Diccionario de atributos:
 * juego: partido que se prueba de inicio a cierre.
 * azul: primer jugador.
 * rojo: segundo jugador.
 */
public class JuegoIntegracionTest
{
    private Juego crearJuego()
    {
        Jugador azul = new Jugador("Azul", FabricaPersonajes.crear(0),
            new Estadisticas());
        Jugador rojo = new Jugador("Rojo", FabricaPersonajes.crear(1),
            new Estadisticas());
        return new Juego(azul, rojo, new Cancha(800, 400, "800x400"));
    }

    @Test
    public void construccionInicioYValidacionDeLaPartida()
    {
        Jugador jugador = new Jugador("Azul", FabricaPersonajes.crear(0),
            new Estadisticas());
        Cancha cancha = new Cancha(800, 400, "800x400");
        assertThrows(IllegalArgumentException.class,
            () -> new Juego(null, jugador, cancha));
        assertThrows(IllegalArgumentException.class,
            () -> new Juego(jugador, jugador, cancha));
        assertThrows(IllegalArgumentException.class,
            () -> new Juego(jugador, new Jugador("Rojo",
                FabricaPersonajes.crear(1), new Estadisticas()), null));

        Juego juego = crearJuego();
        assertFalse(juego.isPartidoActivo());
        assertEquals(5, juego.getGolesParaGanar());
        assertEquals(400, juego.getBalon().getX());
        assertEquals(200, juego.getBalon().getY());
        assertEquals(1, juego.getJugador1().getDireccionMirada());
        assertEquals(-1, juego.getJugador2().getDireccionMirada());
        assertEquals(0, juego.getTiempoTranscurrido(), 0.0001);
        assertEquals(-1, juego.getTiempoRestante());
        assertNull(juego.getGanador());
        assertFalse(juego.haTerminado());
        assertFalse(juego.esModoMaquina());
        assertNull(juego.getPoderEnVuelo());
        assertThrows(IllegalArgumentException.class,
            () -> juego.setGolesParaGanar(0));
        assertThrows(IllegalArgumentException.class,
            () -> juego.setConfiguracion(null));

        juego.setGolesParaGanar(3);
        assertEquals(3, juego.getGolesParaGanar());
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 4));
        assertEquals(4, juego.getGolesParaGanar());
        juego.iniciarPartido();
        juego.iniciarPartido();
        assertTrue(juego.isPartidoActivo());
        assertThrows(IllegalStateException.class,
            () -> juego.setConfiguracion(new ConfiguracionPartido(
                "GOLES", 60, 2)));
        assertThrows(IllegalStateException.class,
            () -> juego.setGolesParaGanar(2));
        assertThrows(IllegalArgumentException.class,
            () -> juego.actualizar(-0.1));
        assertThrows(IllegalArgumentException.class,
            () -> juego.actualizarTiempo(-0.1));
    }

    @Test
    public void losControlesMuevenAAmbosJugadoresYRespetanLosBordes()
    {
        Juego juego = crearJuego();
        int azulX = juego.getJugador1().getX();
        int rojoX = juego.getJugador2().getX();
        juego.moverJugador1Izquierda();
        juego.moverJugador2Derecha();
        assertEquals(azulX, juego.getJugador1().getX());
        assertEquals(rojoX, juego.getJugador2().getX());
        juego.iniciarPartido();
        juego.moverJugador1Izquierda();
        juego.moverJugador2Derecha();
        assertTrue(juego.getJugador1().getX() < azulX);
        assertTrue(juego.getJugador2().getX() > rojoX);

        juego.getJugador1().establecerPosicion(0, 390);
        juego.getJugador2().establecerPosicion(800, 390);
        juego.moverJugador1Izquierda();
        juego.moverJugador2Derecha();
        assertEquals(0, juego.getJugador1().getX());
        assertEquals(800, juego.getJugador2().getX());

        juego.saltarJugador1();
        juego.saltarJugador2();
        assertTrue(juego.getJugador1().estaSaltando());
        assertTrue(juego.getJugador2().estaSaltando());
        juego.actualizar();
        assertTrue(juego.getJugador1().getY() < 390);
        assertTrue(juego.getJugador2().getY() < 390);
    }

    @Test
    public void unGolRecolocaJugadoresBalonYRecargaAlRival()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 5));
        juego.iniciarPartido();
        juego.getJugador1().establecerPosicion(50, 140);
        juego.getJugador2().establecerPosicion(700, 160);
        juego.getBalon().reiniciar(20, 200);
        juego.getBalon().setVelocidad(-8, 0);

        juego.anotarGolJugador1();

        assertEquals(1, juego.getMarcador().getGolesJugador1());
        assertEquals(0, juego.getMarcador().getGolesJugador2());
        assertEquals(220, juego.getJugador1().getX());
        assertEquals(580, juego.getJugador2().getX());
        assertEquals(400, juego.getBalon().getX());
        assertEquals(200, juego.getBalon().getY());
        assertEquals(0, juego.getBalon().getVx());
        assertEquals(0.25, juego.getCargaPoderJugador2(), 0.0001);
        assertTrue(juego.isPartidoActivo());
        juego.anotarGolJugador2();
        assertEquals(0.25, juego.getCargaPoderJugador1(), 0.0001);
    }

    @Test
    public void partidoPorGolesEntregaPremiosUnaSolaVezYPermiteReiniciar()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 1));
        juego.iniciarPartido();
        juego.getBalon().setVelocidad(9, 4);
        juego.anotarGolJugador2();

        assertTrue(juego.haTerminado());
        assertFalse(juego.isPartidoActivo());
        assertSame(juego.getJugador2(), juego.getGanador());
        assertEquals(100, juego.getJugador2().getPuntos());
        assertEquals(25, juego.getJugador1().getPuntos());
        assertTrue(juego.isRecompensaEntregada());
        juego.finalizarPartido();
        assertEquals(100, juego.getJugador2().getPuntos());

        juego.marcarProgresoGuardado();
        assertTrue(juego.isProgresoGuardado());
        juego.reiniciarPartido();
        assertTrue(juego.isPartidoActivo());
        assertFalse(juego.haTerminado());
        assertFalse(juego.isRecompensaEntregada());
        assertFalse(juego.isProgresoGuardado());
        assertEquals(0, juego.getMarcador().getGolesJugador1());
        assertEquals(0, juego.getMarcador().getGolesJugador2());
        assertEquals(0, juego.getBalon().getVx());
    }

    @Test
    public void finalManualEnEmpateNoAsignaGanadorNiPremios()
    {
        Juego juego = crearJuego();
        juego.iniciarPartido();
        juego.finalizarPartido();
        juego.finalizarPartido();
        assertTrue(juego.haTerminado());
        assertNull(juego.getGanador());
        assertFalse(juego.isRecompensaEntregada());
        assertEquals(0, juego.getJugador1().getPuntos());
        assertEquals(0, juego.getJugador2().getPuntos());
        assertFalse(juego.patadaJugador1());
        assertFalse(juego.patadaJugador2());
        juego.anotarGolJugador1();
        assertEquals(0, juego.getMarcador().getGolesJugador1());
        juego.actualizarEfectos(1.0);
    }

    @Test
    public void elRelojFinalizaConVentajaYEnEmpateEntraEnMuerteSubita()
    {
        Juego conVentaja = crearJuego();
        conVentaja.setConfiguracion(new ConfiguracionPartido(
            "TIEMPO", 10, 5));
        conVentaja.iniciarPartido();
        conVentaja.anotarGolJugador1();
        conVentaja.actualizarTiempo(9.2);
        assertEquals(1, conVentaja.getTiempoRestante());
        conVentaja.actualizarTiempo(0.8);
        assertTrue(conVentaja.haTerminado());
        assertSame(conVentaja.getJugador1(), conVentaja.getGanador());
        assertEquals(100, conVentaja.getJugador1().getPuntos());

        Juego empate = crearJuego();
        empate.setConfiguracion(new ConfiguracionPartido("TIEMPO", 5, 5));
        empate.iniciarPartido();
        empate.actualizarTiempo(5);
        assertTrue(empate.estaEnMuerteSubita());
        assertTrue(empate.isPartidoActivo());
        assertEquals(0, empate.getTiempoRestante());
        empate.anotarGolJugador2();
        assertTrue(empate.haTerminado());
        assertSame(empate.getJugador2(), empate.getGanador());
    }

    @Test
    public void segundoJugadorPuedeCargarPatearYAplicarSuPoder()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 5));
        juego.iniciarPartido();
        assertFalse(juego.lanzarPoderJugador2());
        juego.actualizar(10);
        assertEquals(1.0, juego.getCargaPoderJugador2(), 0.0001);
        assertTrue(juego.lanzarPoderJugador2());
        assertTrue(juego.tieneAuraJugador2());
        assertFalse(juego.lanzarPoderJugador2());

        Jugador rojo = juego.getJugador2();
        juego.getBalon().reiniciar(rojo.getX() - 25, rojo.getY() + 5);
        assertTrue(juego.patadaJugador2());
        assertEquals(-22, juego.getBalon().getVx());
        assertFalse(juego.tieneAuraJugador2());
        assertEquals(2, juego.getPropietarioDisparoPoder());
        assertTrue(juego.getPoderEnVuelo() instanceof Rayo);

        juego.impactarPoderJugador2();
        assertTrue(juego.getJugador1().isElectrocutado());
        assertEquals(60, juego.getJugador1().getVidaMaxima()
            - juego.getJugador1().getVidaActual());
        juego.actualizarEfectos(3.0);
        assertFalse(juego.getJugador1().isElectrocutado());
        assertNull(juego.getPoderEnVuelo());
    }

    @Test
    public void desmayoYEmpujeSeActualizanYSeDetienenAlFinalizar()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 5));
        juego.iniciarPartido();
        juego.impactarPoderJugador1();
        assertFalse(juego.getJugador2().isElectrocutado());
        juego.getEfectosJugador2().activar(new Empuje());
        juego.getJugador2().setDireccionEmpuje(1);
        int antes = juego.getJugador2().getX();
        juego.actualizar(0.1);
        assertEquals(antes + 5, juego.getJugador2().getX());
        juego.actualizarEfectos(1.5);
        assertFalse(juego.getEfectosJugador2().tieneEfectoActivo());
        assertEquals(0, juego.getJugador2().getDireccionEmpuje());
    }

    @Test
    public void muerteImpideAccionesYLaVidaSeRecuperaDuranteElPartido()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 5));
        juego.iniciarPartido();
        Jugador azul = juego.getJugador1();
        azul.recibirDanio(100);
        assertFalse(juego.patadaJugador1());
        assertFalse(juego.lanzarPoderJugador1());
        juego.moverJugador1Derecha();
        juego.saltarJugador1();
        juego.actualizar(2.9);
        assertFalse(azul.estaVivo());
        juego.actualizar(0.1);
        assertTrue(azul.estaVivo());
        assertEquals(100, azul.getVidaActual());
    }
}
