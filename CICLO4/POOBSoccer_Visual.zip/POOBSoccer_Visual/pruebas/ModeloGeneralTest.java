package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import juego.*;

/**
 * Comprueba configuracion, personajes, atributos y marcador.
 *
 * Diccionario de atributos:
 * cancha: campo de referencia para limites y dimensiones.
 * estadisticas: atributos probados en sus valores minimo y maximo.
 */
public class ModeloGeneralTest
{
    @Test
    public void laCanchaCalculaLasDosPorteriasYElAreaDeGol()
    {
        Cancha cancha = new Cancha(1000, 500, "1000x500");

        assertEquals(1000, cancha.getAncho());
        assertEquals(500, cancha.getAlto());
        assertEquals(500, cancha.getSueloY());
        assertEquals(60, cancha.getAnchoPorteria());
        assertEquals(140, cancha.getAltoPorteria());
        assertEquals(0, cancha.getPosicionPorteriaIzquierda());
        assertEquals(940, cancha.getPosicionPorteriaDerecha());
        assertEquals(360, cancha.getPosicionPorteriaY());
        assertEquals(10, cancha.getGrosorTravesano());
        assertTrue(cancha.estaDentroHorizontal(0));
        assertTrue(cancha.estaDentroHorizontal(1000));
        assertFalse(cancha.estaDentroHorizontal(-1));
        assertTrue(cancha.estaDentroVertical(500));
        assertFalse(cancha.estaDentroVertical(501));
        assertTrue(cancha.estaEnZonaPorteria(400));
        assertFalse(cancha.estaEnZonaPorteria(350));
        assertTrue(cancha.estaEnAberturaPorteria(390, 20));
        assertFalse(cancha.estaEnAberturaPorteria(370, 20));
        assertFalse(cancha.estaEnAberturaPorteria(480, 21));
        assertFalse(cancha.estaEnAberturaPorteria(400, 0));
    }

    @Test
    public void rechazaCanchaSinDimensionesORresolucion()
    {
        assertThrows(IllegalArgumentException.class,
            () -> new Cancha(120, 300, "120x300"));
        assertThrows(IllegalArgumentException.class,
            () -> new Cancha(300, 100, "300x100"));
        assertThrows(IllegalArgumentException.class,
            () -> new Cancha(300, 200, " "));
        assertThrows(IllegalArgumentException.class,
            () -> new Cancha(300, 200, null));
    }

    @Test
    public void laConfiguracionDistingueFinalPorTiempoYPorGoles()
    {
        ConfiguracionPartido tiempo = new ConfiguracionPartido(
            "TIEMPO", 90, 5, ModoPartida.JUGADOR_VS_MAQUINA,
            PerfilMaquina.EXPERTA);
        ConfiguracionPartido goles = new ConfiguracionPartido(
            "GOLES", 60, 7);

        assertTrue(tiempo.esPorTiempo());
        assertFalse(tiempo.esPorGoles());
        assertEquals(90, tiempo.getTiempoLimite());
        assertEquals(ModoPartida.JUGADOR_VS_MAQUINA, tiempo.getModo());
        assertEquals(PerfilMaquina.EXPERTA, tiempo.getPerfilMaquina());
        assertTrue(goles.esPorGoles());
        assertFalse(goles.esPorTiempo());
        assertEquals(ModoPartida.JUGADOR_VS_JUGADOR, goles.getModo());
        assertEquals(7, goles.getGolesParaGanar());
    }

    @Test
    public void laConfiguracionRechazaDatosInvalidos()
    {
        assertThrows(IllegalArgumentException.class,
            () -> new ConfiguracionPartido("RONDAS", 60, 5));
        assertThrows(IllegalArgumentException.class,
            () -> new ConfiguracionPartido(null, 60, 5));
        assertThrows(IllegalArgumentException.class,
            () -> new ConfiguracionPartido("TIEMPO", 0, 5));
        assertThrows(IllegalArgumentException.class,
            () -> new ConfiguracionPartido("GOLES", 60, 0));
        assertThrows(IllegalArgumentException.class,
            () -> new ConfiguracionPartido("GOLES", 60, 5, null,
                PerfilMaquina.OFENSIVA));
        assertThrows(IllegalArgumentException.class,
            () -> new ConfiguracionPartido("GOLES", 60, 5,
                ModoPartida.JUGADOR_VS_MAQUINA, null));
    }

    @Test
    public void cadaAtributoTieneSuNombreYSePuedeConsultarYMejorar()
    {
        Estadisticas estadisticas = new Estadisticas();
        assertEquals("Speed", AtributoJugador.SPEED.toString());
        assertEquals("Kick", AtributoJugador.KICK.toString());
        assertEquals("Jump", AtributoJugador.JUMP.toString());
        assertEquals("Survival", AtributoJugador.SURVIVAL.toString());
        assertEquals(1, estadisticas.getValor(AtributoJugador.SPEED));

        for (AtributoJugador atributo : AtributoJugador.values()) {
            assertTrue(estadisticas.mejorar(atributo));
            assertEquals(2, estadisticas.getValor(atributo));
        }
        assertThrows(IllegalArgumentException.class,
            () -> estadisticas.getValor(null));
        assertThrows(IllegalArgumentException.class,
            () -> estadisticas.mejorar(null));
        assertThrows(IllegalArgumentException.class,
            () -> new Estadisticas(0, 1, 1, 1));
        assertThrows(IllegalArgumentException.class,
            () -> new Estadisticas(1, 11, 1, 1));
    }

    @Test
    public void lasHabilidadesRespetanElLimiteYCalculanMultiplicadores()
    {
        Estadisticas estadisticas = new Estadisticas(10, 10, 10, 10);

        assertEquals(1.9, estadisticas.getMultiplicadorSpeed(), 0.0001);
        assertEquals(1.9, estadisticas.getMultiplicadorKick(), 0.0001);
        assertEquals(1.9, estadisticas.getMultiplicadorJump(), 0.0001);
        assertEquals(1.9, estadisticas.getMultiplicadorSurvival(), 0.0001);
        assertEquals(190, estadisticas.getVidaMaxima());
        assertFalse(estadisticas.mejorarSpeed());
        assertFalse(estadisticas.mejorarKick());
        assertFalse(estadisticas.mejorarJump());
        assertFalse(estadisticas.mejorarSurvival());
        for (AtributoJugador atributo : AtributoJugador.values()) {
            assertFalse(estadisticas.mejorar(atributo));
        }
    }

    @Test
    public void losPersonajesValidanDatosYConservanSuPoder()
    {
        Poder poder = new Rayo();
        Personaje personaje = new Personaje(
            "Camerún", "Rayo", "rayo.png", poder);
        Personaje sencillo = new Personaje("Nigeria", "Tornado", "tornado.png");

        assertEquals("Camerún", personaje.getPais());
        assertEquals("Rayo", personaje.getNombre());
        assertEquals("rayo.png", personaje.getImagen());
        assertSame(poder, personaje.getPoder());
        assertNull(sencillo.getPoder());
        assertThrows(IllegalArgumentException.class,
            () -> new Personaje(" ", "Nombre", "img.png"));
        assertThrows(IllegalArgumentException.class,
            () -> new Personaje("Pais", null, "img.png"));
        assertThrows(IllegalArgumentException.class,
            () -> new Personaje("Pais", "Nombre", ""));
    }

    @Test
    public void elMarcadorSumaDetectaEmpateYSeReinicia()
    {
        Marcador marcador = new Marcador();
        assertTrue(marcador.estaEmpatado());
        marcador.anotarGolJugador1();
        assertFalse(marcador.estaEmpatado());
        marcador.anotarGolJugador2();
        assertTrue(marcador.estaEmpatado());
        marcador.anotarGolJugador2();
        assertEquals(1, marcador.getGolesJugador1());
        assertEquals(2, marcador.getGolesJugador2());
        marcador.reiniciar();
        assertEquals(0, marcador.getGolesJugador1());
        assertEquals(0, marcador.getGolesJugador2());
    }

    @Test
    public void losEnumeradosPresentanSusOpcionesLegibles()
    {
        assertEquals("Jugador contra jugador",
            ModoPartida.JUGADOR_VS_JUGADOR.toString());
        assertEquals("Jugador contra maquina",
            ModoPartida.JUGADOR_VS_MAQUINA.toString());
        assertEquals(2, ModoPartida.values().length);
        assertEquals(4, PerfilMaquina.values().length);
    }
}
