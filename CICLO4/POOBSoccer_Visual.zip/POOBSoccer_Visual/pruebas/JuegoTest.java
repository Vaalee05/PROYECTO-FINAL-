package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import juego.*;

/**
 * Pruebas de las reglas centrales del partido.
 *
 * Diccionario de atributos:
 * juego: partido de prueba con dos participantes.
 */
public class JuegoTest
{
    private Juego crearJuego()
    {
        Jugador uno = new Jugador("Azul",
            FabricaPersonajes.crear(0), new Estadisticas());
        Jugador dos = new Jugador("Rojo",
            FabricaPersonajes.crear(1), new Estadisticas());
        return new Juego(uno, dos, new Cancha(800, 400, "800x400"));
    }

    @Test
    public void laBarraSeLlenaEnDiezSegundosYActivaElAura()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5));
        juego.iniciarPartido();

        assertFalse(juego.tieneAuraJugador1());
        assertEquals(0.0, juego.getCargaPoderJugador1(), 0.0001);
        assertFalse(juego.lanzarPoderJugador1());
        juego.actualizar(10.0);

        assertEquals(1.0, juego.getCargaPoderJugador1(), 0.0001);
        assertTrue(juego.lanzarPoderJugador1());
        assertTrue(juego.tieneAuraJugador1());
        assertEquals(0.0, juego.getCargaPoderJugador1(), 0.0001);
    }

    @Test
    public void elGolCargaUnCuartoLaBarraDelJugadorAfectado()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5));
        juego.iniciarPartido();

        juego.anotarGolJugador1();

        assertEquals(0.25, juego.getCargaPoderJugador2(), 0.0001);
    }

    @Test
    public void elTiroEspecialSeActivaAlPatearElBalon()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5));
        juego.iniciarPartido();
        juego.actualizar(10.0);
        assertTrue(juego.lanzarPoderJugador1());

        Jugador jugador = juego.getJugador1();
        juego.getBalon().reiniciar(
            jugador.getX() + 25, jugador.getY() + 5);
        assertTrue(juego.patadaJugador1());

        assertFalse(juego.tieneAuraJugador1());
        assertEquals(19, juego.getBalon().getVx());
        assertTrue(juego.getPoderEnVuelo() instanceof AuraAzul);
    }

    @Test
    public void elContactoDelCuerpoTambienDisparaElPoderActivo()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5));
        juego.iniciarPartido();
        juego.actualizar(10.0);
        assertTrue(juego.lanzarPoderJugador1());

        Jugador jugador = juego.getJugador1();
        juego.getBalon().reiniciar(jugador.getX(), jugador.getY() - 36);
        juego.actualizar();

        assertFalse(juego.tieneAuraJugador1());
        assertEquals(19, juego.getBalon().getVx());
    }

    @Test
    public void elDanoDelPoderAplicaLaEscalaYKick()
    {
        Jugador atacante = new Jugador("Camerun",
            FabricaPersonajes.crear(1), new Estadisticas(1, 5, 1, 1));
        Jugador objetivo = new Jugador("Rival",
            FabricaPersonajes.crear(0), new Estadisticas());
        AdministradorEfectos efectos = new AdministradorEfectos(objetivo);

        new Rayo().aplicar(atacante, objetivo, efectos);

        assertEquals(16, objetivo.getVidaActual());
        assertTrue(objetivo.isElectrocutado());
    }

    @Test
    public void cadaPaisTieneElPoderYLosValoresDelAnexo()
    {
        Personaje corea = FabricaPersonajes.crear(0);
        Personaje camerun = FabricaPersonajes.crear(1);
        Personaje nigeria = FabricaPersonajes.crear(2);
        Personaje estadosUnidos = FabricaPersonajes.crear(3);

        assertEquals("Corea del Sur", corea.getPais());
        assertTrue(corea.getPoder() instanceof AuraAzul);
        assertEquals(8, corea.getPoder().getDanoBase());
        assertEquals(1.5, corea.getPoder().getDuracion(), 0.001);
        assertTrue(((PoderBase) corea.getPoder()).getEfecto()
            instanceof Empuje);
        assertEquals(60, vidaTrasImpacto(corea.getPoder()));

        assertEquals("Camerún", camerun.getPais());
        assertTrue(camerun.getPoder() instanceof Rayo);
        assertEquals(12, camerun.getPoder().getDanoBase());
        assertEquals(3.0, camerun.getPoder().getDuracion(), 0.001);
        assertTrue(((PoderBase) camerun.getPoder()).getEfecto()
            instanceof Electrocutado);
        assertEquals(40, vidaTrasImpacto(camerun.getPoder()));

        assertEquals("Nigeria", nigeria.getPais());
        assertTrue(nigeria.getPoder() instanceof Tornado);
        assertEquals(8, nigeria.getPoder().getDanoBase());
        assertEquals(3.0, nigeria.getPoder().getDuracion(), 0.001);
        assertTrue(((PoderBase) nigeria.getPoder()).getEfecto()
            instanceof Inconsciente);
        assertEquals(60, vidaTrasImpacto(nigeria.getPoder()));

        assertEquals("Estados Unidos", estadosUnidos.getPais());
        assertTrue(estadosUnidos.getPoder() instanceof Ilusion);
        assertEquals(6, estadosUnidos.getPoder().getDanoBase());
        assertEquals(2.5, estadosUnidos.getPoder().getDuracion(), 0.001);
        assertTrue(((PoderBase) estadosUnidos.getPoder()).getEfecto()
            instanceof Confusion);
        assertEquals(70, vidaTrasImpacto(estadosUnidos.getPoder()));
    }

    private int vidaTrasImpacto(Poder poder)
    {
        Jugador atacante = new Jugador("Atacante",
            new Personaje("Pais", "Personaje", "jugador.png", poder),
            new Estadisticas());
        Jugador objetivo = new Jugador("Objetivo",
            FabricaPersonajes.crear(0), new Estadisticas());
        poder.aplicar(atacante, objetivo,
            new AdministradorEfectos(objetivo));
        return objetivo.getVidaActual();
    }

    @Test
    public void ilusionDivideElBalonDesdeQueSaleElTiro()
    {
        Jugador uno = new Jugador("USA", FabricaPersonajes.crear(3),
            new Estadisticas());
        Jugador dos = new Jugador("Rival", FabricaPersonajes.crear(0),
            new Estadisticas());
        Juego juego = new Juego(uno, dos, new Cancha(800, 400, "800x400"));
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 5));
        juego.iniciarPartido();
        juego.actualizar(10.0);
        assertTrue(juego.lanzarPoderJugador1());
        juego.getBalon().reiniciar(uno.getX(), uno.getY() - 36);

        juego.actualizar();

        assertEquals(7, juego.getBalonesFantasma().size());
        assertTrue(juego.getPoderEnVuelo() instanceof Ilusion);
    }

    @Test
    public void elBalonQueNoPasaCompletoBajoElTravesanoNoEsGol()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 5));
        juego.iniciarPartido();
        int y = juego.getCancha().getPosicionPorteriaY() + 8;
        juego.getBalon().reiniciar(-16, y);
        juego.getBalon().setVelocidad(-5, 0);

        juego.actualizar();

        assertEquals(0, juego.getMarcador().getGolesJugador2());
        assertTrue(juego.getBalon().getVx() > 0);
    }

    @Test
    public void elBalonQueCabeBajoElTravesanoSiPuedeSerGol()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido("GOLES", 60, 5));
        juego.iniciarPartido();
        int y = juego.getCancha().getPosicionPorteriaY() + 30;
        juego.getBalon().reiniciar(-16, y);
        juego.getBalon().setVelocidad(-5, 0);

        juego.actualizar();

        assertEquals(1, juego.getMarcador().getGolesJugador2());
    }

    @Test
    public void unaMejoraDuplicaElSiguienteCosto()
    {
        ProgresoJugador perfil = new ProgresoJugador();
        perfil.establecer(new Estadisticas(), 1500, 500);

        assertTrue(perfil.mejorar(AtributoJugador.KICK));
        assertEquals(1000, perfil.getPuntos());
        assertEquals(1000, perfil.getCostoSiguienteMejora());
        assertEquals(2, perfil.getEstadisticas().getKick());
    }

    @Test
    public void elPerfilMaquinaOfensivoPersigueElBalon()
    {
        Juego juego = crearJuego();
        juego.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5, ModoPartida.JUGADOR_VS_MAQUINA,
            PerfilMaquina.OFENSIVA));
        juego.iniciarPartido();
        int xInicial = juego.getJugador2().getX();

        juego.actualizar();

        assertTrue(juego.getJugador2().getX() < xInicial);
    }
}
