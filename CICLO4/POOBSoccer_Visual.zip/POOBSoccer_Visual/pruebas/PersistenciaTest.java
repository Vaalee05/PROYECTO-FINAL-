package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import juego.*;

/**
 * Comprueba el guardado y la recuperacion de perfiles y partidos.
 *
 * Diccionario de atributos:
 * carpeta: directorio temporal aislado para los archivos de la prueba.
 * repositorio: servicio de perfiles que se prueba.
 */
public class PersistenciaTest
{
    @TempDir
    Path carpeta;

    @Test
    public void elProgresoSeGuardaSeActualizaYSeAíslaPorJugador()
        throws Exception
    {
        File archivo = carpeta.resolve("perfiles/progreso.properties").toFile();
        RepositorioProgreso repositorio = new RepositorioProgreso(archivo);
        ProgresoJugador inicial = repositorio.cargar("  Ángela  ");
        assertEquals(0, inicial.getPuntos());
        assertEquals(1, inicial.getEstadisticas().getSpeed());

        inicial.establecer(new Estadisticas(3, 4, 2, 5), 1500, 1000);
        repositorio.guardar("  Ángela  ", inicial);
        repositorio.guardar("Luis", new ProgresoJugador());
        ProgresoJugador recuperado = repositorio.cargar("ángela");
        assertEquals(3, recuperado.getEstadisticas().getSpeed());
        assertEquals(4, recuperado.getEstadisticas().getKick());
        assertEquals(2, recuperado.getEstadisticas().getJump());
        assertEquals(5, recuperado.getEstadisticas().getSurvival());
        assertEquals(1500, recuperado.getPuntos());
        assertEquals(1000, recuperado.getCostoSiguienteMejora());
        assertEquals(0, repositorio.cargar("Luis").getPuntos());

        repositorio.guardarJugador("Luis", new Estadisticas(2, 1, 3, 1), 700);
        assertEquals(700, repositorio.cargar("Luis").getPuntos());
        assertEquals(2, repositorio.cargar("Luis")
            .getEstadisticas().getSpeed());
        assertTrue(archivo.isFile());
    }

    @Test
    public void elRepositorioRechazaNombresYPerfilesInvalidos()
    {
        RepositorioProgreso repositorio = new RepositorioProgreso(
            carpeta.resolve("progreso.properties").toFile());
        ProgresoJugador perfil = new ProgresoJugador();
        assertThrows(ErrorJuegoException.class,
            () -> repositorio.cargar(" "));
        assertThrows(ErrorJuegoException.class,
            () -> repositorio.guardar(null, perfil));
        assertThrows(ErrorJuegoException.class,
            () -> repositorio.guardar("jugador", null));
        assertThrows(IllegalArgumentException.class,
            () -> perfil.establecer(null, 100, 500));
        assertThrows(IllegalArgumentException.class,
            () -> perfil.establecer(new Estadisticas(), -1, 500));
        assertThrows(IllegalArgumentException.class,
            () -> perfil.establecer(new Estadisticas(), 1, 499));
        assertThrows(IllegalArgumentException.class,
            () -> perfil.agregarPuntos(-1));
    }

    @Test
    public void elPartidoSeGuardaYSeRecuperaConSuMarcador()
        throws Exception
    {
        Juego original = crearJuego();
        original.setConfiguracion(new ConfiguracionPartido(
            "GOLES", 60, 5, ModoPartida.JUGADOR_VS_MAQUINA,
            PerfilMaquina.DEFENSIVA));
        original.iniciarPartido();
        original.anotarGolJugador1();
        File destino = carpeta.resolve("guardados/partida.dopo").toFile();

        ServicioPartidas.guardar(original, destino);
        Juego recuperado = ServicioPartidas.abrir(destino);

        assertTrue(destino.isFile());
        assertEquals(1, recuperado.getMarcador().getGolesJugador1());
        assertEquals(0, recuperado.getMarcador().getGolesJugador2());
        assertEquals("Azul", recuperado.getJugador1().getNombre());
        assertEquals(PerfilMaquina.DEFENSIVA,
            recuperado.getPerfilMaquina());
        assertTrue(recuperado.isPartidoActivo());
        assertEquals(400, recuperado.getBalon().getX());
    }

    @Test
    public void unaPartidaRecuperadaConservaFisicaYPuedeContinuar()
        throws Exception
    {
        Juego original = crearJuego();
        original.iniciarPartido();
        original.actualizar(10.0);
        original.getBalon().setVelocidad(8, -3);
        original.getEfectosJugador1().activar(new Electrocutado());

        File destino = carpeta.resolve("guardados/partida-activa.dopo")
            .toFile();
        ServicioPartidas.guardar(original, destino);

        Juego recuperado = ServicioPartidas.abrir(destino);
        recuperado.restaurarDespuesDeCarga();

        assertTrue(recuperado.isPartidoActivo());
        assertEquals(8, recuperado.getBalon().getVx());
        assertTrue(recuperado.getJugador1().isElectrocutado());

        int posicionAnterior = recuperado.getBalon().getX();
        recuperado.actualizar(0.1);
        assertNotEquals(posicionAnterior, recuperado.getBalon().getX());

        // La carga de poder y el poder del personaje siguen disponibles.
        assertTrue(recuperado.lanzarPoderJugador1());
    }

    @Test
    public void elServicioDePartidasRechazaArchivosInvalidos()
        throws Exception
    {
        Path archivoTexto = carpeta.resolve("no-es-partida.dopo");
        try (ObjectOutputStream salida = new ObjectOutputStream(
                Files.newOutputStream(archivoTexto))) {
            salida.writeObject("contenido ajeno");
        }
        assertThrows(ErrorJuegoException.class,
            () -> ServicioPartidas.abrir(archivoTexto.toFile()));
        assertThrows(ErrorJuegoException.class,
            () -> ServicioPartidas.abrir(carpeta.resolve("no-existe.dopo")
                .toFile()));
        assertThrows(ErrorJuegoException.class,
            () -> ServicioPartidas.guardar(null,
                carpeta.resolve("vacio.dopo").toFile()));
        assertThrows(ErrorJuegoException.class,
            () -> ServicioPartidas.guardar(crearJuego(), null));
    }

    @Test
    public void excepcionDelJuegoConservaLaCausa()
    {
        Exception causa = new IllegalStateException("detalle");
        ErrorJuegoException conCausa = new ErrorJuegoException("mensaje", causa);
        ErrorJuegoException sencillo = new ErrorJuegoException("otro");
        assertEquals("mensaje", conCausa.getMessage());
        assertSame(causa, conCausa.getCause());
        assertEquals("otro", sencillo.getMessage());
        assertNull(sencillo.getCause());
    }

    private Juego crearJuego()
    {
        return new Juego(
            new Jugador("Azul", FabricaPersonajes.crear(0),
                new Estadisticas()),
            new Jugador("Rojo", FabricaPersonajes.crear(1),
                new Estadisticas()),
            new Cancha(800, 400, "800x400")
        );
    }
}
