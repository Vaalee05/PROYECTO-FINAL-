package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import java.awt.Color;
import java.awt.Component;
import java.awt.Container;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.image.BufferedImage;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.atomic.AtomicInteger;
import javax.swing.JButton;
import javax.swing.JLabel;
import org.junit.jupiter.api.Test;
import interfaz.PantallaInicio;

/**
 * Prueba la composicion, pintura y acciones de la portada.
 *
 * Diccionario de atributos:
 * pantalla: panel inicial que se pinta fuera de una ventana.
 * inicio: contador de veces que se solicita comenzar.
 * salida: contador de veces que se solicita cerrar.
 */
public class PantallaInicioTest
{
    @Test
    public void muestraMarcaEquiposControlesYAcciones()
    {
        AtomicInteger inicios = new AtomicInteger();
        AtomicInteger salidas = new AtomicInteger();
        PantallaInicio pantalla = new PantallaInicio(
            inicios::incrementAndGet, salidas::incrementAndGet);
        List<String> textos = new ArrayList<>();
        recolectarTextos(pantalla, textos);

        assertTrue(textos.contains("DOPOSOCCER"));
        assertTrue(textos.contains("EL PARTIDO EMPIEZA AQUÍ"));
        assertTrue(textos.contains("TEMPORADA 2026  ·  VERSIÓN 3"));
        assertTrue(textos.stream().anyMatch(t -> t.contains("P1:")));
        assertEquals("INICIAR JUEGO  ›",
            pantalla.getBotonIniciar().getText());
        assertEquals("Salir del juego", pantalla.getBotonSalir().getText());
        assertEquals("Jugador 1, uniforme azul",
            buscarTooltip(pantalla, "Jugador 1, uniforme azul"));
        assertEquals("Jugador 2, uniforme rojo",
            buscarTooltip(pantalla, "Jugador 2, uniforme rojo"));

        pantalla.getBotonIniciar().doClick();
        pantalla.getBotonSalir().doClick();
        assertEquals(1, inicios.get());
        assertEquals(1, salidas.get());
    }

    @Test
    public void laPortadaPintaElFondoYLaTarjetaLegible()
    {
        PantallaInicio pantalla = new PantallaInicio(() -> { }, () -> { });
        pantalla.setSize(1080, 680);
        acomodar(pantalla);
        BufferedImage imagen = new BufferedImage(1080, 680,
            BufferedImage.TYPE_INT_ARGB);
        Graphics2D g = imagen.createGraphics();
        pantalla.paint(g);
        g.dispose();

        assertNotEquals(0, imagen.getRGB(10, 10));
        assertNotEquals(0, imagen.getRGB(540, 340));
        assertTrue(pantalla.getBotonIniciar().getWidth() > 0);
        assertTrue(pantalla.getBotonSalir().getWidth() > 0);
    }

    @Test
    public void elBotonPrincipalCambiaAlPasarElCursor()
    {
        PantallaInicio pantalla = new PantallaInicio(() -> { }, () -> { });
        JButton boton = pantalla.getBotonIniciar();
        assertEquals(new Color(57, 201, 104), boton.getBackground());
        MouseEvent entrada = new MouseEvent(boton, MouseEvent.MOUSE_ENTERED,
            System.currentTimeMillis(), 0, 1, 1, 0, false);
        for (MouseListener escucha : boton.getMouseListeners()) {
            escucha.mouseEntered(entrada);
        }
        assertEquals(new Color(91, 226, 132), boton.getBackground());

        MouseEvent salida = new MouseEvent(boton, MouseEvent.MOUSE_EXITED,
            System.currentTimeMillis(), 0, 1, 1, 0, false);
        for (MouseListener escucha : boton.getMouseListeners()) {
            escucha.mouseExited(salida);
        }
        assertEquals(new Color(57, 201, 104), boton.getBackground());
    }

    @Test
    public void laPortadaRequiereAccionesDeNavegacion()
    {
        assertThrows(IllegalArgumentException.class,
            () -> new PantallaInicio(null, () -> { }));
        assertThrows(IllegalArgumentException.class,
            () -> new PantallaInicio(() -> { }, null));
    }

    private void acomodar(Container panel)
    {
        panel.doLayout();
        for (Component componente : panel.getComponents()) {
            if (componente instanceof Container) {
                acomodar((Container) componente);
            }
        }
    }

    private void recolectarTextos(Container panel, List<String> textos)
    {
        for (Component componente : panel.getComponents()) {
            if (componente instanceof JLabel) {
                textos.add(((JLabel) componente).getText());
            }
            if (componente instanceof JButton) {
                textos.add(((JButton) componente).getText());
            }
            if (componente instanceof Container) {
                recolectarTextos((Container) componente, textos);
            }
        }
    }

    private String buscarTooltip(Container panel, String valor)
    {
        for (Component componente : panel.getComponents()) {
            if (componente instanceof javax.swing.JComponent
                && valor.equals(((javax.swing.JComponent) componente)
                    .getToolTipText())) {
                return valor;
            }
            if (componente instanceof Container) {
                String encontrado = buscarTooltip((Container) componente, valor);
                if (encontrado != null) {
                    return encontrado;
                }
            }
        }
        return null;
    }
}
