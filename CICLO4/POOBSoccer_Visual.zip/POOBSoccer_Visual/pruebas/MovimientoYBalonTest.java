package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import juego.*;

/**
 * Cubre movimiento, colisiones, patadas y estrategias de la maquina.
 *
 * Diccionario de atributos:
 * cancha: dimensiones empleadas para resolver rebotes.
 * jugador: personaje usado como atacante o rival.
 * balon: objeto cuya trayectoria se comprueba.
 */
public class MovimientoYBalonTest
{
    private Cancha crearCancha()
    {
        return new Cancha(800, 400, "800x400");
    }

    private Jugador crearJugador(int seleccion)
    {
        return new Jugador("Jugador", FabricaPersonajes.crear(seleccion),
            new Estadisticas());
    }

    @Test
    public void elBalonRebotaEnTechoSueloYLaterales()
    {
        Cancha cancha = crearCancha();
        Balon lateral = new Balon(20, 200, 10);
        lateral.setVelocidad(-30, 0);
        lateral.actualizar(cancha);
        assertEquals(10, lateral.getX());
        assertTrue(lateral.getVx() > 0);

        Balon suelo = new Balon(200, 390, 10);
        suelo.setVelocidad(0, 8);
        suelo.actualizar(cancha);
        assertEquals(390, suelo.getY());
        assertTrue(suelo.getVy() < 0);

        Balon techo = new Balon(200, 10, 10);
        techo.setVelocidad(0, -5);
        techo.actualizar(cancha);
        assertEquals(10, techo.getY());
        assertTrue(techo.getVy() > 0);
    }

    @Test
    public void elBalonPermiteAjustarReiniciarYDetenerElMovimiento()
    {
        Balon balon = new Balon(10, 20, 15);
        assertEquals(15, balon.getRadio());
        assertThrows(IllegalArgumentException.class,
            () -> new Balon(0, 0, 0));
        assertThrows(IllegalArgumentException.class,
            () -> balon.setRebote(-0.1));
        assertThrows(IllegalArgumentException.class,
            () -> balon.setRebote(1.21));

        balon.setRebote(1.1);
        balon.setVelocidad(12, -4);
        balon.actualizar();
        assertEquals(22, balon.getX());
        assertEquals(16, balon.getY());
        balon.detener();
        assertEquals(0, balon.getVx());
        assertEquals(0, balon.getVy());
        balon.setVelocidad(7, 9);
        balon.reiniciar(300, 200);
        assertEquals(300, balon.getX());
        assertEquals(200, balon.getY());
        assertEquals(0, balon.getVx());
        assertEquals(0, balon.getVy());
    }

    @Test
    public void colisionConJugadorSeparaLosSpritesYReflejaElBalon()
    {
        Cancha cancha = crearCancha();
        Jugador jugador = crearJugador(0);
        jugador.establecerPosicion(300, 220);
        Balon balon = new Balon(300, 184, 15);

        assertTrue(balon.colisionarConJugador(jugador, cancha));
        assertTrue(balon.getVx() != 0 || balon.getVy() != 0);
        assertFalse(balon.colisionarConJugador(jugador, cancha));
        assertFalse(new Balon(500, 184, 15)
            .colisionarConJugador(jugador, cancha));
        assertThrows(IllegalArgumentException.class,
            () -> balon.colisionarConJugador(null, cancha));
        assertThrows(IllegalArgumentException.class,
            () -> balon.colisionarConJugador(jugador, null));
        assertThrows(IllegalArgumentException.class,
            () -> balon.actualizar((Cancha) null));
    }

    @Test
    public void laPatadaGolpeaElBalonAlRivalOMuestraQueNoLlega()
    {
        Patada patada = new Patada();
        Jugador atacante = crearJugador(0);
        Jugador rival = crearJugador(1);
        atacante.establecerPosicion(100, 200);
        rival.establecerPosicion(400, 200);
        Balon balon = new Balon(125, 205, 15);

        assertTrue(patada.ejecutar(atacante, rival, balon, 1));
        assertEquals(13, balon.getVx());
        assertEquals(-14, balon.getVy());

        balon.reiniciar(700, 50);
        rival.establecerPosicion(150, 205);
        assertTrue(patada.ejecutar(atacante, rival, balon, 1));
        assertEquals(90, rival.getVidaActual());

        rival.establecerPosicion(500, 300);
        assertFalse(patada.ejecutar(atacante, rival, balon, 1));
        assertThrows(IllegalArgumentException.class,
            () -> patada.ejecutar(null, rival, balon, 1));
        assertThrows(IllegalArgumentException.class,
            () -> patada.ejecutar(atacante, rival, balon, 0));
    }

    @Test
    public void elProyectilPuedeImpactarFallaryDesactivarse()
    {
        Jugador atacante = crearJugador(0);
        Jugador rival = crearJugador(1);
        atacante.establecerPosicion(100, 100);
        rival.establecerPosicion(160, 100);
        Proyectil proyectil = new Proyectil(atacante, rival,
            new Rayo(), 30);
        assertEquals(100, proyectil.getX());
        assertTrue(proyectil.isActivo());
        assertFalse(proyectil.comprobarImpacto());
        proyectil.actualizar();
        proyectil.actualizar();
        assertTrue(proyectil.comprobarImpacto());
        AdministradorEfectos efectos = new AdministradorEfectos(rival);
        assertTrue(proyectil.impactar(efectos));
        assertFalse(proyectil.isActivo());
        assertTrue(rival.isElectrocutado());
        assertFalse(proyectil.impactar(efectos));

        Proyectil sinImpacto = new Proyectil(atacante, rival,
            new AuraAzul(), 2);
        sinImpacto.desactivar();
        assertFalse(sinImpacto.isActivo());
        assertFalse(sinImpacto.comprobarImpacto());
        assertThrows(IllegalArgumentException.class,
            () -> new Proyectil(null, rival, new Rayo(), 2));
        assertThrows(IllegalArgumentException.class,
            () -> new Proyectil(atacante, atacante, new Rayo(), 2));
        assertThrows(IllegalArgumentException.class,
            () -> new Proyectil(atacante, rival, null, 2));
        assertThrows(IllegalArgumentException.class,
            () -> new Proyectil(atacante, rival, new Rayo(), 0));
        assertThrows(IllegalArgumentException.class,
            () -> sinImpacto.impactar(null));
    }

    @Test
    public void losBalonesFantasmasAvanzanRebotanYDesaparecen()
    {
        Cancha cancha = crearCancha();
        BalonFantasma fantasma = new BalonFantasma(100, 100, 3, 2, 0.5);
        fantasma.actualizar(0.1, cancha);
        assertEquals(118, fantasma.getX());
        assertEquals(112, fantasma.getY());
        assertEquals(0.4, fantasma.getVida(), 0.0001);
        assertTrue(fantasma.estaActivo());

        BalonFantasma techo = new BalonFantasma(100, 8, 0, -2, 1);
        techo.actualizar(0.1, cancha);
        assertEquals(12, techo.getY());
        BalonFantasma suelo = new BalonFantasma(100, 398, 0, 1, 1);
        suelo.actualizar(0.1, cancha);
        assertEquals(cancha.getSueloY() - 12, suelo.getY());

        fantasma.actualizar(1.0, cancha);
        assertFalse(fantasma.estaActivo());
        assertEquals(0.0, fantasma.getVida(), 0.0001);
    }

    @Test
    public void perfilesDeMaquinaEligenDireccionesYAlcancesDistintos()
    {
        Cancha cancha = crearCancha();
        Jugador jugador = crearJugador(0);
        Balon balon = new Balon(500, 100, 15);
        jugador.establecerPosicion(300, 220);

        assertEquals(1, PerfilMaquina.OFENSIVA
            .decidirDireccion(jugador, balon, cancha, 1));
        assertEquals(0, PerfilMaquina.OFENSIVA
            .decidirDireccion(jugador, new Balon(305, 100, 15), cancha, 1));
        assertEquals(1, PerfilMaquina.DEFENSIVA
            .decidirDireccion(jugador, new Balon(600, 100, 15), cancha, 1));
        assertEquals(1, PerfilMaquina.EXPERTA
            .decidirDireccion(jugador, balon, cancha, 1));
        assertEquals(112, PerfilMaquina.OFENSIVA.alcancePatada());
        assertEquals(88, PerfilMaquina.DEFENSIVA.alcancePatada());
        assertEquals(125, PerfilMaquina.EXPERTA.alcancePatada());
        assertEquals(58, PerfilMaquina.TORPE.alcancePatada());
        for (int i = 0; i < 100; i++) {
            int direccion = PerfilMaquina.TORPE
                .decidirDireccion(jugador, balon, cancha, i);
            assertTrue(direccion >= -1 && direccion <= 1);
        }

        assertTrue(PerfilMaquina.OFENSIVA.debeSaltar(jugador,
            new Balon(310, 150, 15)));
        jugador.saltar();
        assertFalse(PerfilMaquina.OFENSIVA.debeSaltar(jugador,
            new Balon(310, 150, 15)));
        assertFalse(PerfilMaquina.OFENSIVA.debeSaltar(jugador,
            new Balon(600, 100, 15)));
    }
}
