package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import java.io.File;
import java.nio.file.Files;
import java.nio.file.Path;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.io.TempDir;
import juego.RegistroErrores;

/**
 * Comprueba el registro de mensajes sin escribir archivos de prueba al juego.
 *
 * Diccionario de atributos:
 * carpeta: directorio temporal para los registros de esta suite.
 */
public class RegistroErroresTest
{
    @TempDir
    Path carpeta;

    @AfterEach
    public void restaurarDestino()
    {
        RegistroErrores.configurarArchivo(
            new File("datos/logs/doposoccer.log"));
    }

    @Test
    public void guardaMensajesNormalesYExcepciones()
        throws Exception
    {
        Path archivo = carpeta.resolve("logs/errores.log");
        RegistroErrores.configurarArchivo(archivo.toFile());
        RegistroErrores.registrar("mensaje simple", null);
        RegistroErrores.registrar("mensaje con error",
            new IllegalStateException("detalle de prueba"));
        RegistroErrores.configurarArchivo(
            new File("datos/logs/doposoccer.log"));

        String contenido = Files.readString(archivo);
        assertTrue(contenido.contains("mensaje simple"));
        assertTrue(contenido.contains("mensaje con error"));
        assertTrue(contenido.contains("detalle de prueba"));
    }

    @Test
    public void manejaUnaRutaSinPermisoDeEscritura()
        throws Exception
    {
        File bloqueador = carpeta.resolve("archivo").toFile();
        Files.writeString(bloqueador.toPath(), "no es una carpeta");
        File destino = new File(bloqueador, "errores.log");
        RegistroErrores.configurarArchivo(destino);

        assertDoesNotThrow(() -> RegistroErrores.registrar(
            "no se pudo abrir el destino", null));
        assertFalse(destino.exists());
        assertThrows(IllegalArgumentException.class,
            () -> RegistroErrores.configurarArchivo(null));
    }
}
