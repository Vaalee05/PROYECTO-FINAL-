package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import juego.*;

/** Pruebas de colision del balon con los travesanos de los arcos. */
public class BalonTest
{
    @Test
    public void elTravesanoSuperiorDevuelveElBalonAlCampo()
    {
        Cancha cancha = new Cancha(800, 400, "800x400");
        int travesano = cancha.getPosicionPorteriaY();
        Balon balon = new Balon(30, travesano - 25, 15);
        balon.setVelocidad(0, 8);

        balon.actualizar(cancha);

        assertTrue(balon.getY() < travesano - balon.getRadio());
        assertTrue(balon.getVy() < 0);
        assertFalse(cancha.estaEnAberturaPorteria(
            balon.getY(), balon.getRadio()));
    }
}
