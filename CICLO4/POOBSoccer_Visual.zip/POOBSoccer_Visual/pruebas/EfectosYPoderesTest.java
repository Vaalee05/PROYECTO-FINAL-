package pruebas;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.Test;
import juego.*;

/**
 * Verifica la duracion de efectos y el comportamiento de los cuatro poderes.
 *
 * Diccionario de atributos:
 * rival: jugador que recibe daño y efectos.
 * atacante: jugador que lanza cada poder especial.
 * administrador: ciclo de vida del efecto aplicado al rival.
 */
public class EfectosYPoderesTest
{
    @Test
    public void administradorRechazaEfectosInvalidosYTiempoNegativo()
    {
        Jugador rival = jugador(0);
        assertThrows(IllegalArgumentException.class,
            () -> new AdministradorEfectos(null));
        AdministradorEfectos administrador =
            new AdministradorEfectos(rival);
        assertThrows(IllegalArgumentException.class,
            () -> administrador.activar(null));
        assertThrows(IllegalArgumentException.class,
            () -> administrador.activar(new EfectoSinDuracion()));
        assertThrows(IllegalArgumentException.class,
            () -> administrador.actualizar(-0.1));
        assertFalse(administrador.tieneEfectoActivo());
        assertNull(administrador.getEfectoActivo());
    }

    @Test
    public void administradorReemplazaActualizaYFinalizaElEfecto()
    {
        Jugador rival = jugador(0);
        AdministradorEfectos administrador =
            new AdministradorEfectos(rival);
        Electrocutado rayo = new Electrocutado();
        Confusion ilusion = new Confusion();

        administrador.activar(rayo);
        assertTrue(rival.isElectrocutado());
        administrador.actualizar(1.25);
        assertEquals(1.25, administrador.getTiempoTranscurrido(), 0.0001);
        administrador.activar(ilusion);
        assertFalse(rival.isElectrocutado());
        assertTrue(rival.isConfundido());
        assertSame(ilusion, administrador.getEfectoActivo());
        administrador.actualizar(2.49);
        assertTrue(administrador.tieneEfectoActivo());
        administrador.actualizar(0.01);
        assertFalse(administrador.tieneEfectoActivo());
        assertFalse(rival.isConfundido());
        assertEquals(0.0, administrador.getTiempoTranscurrido(), 0.0001);
        administrador.finalizar();
    }

    @Test
    public void cadaEfectoActivaYDesactivaElEstadoCorrespondiente()
    {
        Jugador rival = jugador(0);
        Empuje empuje = new Empuje();
        Electrocutado electrocutado = new Electrocutado();
        Inconsciente inconsciente = new Inconsciente();
        Confusion confusion = new Confusion();

        assertEquals(1.5, empuje.getDuracion(), 0.001);
        empuje.iniciar(rival);
        rival.setDireccionEmpuje(1);
        assertTrue(rival.isEmpujado());
        empuje.finalizar(rival);
        assertFalse(rival.isEmpujado());
        assertEquals(0, rival.getDireccionEmpuje());

        assertEquals(3.0, electrocutado.getDuracion(), 0.001);
        electrocutado.iniciar(rival);
        assertTrue(rival.isElectrocutado());
        electrocutado.finalizar(rival);
        assertFalse(rival.isElectrocutado());

        inconsciente.iniciar(rival);
        assertTrue(rival.isInconsciente());
        assertTrue(rival.estaSaltando());
        inconsciente.finalizar(rival);
        assertFalse(rival.isInconsciente());

        assertEquals(2.5, confusion.getDuracion(), 0.001);
        assertEquals(8, confusion.getCantidadBalones());
        confusion.iniciar(rival);
        assertTrue(rival.isConfundido());
        confusion.finalizar(rival);
        assertFalse(rival.isConfundido());
    }

    @Test
    public void losCuatroPoderesPreparanUnaTrayectoriaPropia()
    {
        comprobarTrayectoria(new AuraAzul(), 19, -1, 0.88);
        comprobarTrayectoria(new Rayo(), 22, -2, 0.82);
        comprobarTrayectoria(new Tornado(), 15, -3, 1.05);
        comprobarTrayectoria(new Ilusion(), 17, -2, 0.92);
    }

    @Test
    public void losPoderesValidanLaDireccionYElBalon()
    {
        for (Poder poder : poderes()) {
            assertThrows(IllegalArgumentException.class,
                () -> poder.prepararDisparo(null, 1));
            assertThrows(IllegalArgumentException.class,
                () -> poder.prepararDisparo(new Balon(100, 100, 10), 0));
        }
    }

    @Test
    public void cadaPoderAplicaElDanoYElEfectoDelPais()
    {
        verificarImpacto(new AuraAzul(), 40, Empuje.class);
        verificarImpacto(new Rayo(), 60, Electrocutado.class);
        verificarImpacto(new Tornado(), 40, Inconsciente.class);
        verificarImpacto(new Ilusion(), 30, Confusion.class);
    }

    @Test
    public void losPoderesRechazanParticipantesNulos()
    {
        Jugador atacante = jugador(0);
        Jugador rival = jugador(1);
        AdministradorEfectos administrador =
            new AdministradorEfectos(rival);
        for (Poder poder : poderes()) {
            assertThrows(IllegalArgumentException.class,
                () -> poder.aplicar(null, rival, administrador));
            assertThrows(IllegalArgumentException.class,
                () -> poder.aplicar(atacante, null, administrador));
            assertThrows(IllegalArgumentException.class,
                () -> poder.aplicar(atacante, rival, null));
        }
    }

    @Test
    public void poderBaseValidaSusDatosYDisparaEnElSentidoIndicado()
    {
        PoderPrueba poder = new PoderPrueba("Prueba", 4, 1.0,
            new EfectoSinDuracion(1.0));
        Balon balon = new Balon(100, 100, 10);
        poder.prepararDisparo(balon, -1);
        assertEquals(-18, balon.getVx());
        assertEquals(-2, balon.getVy());
        assertEquals("Prueba", poder.getNombre());
        assertEquals(4, poder.getDanoBase());
        assertEquals(1.0, poder.getDuracion(), 0.0001);

        assertThrows(IllegalArgumentException.class,
            () -> new PoderPrueba("", 4, 1, new EfectoSinDuracion(1)));
        assertThrows(IllegalArgumentException.class,
            () -> new PoderPrueba("P", 0, 1, new EfectoSinDuracion(1)));
        assertThrows(IllegalArgumentException.class,
            () -> new PoderPrueba("P", 1, 0, new EfectoSinDuracion(1)));
        assertThrows(IllegalArgumentException.class,
            () -> new PoderPrueba("P", 1, 1, null));
        assertThrows(IllegalArgumentException.class,
            () -> new PoderPrueba("P", 1, 2, new EfectoSinDuracion(1)));
    }

    private void comprobarTrayectoria(Poder poder, int rapidez,
                                      int vertical, double rebote)
    {
        Balon balon = new Balon(200, 150, 12);
        poder.prepararDisparo(balon, 1);
        assertEquals(rapidez, balon.getVx());
        assertEquals(vertical, balon.getVy());
        balon.setVelocidad(0, 0);
        balon.actualizar(new Cancha(800, 400, "800x400"));
        assertEquals(0, balon.getVx());
        assertEquals(1, balon.getVy());
        poder.prepararDisparo(balon, -1);
        assertEquals(-rapidez, balon.getVx());
        assertEquals(vertical, balon.getVy());
    }

    private void verificarImpacto(Poder poder, int dano,
                                  Class<?> claseEfecto)
    {
        Jugador atacante = jugador(0);
        Jugador rival = jugador(1);
        AdministradorEfectos administrador =
            new AdministradorEfectos(rival);
        poder.aplicar(atacante, rival, administrador);
        assertEquals(100 - dano, rival.getVidaActual());
        assertTrue(administrador.tieneEfectoActivo());
        assertTrue(claseEfecto.isInstance(administrador.getEfectoActivo()));
    }

    private Poder[] poderes()
    {
        return new Poder[] {
            new AuraAzul(), new Rayo(), new Tornado(), new Ilusion()
        };
    }

    private Jugador jugador(int personaje)
    {
        return new Jugador("Jugador " + personaje,
            FabricaPersonajes.crear(personaje), new Estadisticas());
    }

    private static class EfectoSinDuracion implements Efecto
    {
        private final double duracion;

        private EfectoSinDuracion()
        {
            this(0.0);
        }

        private EfectoSinDuracion(double duracion)
        {
            this.duracion = duracion;
        }

        public void iniciar(Jugador objetivo) { }
        public void finalizar(Jugador objetivo) { }
        public double getDuracion() { return duracion; }
    }

    private static class PoderPrueba extends PoderBase
    {
        private PoderPrueba(String nombre, int dano, double duracion,
                            Efecto efecto)
        {
            super(nombre, dano, duracion, efecto);
        }

        public void aplicar(Jugador atacante, Jugador objetivo,
                            AdministradorEfectos administrador)
        {
            administrador.activar(getEfecto());
        }
    }
}
