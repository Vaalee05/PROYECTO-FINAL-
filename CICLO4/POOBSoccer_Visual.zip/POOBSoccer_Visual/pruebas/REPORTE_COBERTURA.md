# Reporte de pruebas y cobertura

**Proyecto:** DOPOSoccer, versión 3  
**Fecha:** 25 de noviembre de 2026  
**Resultado:** 69 pruebas aprobadas, 0 fallidas

## Cobertura del código de producción

Se midieron las clases de los paquetes `juego` e `interfaz`. Las clases de
prueba del paquete `pruebas` no forman parte del denominador.

| Paquete | Líneas cubiertas | Instrucciones cubiertas | Ramas cubiertas |
| --- | ---: | ---: | ---: |
| `juego` | 1212 / 1348 (**89,91 %**) | 4828 / 5428 (**88,95 %**) | 524 / 719 (**72,88 %**) |
| `interfaz` | 838 / 1012 (**82,81 %**) | 4424 / 5002 (**88,44 %**) | 166 / 272 (**61,03 %**) |
| **Total** | **2050 / 2360 (86,86 %)** | **9252 / 10430 (88,71 %)** | **690 / 991 (69,63 %)** |

La medida principal de cobertura por línea supera el mínimo solicitado de
76 %. También se recorren las acciones del menú, los cambios del selector,
la pintura del campo, los cuatro poderes, los controles simultáneos, los
rebotes, el reloj, los goles y el guardado de perfiles y partidos.

## Ejecutar las pruebas en BlueJ

Abre el paquete `pruebas`, selecciona una clase terminada en `Test` y usa
**Probar todo**. La suite incluye las clases `JuegoTest`, `JugadorTest`,
`BalonTest`, `ModeloGeneralTest`, `EfectosYPoderesTest`,
`MovimientoYBalonTest`, `JuegoIntegracionTest`, `PersistenciaTest`,
`PantallaInicioTest`, `InterfazIntegracionTest` y `RegistroErroresTest`.

## Medición

La cobertura se generó con JaCoCo 0.8.16 sobre las clases compiladas del
proyecto; las pruebas usan JUnit 5, que ya está incluido con BlueJ.
