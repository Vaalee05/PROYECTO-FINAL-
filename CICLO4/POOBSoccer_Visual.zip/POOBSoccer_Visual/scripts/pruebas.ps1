$ErrorActionPreference = "Stop"
$raiz = Split-Path -Parent $PSScriptRoot
if (-not (Get-Command mvn -ErrorAction SilentlyContinue)) {
    Write-Host "No se encontro Maven. Instala Apache Maven y verifica que 'mvn' funcione en la terminal." -ForegroundColor Yellow
    Write-Host "Tambien puedes abrir el pom.xml en VS Code y aceptar la importacion del proyecto Maven."
    exit 1
}
Push-Location $raiz
try {
    & mvn test
    if ($LASTEXITCODE -ne 0) {
        Write-Host "Hay pruebas fallidas o errores de compilacion. Revisa el resumen anterior y target/surefire-reports." -ForegroundColor Red
        exit $LASTEXITCODE
    }
    Write-Host "Todas las pruebas terminaron correctamente." -ForegroundColor Green
}
finally {
    Pop-Location
}
