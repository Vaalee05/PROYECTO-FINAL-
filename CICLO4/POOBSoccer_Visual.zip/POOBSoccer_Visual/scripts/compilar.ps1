$ErrorActionPreference = "Stop"
$raiz = Split-Path -Parent $PSScriptRoot
$out = Join-Path $raiz "out"

if (-not (Get-Command javac -ErrorAction SilentlyContinue)) {
    throw "No se encontro javac. Instala un JDK (recomendado Java 21) y agrega su carpeta bin al PATH."
}

if (Test-Path $out) {
    Remove-Item $out -Recurse -Force
}
New-Item -ItemType Directory -Path $out | Out-Null

$fuentes = @()
$fuentes += Get-ChildItem (Join-Path $raiz "juego") -Filter *.java -File -Recurse
$fuentes += Get-ChildItem (Join-Path $raiz "interfaz") -Filter *.java -File -Recurse
$argumentos = @("-encoding", "UTF-8", "-d", $out)
$argumentos += $fuentes.FullName

& javac @argumentos
if ($LASTEXITCODE -ne 0) {
    throw "La compilacion fallo. Revisa los errores anteriores."
}
Write-Host "Compilacion correcta. Clases generadas en: $out" -ForegroundColor Green
