$ErrorActionPreference = "Stop"
$raiz = Split-Path -Parent $PSScriptRoot
& (Join-Path $PSScriptRoot "compilar.ps1")
if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
Push-Location $raiz
try {
    & java -cp (Join-Path $raiz "out") interfaz.LanzadorDOPOSoccer
    if ($LASTEXITCODE -ne 0) { exit $LASTEXITCODE }
}
finally {
    Pop-Location
}
