# Plan de versiones y miniciclos

## Alcance hasta la version 3

El proyecto conserva el partido arcade 2D y entrega por etapas las funciones
de DOPOSoccer. Cada miniciclo deja una parte utilizable e integrable en BlueJ.

| Version | Objetivo | Miniciclos |
|---|---|---|
| 1 | Partido local jugador contra jugador | 1. Cancha, jugadores y personajes. 2. Movimiento, salto, patada y colisiones del balon. 3. Marcador, reloj, reinicio tras gol, interfaz y pruebas unitarias. |
| 2 | Persistencia y rival automatico | 1. Guardar y abrir el estado de una partida. 2. Conservar puntos y estadisticas por jugador. 3. Crear los perfiles de maquina Torpe, Ofensiva, Defensiva y Experta. |
| 3 | Poderes, mejoras y entrega inicial | 1. Carga de poder, aura y tiros de cada pais. 2. Daño, efectos, aturdimiento y recompensas. 3. Pausa, informacion permanente, opciones de cancha y errores registrados. 4. Ejecutar los escenarios iniciales de aceptacion y corregir observaciones. |
| 4 | Expansion posterior | 1. Modos de torneo, liga y supervivencia. 2. Mas personajes y tiros configurables. 3. Ajustes de presentacion y nuevas pruebas de aceptacion. |

## Requisitos incluidos hasta V3

- Dos personas en el mismo teclado y una persona contra la maquina.
- Cuatro perfiles de maquina y cuatro personajes con poderes distintos.
- Partido por tiempo con muerte subita o por goles.
- Cancha en 800x400, 1000x500 o 1200x600.
- Estadisticas, puntos, mejoras con costo creciente y archivo persistente.
- Guardado y apertura de partidas, menu de pausa y finalizacion manual.
- Barra de poder, aura, rebotes, impactos, efectos, vida y recompensas visibles.
- Excepcion del juego, mensajes detallados y archivo de registro de errores.

## Elementos planeados para una version posterior

Torneos, ligas, supervivencia, multijugador en red, mas selecciones nacionales,
sonido y personalizacion grafica avanzada quedan fuera del alcance V3. No son
necesarios para el partido local descrito en la especificacion actual.
