package interfaz;

import javax.swing.JFrame;

/**
 * Ventana de bienvenida de DOPOSoccer.
 *
 * Diccionario de atributos:
 * pantalla: portada con las acciones para iniciar o salir.
 */
public class VentanaPrincipal extends JFrame
{
    /**
     * Abre la pantalla inicial del juego.
     */
    public VentanaPrincipal()
    {
        setTitle("DOPOSoccer");
        setSize(1080, 680);
        setMinimumSize(new java.awt.Dimension(900, 600));
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        PantallaInicio pantalla = new PantallaInicio(
            this::abrirSeleccion,
            this::dispose
        );
        setContentPane(pantalla);
        setVisible(true);
    }

    /**
     * Cambia de la portada a la configuracion del partido.
     */
    private void abrirSeleccion()
    {
        new SeleccionPersonajes().setVisible(true);
        dispose();
    }
}
