
package interfaz;

import juego.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.File;
import javax.swing.filechooser.FileNameExtensionFilter;
import java.util.HashSet;
import java.util.Set;

/**
 * Representa la ventana donde se desarrolla el partido.
 * Muestra la cancha, los jugadores, el balon y el marcador.
 *
 * Diccionario de atributos:
 * juego: estado actual del partido.
 * panelCancha: panel que dibuja y recibe los controles.
 * temporizador: actualizador del juego y sus controles.
 * botonPausa: boton para abrir el menu de pausa.
 * teclasPresionadas: teclas que siguen pulsadas.
 * enPausa: indica si el menu de pausa esta abierto.
 * manejadorTeclado: recibe teclas simultaneas en toda la ventana.
 * ultimoTiempoActualizacion: instante del ultimo ciclo del juego.
 * ultimoGolpeJugador1: instante de la ultima patada del jugador 1.
 * ultimoGolpeJugador2: instante de la ultima patada del jugador 2.
 * finVentanaPatadaJugador1: limite de tiempo para ejecutar una patada pendiente.
 * finVentanaPatadaJugador2: limite de tiempo para ejecutar una patada pendiente.
 * imagenPersonajes: sprites de cada pais y uniforme de equipo.
 * intentoGuardarResultado: evita repetir la escritura tras terminar.
 */
public class VentanaPartido extends JFrame
{
    private static final long INTERVALO_PATADA_MILLIS = 350;

    private Juego juego;
    private RepositorioProgreso repositorio;
    private PanelCancha panelCancha;
    private Timer temporizador;
    private JButton botonPausa;
    private Set<Integer> teclasPresionadas;
    private boolean enPausa;
    private KeyEventDispatcher manejadorTeclado;
    private long ultimoTiempoActualizacion;
    private long ultimoGolpeJugador1;
    private long ultimoGolpeJugador2;
    private long finVentanaPatadaJugador1;
    private long finVentanaPatadaJugador2;
    private boolean intentoGuardarResultado;
    private JLabel etiquetaGol;
    private int golesAnterioresJugador1;
    private int golesAnterioresJugador2;

    /**
     * Construye la ventana del partido.
     *
     * @param juego partida que se va a representar.
     */
    public VentanaPartido(Juego juego)
    {
        this(juego, new RepositorioProgreso());
    }

    /**
     * Construye la ventana con un repositorio de progreso inyectado.
     *
     * @param juego partida que se va a representar.
     * @param repositorio servicio donde se conservan los perfiles.
     */
    public VentanaPartido(Juego juego, RepositorioProgreso repositorio)
    {
        if (juego == null || repositorio == null) {
            throw new IllegalArgumentException(
                "El juego y el repositorio son obligatorios."
            );
        }

        this.juego = juego;
        this.repositorio = repositorio;
        teclasPresionadas = new HashSet<>();
        enPausa = false;
        ultimoGolpeJugador1 = 0;
        ultimoGolpeJugador2 = 0;
        finVentanaPatadaJugador1 = 0;
        finVentanaPatadaJugador2 = 0;
        intentoGuardarResultado = false;
        golesAnterioresJugador1 = juego.getMarcador().getGolesJugador1();
        golesAnterioresJugador2 = juego.getMarcador().getGolesJugador2();

        setTitle("DOPOSoccer - Partido");
        setResizable(false);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);

        panelCancha = new PanelCancha();
        panelCancha.setLayout(null);

        etiquetaGol = new JLabel("", SwingConstants.CENTER);
        etiquetaGol.setFont(new Font("Arial", Font.BOLD, 34));
        etiquetaGol.setForeground(new Color(255, 220, 35));
        etiquetaGol.setOpaque(true);
        etiquetaGol.setBackground(new Color(0, 0, 0, 185));
        etiquetaGol.setBounds(180, 145,
            Math.max(300, juego.getCancha().getAncho() - 360), 58);
        etiquetaGol.setVisible(false);
        panelCancha.add(etiquetaGol);

        panelCancha.setPreferredSize(new Dimension(
            juego.getCancha().getAncho(), juego.getCancha().getAlto() + 100
        ));

        botonPausa = new JButton("Pausa");
        botonPausa.setBounds(juego.getCancha().getAncho() - 120,
                             12, 105, 36);
        botonPausa.setFont(new Font("Arial", Font.BOLD, 14));
        botonPausa.setBackground(new Color(255, 210, 0));
        botonPausa.setForeground(Color.BLACK);
        botonPausa.setOpaque(true);
        botonPausa.setFocusable(false);
        botonPausa.addActionListener(e -> mostrarMenuPausa());
        panelCancha.add(botonPausa);
        
        add(panelCancha);
        pack();

        configurarControles();

        juego.iniciarPartido();
        ultimoTiempoActualizacion = System.nanoTime();

        temporizador = new Timer(16, e -> {
            try {
                long ahora = System.nanoTime();
                double segundos = (ahora - ultimoTiempoActualizacion)
                    / 1000000000.0;
                ultimoTiempoActualizacion = ahora;

                procesarMovimiento();
                juego.actualizar(segundos);
                comprobarNuevoGol();
                panelCancha.repaint();
                guardarProgresoSiTermino();
                if (!juego.isPartidoActivo()) {
                    temporizador.stop();
                }
            }
            catch (RuntimeException error) {
                temporizador.stop();
                teclasPresionadas.clear();
                RegistroErrores.registrar(
                    "Error durante la actualizacion del partido.", error
                );
                JOptionPane.showMessageDialog(
                    VentanaPartido.this,
                    "Ocurrio un error durante el partido. "
                    + "Se detuvo la simulacion para evitar mas fallos. "
                    + "Revisa datos/logs/doposoccer.log.",
                    "Error durante el partido",
                    JOptionPane.ERROR_MESSAGE
                );
            }
        });

        temporizador.start();

        addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e)
            {
                temporizador.stop();
                teclasPresionadas.clear();
            }

            public void windowLostFocus(WindowEvent e)
            {
                teclasPresionadas.clear();
            }

            public void windowClosed(WindowEvent e)
            {
                KeyboardFocusManager.getCurrentKeyboardFocusManager()
                    .removeKeyEventDispatcher(manejadorTeclado);
            }
        });

        SwingUtilities.invokeLater(
            () -> panelCancha.requestFocusInWindow()
        );
    }

    /**
     * Configura los controles compartidos de ambos jugadores.
     *
     * El jugador 1 usa A, D, W, S y Q.
     * El jugador 2 usa las flechas, Ctrl y flecha abajo.
     */
    private void configurarControles()
    {
        panelCancha.setFocusable(true);

        manejadorTeclado = new KeyEventDispatcher() {
            public boolean dispatchKeyEvent(KeyEvent e)
            {
                if (!isActive() || enPausa) {
                    return false;
                }

                int tecla = e.getKeyCode();

                if (!esTeclaDelJuego(tecla)) {
                    return false;
                }

                if (juego.esModoMaquina() && esTeclaJugador2(tecla)) {
                    teclasPresionadas.remove(tecla);
                    return true;
                }

                if (e.getID() == KeyEvent.KEY_RELEASED) {
                    teclasPresionadas.remove(tecla);
                    return true;
                }

                if (e.getID() != KeyEvent.KEY_PRESSED) {
                    return false;
                }

                if (!teclasPresionadas.add(tecla)) {
                    return true;
                }

                if (tecla == KeyEvent.VK_ESCAPE) {
                    mostrarMenuPausa();
                    return true;
                }

                if (tecla == KeyEvent.VK_W) {
                    juego.saltarJugador1();
                }
                else if (tecla == KeyEvent.VK_S) {
                    finVentanaPatadaJugador1 =
                        System.currentTimeMillis() + 350;
                    intentarPatadaJugador1();
                }
                else if (tecla == KeyEvent.VK_Q) {
                    juego.lanzarPoderJugador1();
                }

                if (tecla == KeyEvent.VK_UP) {
                    juego.saltarJugador2();
                }
                else if (tecla == KeyEvent.VK_DOWN) {
                    finVentanaPatadaJugador2 =
                        System.currentTimeMillis() + 350;
                    intentarPatadaJugador2();
                }
                else if (tecla == KeyEvent.VK_CONTROL) {
                    juego.lanzarPoderJugador2();
                }

                return true;
            }
        };

        KeyboardFocusManager.getCurrentKeyboardFocusManager()
            .addKeyEventDispatcher(manejadorTeclado);

        panelCancha.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e)
            {
                panelCancha.requestFocusInWindow();
            }
        });
    }

    /**
     * Indica si una tecla pertenece a los controles del partido.
     *
     * @param tecla codigo de la tecla presionada.
     * @return true si la tecla mueve, pausa o activa una accion.
     */
    private boolean esTeclaDelJuego(int tecla)
    {
        return tecla == KeyEvent.VK_A
            || tecla == KeyEvent.VK_D
            || tecla == KeyEvent.VK_W
            || tecla == KeyEvent.VK_S
            || tecla == KeyEvent.VK_Q
            || tecla == KeyEvent.VK_LEFT
            || tecla == KeyEvent.VK_RIGHT
            || tecla == KeyEvent.VK_UP
            || tecla == KeyEvent.VK_DOWN
            || tecla == KeyEvent.VK_CONTROL
            || tecla == KeyEvent.VK_ESCAPE;
    }

    private boolean esTeclaJugador2(int tecla)
    {
        return tecla == KeyEvent.VK_LEFT
            || tecla == KeyEvent.VK_RIGHT
            || tecla == KeyEvent.VK_UP
            || tecla == KeyEvent.VK_DOWN
            || tecla == KeyEvent.VK_CONTROL;
    }

    /**
     * Mueve a los jugadores y repite las patadas sostenidas.
     */
    private void procesarMovimiento()
    {
        if (teclasPresionadas.contains(KeyEvent.VK_A)) {
            juego.moverJugador1Izquierda();
        }

        if (teclasPresionadas.contains(KeyEvent.VK_D)) {
            juego.moverJugador1Derecha();
        }

        if (teclasPresionadas.contains(KeyEvent.VK_LEFT)) {
            juego.moverJugador2Izquierda();
        }

        if (teclasPresionadas.contains(KeyEvent.VK_RIGHT)) {
            juego.moverJugador2Derecha();
        }

        long ahora = System.currentTimeMillis();

        if ((teclasPresionadas.contains(KeyEvent.VK_S)
             || ahora <= finVentanaPatadaJugador1)
            && ahora - ultimoGolpeJugador1 >= INTERVALO_PATADA_MILLIS) {
            intentarPatadaJugador1();
        }

        if ((teclasPresionadas.contains(KeyEvent.VK_DOWN)
             || ahora <= finVentanaPatadaJugador2)
            && ahora - ultimoGolpeJugador2 >= INTERVALO_PATADA_MILLIS) {
            intentarPatadaJugador2();
        }
    }

    /**
     * Ejecuta la patada del jugador 1 si el balón o el rival están cerca.
     */
    private void intentarPatadaJugador1()
    {
        if (juego.patadaJugador1()) {
            ultimoGolpeJugador1 = System.currentTimeMillis();
            finVentanaPatadaJugador1 = 0;
        }
    }

    /**
     * Ejecuta la patada del jugador 2 si el balón o el rival están cerca.
     */
    private void intentarPatadaJugador2()
    {
        if (juego.patadaJugador2()) {
            ultimoGolpeJugador2 = System.currentTimeMillis();
            finVentanaPatadaJugador2 = 0;
        }
    }

    /**
     * Detecta cambios en el marcador y anuncia cada gol una sola vez.
     */
    private void comprobarNuevoGol()
    {
        int goles1 = juego.getMarcador().getGolesJugador1();
        int goles2 = juego.getMarcador().getGolesJugador2();

        if (goles1 > golesAnterioresJugador1) {
            mostrarAvisoGol(juego.getJugador1().getNombre());
        }
        else if (goles2 > golesAnterioresJugador2) {
            mostrarAvisoGol(juego.getJugador2().getNombre());
        }

        golesAnterioresJugador1 = goles1;
        golesAnterioresJugador2 = goles2;
    }

    private void mostrarAvisoGol(String nombreJugador)
    {
        etiquetaGol.setText("¡GOOOL! " + nombreJugador);
        etiquetaGol.setVisible(true);
        panelCancha.setComponentZOrder(etiquetaGol, 0);
        panelCancha.repaint();

        Timer ocultar = new Timer(1800, e -> {
            etiquetaGol.setVisible(false);
            panelCancha.repaint();
        });
        ocultar.setRepeats(false);
        ocultar.start();
    }

    private void guardarProgresoSiTermino()
    {
        if (intentoGuardarResultado || juego.isPartidoActivo()
            || !juego.isRecompensaEntregada()
            || juego.isProgresoGuardado()) {
            return;
        }
        intentoGuardarResultado = true;
        try {
            repositorio.guardarJugador(
                juego.getJugador1().getNombre(),
                juego.getJugador1().getEstadisticas(),
                juego.getJugador1().getPuntos()
            );
            repositorio.guardarJugador(
                juego.getJugador2().getNombre(),
                juego.getJugador2().getEstadisticas(),
                juego.getJugador2().getPuntos()
            );
            juego.marcarProgresoGuardado();
        }
        catch (ErrorJuegoException error) {
            RegistroErrores.registrar(
                "No se pudieron guardar los puntos del partido.", error
            );
            JOptionPane.showMessageDialog(this,
                error.getMessage(), "Error de progreso",
                JOptionPane.ERROR_MESSAGE);
        }
    }

    /**
     * Pausa la partida y muestra sus opciones.
     */
    private void mostrarMenuPausa()
    {
        if (enPausa) {
            return;
        }

        enPausa = true;
        temporizador.stop();
        teclasPresionadas.clear();

        JDialog menu = new JDialog(this, "Partido pausado", true);
        menu.setDefaultCloseOperation(JDialog.DO_NOTHING_ON_CLOSE);

        JPanel panel = new JPanel();
        panel.setLayout(new BoxLayout(panel, BoxLayout.Y_AXIS));
        panel.setBackground(new Color(18, 48, 39));
        panel.setBorder(
            BorderFactory.createEmptyBorder(24, 34, 24, 34)
        );

        JLabel titulo = new JLabel("PARTIDO EN PAUSA");
        titulo.setFont(new Font("Arial", Font.BOLD, 22));
        titulo.setForeground(Color.WHITE);
        titulo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JLabel tiempo = new JLabel(crearTextoTiempo());
        tiempo.setFont(new Font("Arial", Font.PLAIN, 15));
        tiempo.setForeground(new Color(190, 230, 195));
        tiempo.setAlignmentX(Component.CENTER_ALIGNMENT);

        JButton continuar = crearBotonMenu(
            "Continuar", new Color(55, 145, 75)
        );
        JButton reiniciar = crearBotonMenu(
            "Reiniciar", new Color(61, 115, 167)
        );
        JButton seleccionar = crearBotonMenu(
            "Volver a seleccion", new Color(70, 125, 110)
        );
        JButton guardar = crearBotonMenu(
            "Guardar partida", new Color(80, 113, 150)
        );
        JButton abrir = crearBotonMenu(
            "Abrir partida", new Color(90, 103, 138)
        );
        JButton terminar = crearBotonMenu(
            "Finalizar partido", new Color(180, 113, 45)
        );
        JButton salir = crearBotonMenu(
            "Salir", new Color(165, 70, 65)
        );

        continuar.addActionListener(e -> {
            menu.dispose();
            reanudarPartido();
        });

        reiniciar.addActionListener(e -> {
            juego.reiniciarPartido();
            menu.dispose();
            reanudarPartido();
        });

        seleccionar.addActionListener(e -> {
            menu.dispose();
            volverASeleccion();
        });

        guardar.addActionListener(e -> guardarPartida());

        abrir.addActionListener(e -> {
            if (abrirPartida()) {
                menu.dispose();
                reanudarPartido();
            }
        });

        terminar.addActionListener(e -> {
            juego.finalizarPartido();
            guardarProgresoSiTermino();
            menu.dispose();
            temporizador.stop();
            enPausa = false;
            panelCancha.repaint();
        });

        salir.addActionListener(e -> {
            menu.dispose();
            salirDelJuego();
        });

        panel.add(titulo);
        panel.add(Box.createVerticalStrut(8));
        panel.add(tiempo);
        panel.add(Box.createVerticalStrut(20));
        panel.add(continuar);
        panel.add(Box.createVerticalStrut(9));
        panel.add(reiniciar);
        panel.add(Box.createVerticalStrut(9));
        panel.add(guardar);
        panel.add(Box.createVerticalStrut(9));
        panel.add(abrir);
        panel.add(Box.createVerticalStrut(9));
        panel.add(terminar);
        panel.add(Box.createVerticalStrut(9));
        panel.add(seleccionar);
        panel.add(Box.createVerticalStrut(9));
        panel.add(salir);

        menu.addWindowListener(new WindowAdapter() {
            public void windowClosing(WindowEvent e)
            {
                menu.dispose();
                reanudarPartido();
            }
        });

        menu.setContentPane(panel);
        menu.pack();
        menu.setResizable(false);
        menu.setLocationRelativeTo(this);
        menu.getRootPane().setDefaultButton(continuar);
        menu.setVisible(true);
    }

    /**
     * Crea un boton con el estilo del menu del partido.
     *
     * @param texto texto que aparece en el boton.
     * @param color color de fondo del boton.
     * @return boton listo para el menu.
     */
    private JButton crearBotonMenu(String texto, Color color)
    {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Arial", Font.BOLD, 15));
        boton.setBackground(color);
        boton.setForeground(Color.WHITE);
        boton.setOpaque(true);
        boton.setFocusPainted(false);
        boton.setAlignmentX(Component.CENTER_ALIGNMENT);
        boton.setMaximumSize(new Dimension(300, 42));
        boton.setPreferredSize(new Dimension(300, 42));
        return boton;
    }

    /**
     * Construye el texto del cronometro para el menu de pausa.
     *
     * @return tiempo restante o mensaje del modo por goles.
     */
    private String crearTextoTiempo()
    {
        int restante = juego.getTiempoRestante();

        if (restante < 0) {
            int transcurrido = (int) Math.floor(
                juego.getTiempoTranscurrido());
            return String.format("Partido por goles · %02d:%02d",
                transcurrido / 60, transcurrido % 60);
        }

        if (juego.estaEnMuerteSubita()) {
            return "Muerte subita - 00:00";
        }

        return String.format(
            "Tiempo restante: %02d:%02d",
            restante / 60,
            restante % 60
        );
    }

    /**
     * Continua el partido despues de cerrar el menu de pausa.
     */
    private void reanudarPartido()
    {
        enPausa = false;
        teclasPresionadas.clear();
        ultimoTiempoActualizacion = System.nanoTime();
        temporizador.start();
        SwingUtilities.invokeLater(
            () -> panelCancha.requestFocusInWindow()
        );
    }

    /**
     * Cierra el partido y vuelve a la seleccion de personajes.
     */
    private void volverASeleccion()
    {
        temporizador.stop();
        teclasPresionadas.clear();
        dispose();

        SeleccionPersonajes seleccion = new SeleccionPersonajes();
        seleccion.setVisible(true);
    }

    /**
     * Cierra el juego desde el menu de pausa.
     */
    private void salirDelJuego()
    {
        temporizador.stop();
        teclasPresionadas.clear();
        dispose();
    }

    private void guardarPartida()
    {
        JFileChooser selector = crearSelectorPartida();
        selector.setSelectedFile(new File("partida.dopo"));
        if (selector.showSaveDialog(this) != JFileChooser.APPROVE_OPTION) {
            return;
        }
        File archivo = ajustarExtension(selector.getSelectedFile());
        try {
            ServicioPartidas.guardar(juego, archivo);
            JOptionPane.showMessageDialog(this,
                "Partida guardada en:\n" + archivo.getAbsolutePath(),
                "Guardado completo", JOptionPane.INFORMATION_MESSAGE);
        }
        catch (ErrorJuegoException error) {
            mostrarErrorPartida(error);
        }
    }

    private boolean abrirPartida()
    {
        JFileChooser selector = crearSelectorPartida();
        if (selector.showOpenDialog(this) != JFileChooser.APPROVE_OPTION) {
            return false;
        }
        try {
            Juego partidaRecuperada =
                ServicioPartidas.abrir(selector.getSelectedFile());

            // Se valida y restaura antes de reemplazar la partida actual.
            partidaRecuperada.restaurarDespuesDeCarga();

            juego = partidaRecuperada;
            golesAnterioresJugador1 =
                juego.getMarcador().getGolesJugador1();
            golesAnterioresJugador2 =
                juego.getMarcador().getGolesJugador2();

            ultimoGolpeJugador1 = 0;
            ultimoGolpeJugador2 = 0;
            finVentanaPatadaJugador1 = 0;
            finVentanaPatadaJugador2 = 0;
            ultimoTiempoActualizacion = System.nanoTime();
            teclasPresionadas.clear();

            etiquetaGol.setVisible(false);
            actualizarDimensionCancha();
            intentoGuardarResultado = false;
            panelCancha.revalidate();
            panelCancha.repaint();
            return true;
        }
        catch (ErrorJuegoException error) {
            mostrarErrorPartida(error);
            return false;
        }
        catch (RuntimeException error) {
            RegistroErrores.registrar(
                "El estado recuperado de la partida no es valido.", error
            );
            JOptionPane.showMessageDialog(
                this,
                "La partida no se pudo restaurar correctamente: "
                + error.getMessage(),
                "Partida incompatible",
                JOptionPane.ERROR_MESSAGE
            );
            return false;
        }
    }

    private JFileChooser crearSelectorPartida()
    {
        JFileChooser selector = new JFileChooser();
        selector.setFileFilter(new FileNameExtensionFilter(
            "Partidas de DOPOSoccer (*.dopo)", "dopo"));
        return selector;
    }

    private File ajustarExtension(File archivo)
    {
        if (archivo.getName().toLowerCase(java.util.Locale.ROOT)
            .endsWith(".dopo")) {
            return archivo;
        }
        return new File(archivo.getAbsolutePath() + ".dopo");
    }

    private void actualizarDimensionCancha()
    {
        panelCancha.setPreferredSize(new Dimension(
            juego.getCancha().getAncho(), juego.getCancha().getAlto() + 100
        ));
        botonPausa.setBounds(juego.getCancha().getAncho() - 120,
                             12, 105, 36);
        pack();
        setLocationRelativeTo(null);
        panelCancha.repaint();
    }

    private void mostrarErrorPartida(ErrorJuegoException error)
    {
        RegistroErrores.registrar("Error en el menu de partido.", error);
        JOptionPane.showMessageDialog(this, error.getMessage(),
            "No se pudo completar la operacion", JOptionPane.ERROR_MESSAGE);
    }

    /**
     * Panel encargado de dibujar los elementos del partido.
     */
    private class PanelCancha extends JPanel
    {
        private Image imagenEstadio;
        private Image imagenPersonajes;

        public PanelCancha()
        {
            imagenEstadio = cargarImagen("imagenes/estadio.png");
            imagenPersonajes = cargarImagen(
                "imagenes/personajes_paises.png"
            );
        }

        /**
         * Carga una imagen desde el proyecto o el classpath de BlueJ.
         *
         * @param ruta ubicacion relativa de la imagen.
         * @return imagen lista para dibujar.
         */
        private Image cargarImagen(String ruta)
        {
            String rutaRecurso = ruta.replace('\\', '/');
            java.net.URL recurso = getClass().getClassLoader()
                .getResource(rutaRecurso);

            if (recurso != null) {
                ImageIcon iconoRecurso = new ImageIcon(recurso);

                if (iconoRecurso.getIconWidth() > 0
                    && iconoRecurso.getIconHeight() > 0) {
                    return iconoRecurso.getImage();
                }
            }

            java.io.File archivo = new java.io.File(ruta);

            if (!archivo.exists()) {
                try {
                    java.net.URL ubicacionClases =
                        VentanaPartido.class.getProtectionDomain()
                            .getCodeSource().getLocation();
                    java.io.File raizProyecto = new java.io.File(
                        ubicacionClases.toURI()
                    );
                    archivo = new java.io.File(raizProyecto, ruta);
                }
                catch (Exception ignorada) {
                    // Se conserva la ruta de trabajo para mostrar el error.
                }
            }

            if (!archivo.exists()) {
                throw new IllegalStateException(
                    "No se encontró la imagen: " + archivo.getAbsolutePath()
                );
            }

            ImageIcon icono = new ImageIcon(archivo.getAbsolutePath());

            if (icono.getIconWidth() <= 0 || icono.getIconHeight() <= 0) {
                throw new IllegalStateException(
                    "No se pudo cargar la imagen: " + archivo.getAbsolutePath()
                );
            }

            return icono.getImage();
        }
        
        /**
         * Dibuja la cancha y los elementos del partido.
         *
         * @param g contexto grafico.
         */
        protected void paintComponent(Graphics g)
        {
            super.paintComponent(g);

            Graphics2D dibujo = (Graphics2D) g;

            int ancho = getWidth();
            int alto = getHeight();

            dibujo.drawImage(
                imagenEstadio,
                0,
                0,
                ancho,
                alto,
                this
            );

            dibujarMarcador(dibujo, ancho);
            dibujarTiempo(dibujo, ancho);
            dibujarCargasPoder(dibujo, ancho);

            dibujarJugador(
                dibujo,
                juego.getJugador1(),
                1
            );

            dibujarJugador(
                dibujo,
                juego.getJugador2(),
                2
            );

            Balon balon = juego.getBalon();
            dibujarTiroPoder(dibujo, balon);
            dibujarBalon(dibujo, balon);
            dibujarIlusiones(dibujo);

            dibujarProyectiles(dibujo);
            dibujarResultado(dibujo, ancho, alto);
        }

        /**
         * Dibuja el marcador del partido.
         *
         * @param g contexto grafico.
         * @param ancho ancho del panel.
         */
        private void dibujarMarcador(Graphics2D g, int ancho)
        {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 24));

            String texto =
                juego.getJugador1().getNombre() + "  "
                + juego.getMarcador().getGolesJugador1()
                + " - "
                + juego.getMarcador().getGolesJugador2()
                + "  "
                + juego.getJugador2().getNombre();

            FontMetrics medidas = g.getFontMetrics();

            g.drawString(
                texto,
                (ancho - medidas.stringWidth(texto)) / 2,
                55
            );
        }

        /**
         * Dibuja el tiempo restante y el estado de muerte subita.
         *
         * @param g contexto grafico.
         * @param ancho ancho del panel.
         */
        private void dibujarTiempo(Graphics2D g, int ancho)
        {
            int restante = juego.getTiempoRestante();
            String texto;
            if (restante < 0) {
                int transcurrido = (int) Math.floor(
                    juego.getTiempoTranscurrido());
                texto = String.format("%02d:%02d  POR GOLES",
                    transcurrido / 60, transcurrido % 60);
            }
            else {
                texto = String.format("%02d:%02d", restante / 60,
                                      restante % 60);
                if (juego.estaEnMuerteSubita()) {
                    texto += "  MUERTE SUBITA";
                }
            }

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 20));

            FontMetrics medidas = g.getFontMetrics();
            g.drawString(
                texto,
                (ancho - medidas.stringWidth(texto)) / 2,
                88
            );
        }

        private void dibujarCargasPoder(Graphics2D g, int ancho)
        {
            dibujarCarga(g, 22, 108, juego.getCargaPoderJugador1(),
                juego.tieneAuraJugador1(), "Q  "
                + juego.getJugador1().getNombre(), new Color(45, 145, 255));
            dibujarCarga(g, ancho - 182, 108,
                juego.getCargaPoderJugador2(), juego.tieneAuraJugador2(),
                juego.esModoMaquina() ? "CTRL  CPU" : "CTRL  "
                + juego.getJugador2().getNombre(), new Color(255, 73, 73));
        }

        private void dibujarCarga(Graphics2D g, int x, int y, double carga,
                                  boolean activa, String etiqueta, Color color)
        {
            g.setFont(new Font("Arial", Font.BOLD, 11));
            g.setColor(Color.WHITE);
            g.drawString(etiqueta + (activa ? "  AURA" : ""), x, y);
            g.setColor(new Color(15, 30, 28, 210));
            g.fillRoundRect(x, y + 5, 160, 10, 8, 8);
            g.setColor(activa ? new Color(255, 240, 110) : color);
            g.fillRoundRect(x, y + 5,
                (int) Math.round(160 * carga), 10, 8, 8);
            g.setColor(Color.WHITE);
            g.drawRoundRect(x, y + 5, 160, 10, 8, 8);
        }

        /**
         * Muestra el resultado cuando la partida termina.
         *
         * @param g contexto grafico.
         * @param ancho ancho del panel.
         * @param alto alto del panel.
         */
        private void dibujarResultado(Graphics2D g, int ancho, int alto)
        {
            if (juego.isPartidoActivo()) {
                return;
            }

            Jugador ganador = juego.getGanador();
            String texto = ganador == null
                ? "Empate"
                : "Gana " + ganador.getNombre()
                    + (juego.isRecompensaEntregada()
                        ? "  ·  +100 puntos" : "");

            g.setColor(new Color(0, 0, 0, 175));
            g.fillRoundRect(
                ancho / 2 - 225,
                alto / 2 - 52,
                450,
                104,
                20,
                20
            );

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 28));

            FontMetrics medidas = g.getFontMetrics();
            g.drawString(
                texto,
                (ancho - medidas.stringWidth(texto)) / 2,
                alto / 2 - 2
            );
            if (juego.isRecompensaEntregada() && ganador != null) {
                Jugador perdedor = ganador == juego.getJugador1()
                    ? juego.getJugador2() : juego.getJugador1();
                String detalle = perdedor.getNombre() + " obtiene 25 puntos";
                g.setFont(new Font("Arial", Font.PLAIN, 15));
                medidas = g.getFontMetrics();
                g.drawString(detalle,
                    (ancho - medidas.stringWidth(detalle)) / 2,
                    alto / 2 + 27);
            }
        }

        /**
         * Dibuja un jugador en su posicion actual.
         *
         * @param g contexto grafico.
         * @param jugador jugador que se dibuja.
         * @param numeroJugador jugador 1 o jugador 2.
         */
        private void dibujarJugador(
            Graphics2D g, Jugador jugador, int numeroJugador)
        {
            int x = jugador.getX();
            int y = jugador.getY();

            boolean aura = numeroJugador == 1
                ? juego.tieneAuraJugador1() : juego.tieneAuraJugador2();
            if (aura) {
                g.setColor(new Color(255, 238, 90, 220));
                g.setStroke(new BasicStroke(4));
                g.drawRoundRect(x - 39, y - 97, 78, 104, 35, 35);
                g.setStroke(new BasicStroke(1));
            }

            int altoImagen = 92;
            int anchoImagen = 78;
            int columna = obtenerIndicePais(jugador.getPersonaje());
            int fila = numeroJugador == 1 ? 0 : 1;
            int inicioDestinoX = numeroJugador == 1
                ? x - anchoImagen / 2
                : x + anchoImagen / 2;
            int finDestinoX = numeroJugador == 1
                ? x + anchoImagen / 2
                : x - anchoImagen / 2;

            int anchoHoja = imagenPersonajes.getWidth(this);
            int altoHoja = imagenPersonajes.getHeight(this);
            int inicioCeldaX = columna * anchoHoja / 4;
            int finCeldaX = (columna + 1) * anchoHoja / 4;
            int inicioCeldaY = fila * altoHoja / 2;
            int finCeldaY = (fila + 1) * altoHoja / 2;
            int margenHorizontal = (finCeldaX - inicioCeldaX) / 10;

            Composite composicionAnterior = g.getComposite();

            if (!jugador.estaVivo()) {
                g.setComposite(
                    AlphaComposite.getInstance(
                        AlphaComposite.SRC_OVER, 0.4f
                    )
                );
            }

            g.drawImage(
                imagenPersonajes,
                inicioDestinoX,
                y - altoImagen + 10,
                finDestinoX,
                y + 10,
                inicioCeldaX + margenHorizontal,
                inicioCeldaY,
                finCeldaX - margenHorizontal,
                finCeldaY,
                this
            );
            g.setComposite(composicionAnterior);

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 12));

            g.drawString(
                jugador.getNombre(),
                x - 34,
                y - 100
            );

            g.setColor(Color.RED);
            g.fillRect(x - 22, y - 91, 44, 6);

            g.setColor(Color.GREEN);
            int vida = (int) (
                44.0 * jugador.getVidaActual()
                / jugador.getVidaMaxima()
            );

            g.fillRect(x - 22, y - 91, vida, 6);

            if (!jugador.estaVivo()) {
                g.setColor(Color.WHITE);
                g.drawString("REVIVE", x - 23, y - 105);
            }

            Estadisticas s = jugador.getEstadisticas();
            String datos = "V:" + s.getSpeed() + " K:" + s.getKick()
                + " J:" + s.getJump() + " R:" + s.getSurvival()
                + " · " + jugador.getPuntos() + " pts";
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 10));
            g.drawString(datos, Math.max(6, x - 57), y + 27);

            dibujarEstadoJugador(g, jugador, numeroJugador, x, y);
        }

        private void dibujarEstadoJugador(Graphics2D g, Jugador jugador,
            int numeroJugador, int x, int y)
        {
            Efecto efecto = numeroJugador == 1
                ? juego.getEfectosJugador1().getEfectoActivo()
                : juego.getEfectosJugador2().getEfectoActivo();
            if (efecto == null) {
                return;
            }

            String texto;
            if (efecto instanceof Electrocutado) {
                texto = "ELECTROCUTADO";
                g.setColor(new Color(92, 236, 255));
            }
            else if (efecto instanceof Empuje) {
                texto = jugador.getDireccionEmpuje() < 0
                    ? "EMPUJADO  «" : "EMPUJADO  »";
                g.setColor(new Color(255, 229, 92));
            }
            else if (efecto instanceof Inconsciente) {
                texto = "INCONSCIENTE";
                g.setColor(new Color(231, 165, 255));
            }
            else {
                texto = "CONFUNDIDO";
                g.setColor(new Color(224, 129, 255));
            }
            g.setFont(new Font("Arial", Font.BOLD, 10));
            g.drawString(texto, x - 38, y - 70);

            Color resplandor = g.getColor();
            g.setColor(new Color(resplandor.getRed(), resplandor.getGreen(),
                resplandor.getBlue(), 115));
            g.setStroke(new BasicStroke(3));
            g.drawOval(x - 31, y - 84, 62, 88);
            g.setStroke(new BasicStroke(1));
        }

        /**
         * Busca la columna de la hoja de sprites correspondiente al pais.
         *
         * @param personaje personaje seleccionado.
         * @return columna del personaje, de cero a tres.
         */
        private int obtenerIndicePais(Personaje personaje)
        {
            String pais = personaje.getPais();

            if ("Corea del Sur".equalsIgnoreCase(pais)) {
                return 0;
            }

            if ("Camerun".equalsIgnoreCase(pais)
                || "Camerún".equalsIgnoreCase(pais)) {
                return 1;
            }

            if ("Nigeria".equalsIgnoreCase(pais)) {
                return 2;
            }

            if ("Estados Unidos".equalsIgnoreCase(pais)) {
                return 3;
            }

            return 0;
        }

        /**
         * Dibuja un balon con paneles oscuros, brillo y sombra en el campo.
         *
         * @param g contexto grafico del partido.
         * @param balon balon que se representa.
         */
        private void dibujarBalon(Graphics2D g, Balon balon)
        {
            dibujarBalon(g, balon.getX(), balon.getY(), balon.getRadio());
        }

        private void dibujarBalon(Graphics2D g, int x, int y, int radio)
        {
            int diametro = radio * 2;

            Graphics2D dibujo = (Graphics2D) g.create();

            int altura = Math.max(
                0,
                juego.getCancha().getSueloY() - y
            );
            int anchoSombra = Math.max(8, diametro - altura / 4);
            int opacidadSombra = Math.max(18, 75 - altura / 5);

            dibujo.setColor(
                new Color(0, 0, 0, Math.min(90, opacidadSombra))
            );
            dibujo.fillOval(
                x - anchoSombra / 2,
                juego.getCancha().getSueloY() - 4,
                anchoSombra,
                5
            );

            dibujo.setPaint(new GradientPaint(
                x - radio,
                y - radio,
                new Color(255, 255, 255),
                x + radio,
                y + radio,
                new Color(165, 171, 180)
            ));
            dibujo.fillOval(x - radio, y - radio, diametro, diametro);

            Shape clipAnterior = dibujo.getClip();
            dibujo.setClip(new java.awt.geom.Ellipse2D.Double(
                x - radio, y - radio, diametro, diametro
            ));

            double giro = (x * 0.04 + y * 0.025) % (Math.PI * 2);
            dibujo.rotate(giro, x, y);
            dibujo.setColor(new Color(28, 32, 38));
            dibujo.fill(crearPentagono(x, y, 4, -Math.PI / 2));

            for (int i = 0; i < 5; i++) {
                double angulo = -Math.PI / 2 + i * Math.PI * 2 / 5;
                int parcheX = x + (int) Math.round(
                    Math.cos(angulo) * 9
                );
                int parcheY = y + (int) Math.round(
                    Math.sin(angulo) * 9
                );
                dibujo.fill(crearPentagono(
                    parcheX, parcheY, 3, angulo
                ));
            }

            dibujo.setClip(clipAnterior);
            dibujo.setColor(new Color(255, 255, 255, 210));
            dibujo.fillOval(x - radio + 5, y - radio + 4, 4, 4);
            dibujo.setColor(new Color(55, 60, 68));
            dibujo.setStroke(new BasicStroke(1.2f));
            dibujo.drawOval(x - radio, y - radio, diametro, diametro);
            dibujo.dispose();
        }

        private void dibujarIlusiones(Graphics2D g)
        {
            for (BalonFantasma fantasma : juego.getBalonesFantasma()) {
                dibujarBalon(g, fantasma.getX(), fantasma.getY(), 15);
            }
        }

        /** Distingue visualmente cada poder mientras el balon esta en vuelo. */
        private void dibujarTiroPoder(Graphics2D g, Balon balon)
        {
            Poder poder = juego.getPoderEnVuelo();
            if (poder == null) {
                return;
            }

            int x = balon.getX();
            int y = balon.getY();
            int direccion = balon.getVx() < 0 ? -1 : 1;
            Color color;
            if (poder instanceof AuraAzul) {
                color = new Color(35, 160, 255);
            }
            else if (poder instanceof Rayo) {
                color = new Color(255, 235, 65);
            }
            else if (poder instanceof Tornado) {
                color = new Color(75, 245, 150);
            }
            else {
                color = new Color(220, 100, 255);
            }

            Graphics2D efecto = (Graphics2D) g.create();
            efecto.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
            efecto.setColor(new Color(color.getRed(), color.getGreen(),
                color.getBlue(), 95));
            efecto.fillOval(x - 23, y - 23, 46, 46);
            efecto.setColor(new Color(color.getRed(), color.getGreen(),
                color.getBlue(), 220));
            efecto.setStroke(new BasicStroke(5,
                BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));

            if (poder instanceof Rayo) {
                dibujarRayo(efecto, x, y, direccion, color);
            }
            else if (poder instanceof Tornado) {
                double giro = (System.nanoTime() / 90_000_000.0)
                    % (Math.PI * 2);
                Graphics2D remolino = (Graphics2D) efecto.create();
                remolino.rotate(giro, x, y);
                remolino.setStroke(new BasicStroke(4));
                remolino.drawArc(x - 30, y - 15, 60, 30, 20, 270);
                remolino.drawArc(x - 23, y - 23, 46, 46, 195, 270);
                remolino.dispose();
            }
            else if (poder instanceof Ilusion) {
                for (int i = 0; i < 4; i++) {
                    double angulo = System.nanoTime() / 250_000_000.0
                        + i * Math.PI / 2;
                    int px = x + (int) Math.round(Math.cos(angulo) * 29);
                    int py = y + (int) Math.round(Math.sin(angulo) * 20);
                    efecto.fillOval(px - 3, py - 3, 6, 6);
                }
            }
            else {
                int inicio = x - direccion * 66;
                int fin = x - direccion * 18;
                efecto.setStroke(new BasicStroke(13,
                    BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
                efecto.drawLine(inicio, y, fin, y);
                efecto.setStroke(new BasicStroke(4));
                efecto.setColor(new Color(180, 235, 255));
                efecto.drawLine(inicio, y - 5, fin, y - 5);
            }

            efecto.setColor(color);
            efecto.setFont(new Font("Arial", Font.BOLD, 10));
            efecto.drawString(poder.getNombre(), x - 32, y - 24);
            efecto.dispose();
        }

        private void dibujarRayo(Graphics2D g, int x, int y,
                                 int direccion, Color color)
        {
            int inicio = x - direccion * 68;
            java.awt.geom.Path2D camino = new java.awt.geom.Path2D.Double();
            camino.moveTo(inicio, y + 3);
            camino.lineTo(inicio + direccion * 15, y - 8);
            camino.lineTo(inicio + direccion * 23, y + 7);
            camino.lineTo(inicio + direccion * 34, y - 10);
            camino.lineTo(inicio + direccion * 46, y + 4);
            camino.lineTo(x - direccion * 13, y);
            g.setColor(new Color(255, 242, 104, 100));
            g.setStroke(new BasicStroke(10,
                BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(camino);
            g.setColor(color);
            g.setStroke(new BasicStroke(4,
                BasicStroke.CAP_ROUND, BasicStroke.JOIN_ROUND));
            g.draw(camino);
        }

        /**
         * Crea un pentagono para los paneles del balon.
         *
         * @param x centro horizontal del pentagono.
         * @param y centro vertical del pentagono.
         * @param radio distancia del centro a los vertices.
         * @param angulo giro del pentagono.
         * @return pentagono listo para dibujar.
         */
        private Polygon crearPentagono(
            int x, int y, int radio, double angulo)
        {
            Polygon pentagono = new Polygon();

            for (int i = 0; i < 5; i++) {
                double punto = angulo + i * Math.PI * 2 / 5;
                pentagono.addPoint(
                    x + (int) Math.round(Math.cos(punto) * radio),
                    y + (int) Math.round(Math.sin(punto) * radio)
                );
            }

            return pentagono;
        }

        /**
         * Dibuja los proyectiles especiales activos.
         *
         * @param g contexto grafico.
         */
        private void dibujarProyectiles(Graphics2D g)
        {
            Proyectil p1 = juego.getProyectilJugador1();
            Proyectil p2 = juego.getProyectilJugador2();

            g.setColor(Color.CYAN);

            if (p1 != null) {
                g.fillOval(p1.getX() - 10, p1.getY() - 10, 20, 20);
            }

            if (p2 != null) {
                g.fillOval(p2.getX() - 10, p2.getY() - 10, 20, 20);
            }
        }
    }
}
