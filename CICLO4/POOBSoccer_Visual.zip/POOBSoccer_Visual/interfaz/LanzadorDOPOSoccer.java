package interfaz;

import javax.swing.SwingUtilities;

/**
 * Punto de entrada para ejecutar DOPOSoccer fuera de BlueJ.
 * No contiene reglas del juego: solamente inicia la ventana principal.
 */
public final class LanzadorDOPOSoccer
{
    private LanzadorDOPOSoccer()
    {
    }

    public static void main(String[] args)
    {
        Thread.setDefaultUncaughtExceptionHandler((hilo, error) ->
            juego.RegistroErrores.registrar(
                "Excepcion no controlada en el hilo " + hilo.getName(),
                error
            )
        );

        // Las excepciones que ocurren en la interfaz Swing tambien quedan
        // registradas, aunque sean capturadas por el mecanismo de eventos.
        System.setProperty("sun.awt.exception.handler",
            "interfaz.ManejadorExcepcionesSwing");

        SwingUtilities.invokeLater(() -> {
            try {
                new VentanaPrincipal();
            }
            catch (RuntimeException error) {
                juego.RegistroErrores.registrar(
                    "No se pudo iniciar la ventana principal.", error
                );
                throw error;
            }
        });
    }
}
