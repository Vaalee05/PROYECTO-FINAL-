package interfaz;

import javax.swing.SwingUtilities;

/**
 * Punto de entrada para ejecutar DOPOSoccer fuera de BlueJ.
 * No contiene reglas del juego: solamente inicia la ventana principal.
 */
public final class LanzadorDOPOSoccer
{
    private LanzadorDOPOSoccer()
    {
    }

    public static void main(String[] args)
    {
        SwingUtilities.invokeLater(VentanaPrincipal::new);
    }
}
