package interfaz;

import juego.RegistroErrores;

/**
 * Registra excepciones no controladas que ocurren en el hilo de eventos Swing.
 */
public class ManejadorExcepcionesSwing
{
    public void handle(Throwable error)
    {
        RegistroErrores.registrar(
            "Excepcion no controlada en la interfaz Swing.", error
        );
    }
}
