package interfaz;

import javax.swing.*;
import java.awt.*;
import juego.*;

/**
 * Presenta los perfiles, personajes y reglas del siguiente partido.
 *
 * Diccionario de atributos:
 * nombreJugador1: nombre y perfil persistente del primer jugador.
 * nombreJugador2: nombre del segundo jugador o de la maquina.
 * seleccionJugador1: personaje del primer jugador.
 * seleccionJugador2: personaje del segundo jugador.
 * seleccionModalidad: tipo de finalizacion del partido.
 * seleccionModo: partido entre personas o contra la maquina.
 * seleccionPerfil: nivel de comportamiento de la maquina.
 * seleccionResolucion: dimensiones de la cancha.
 * duracion: minutos de juego o goles necesarios.
 * repositorio: almacenamiento de estadisticas y puntos.
 */
public class SeleccionPersonajes extends JFrame
{
    private final JTextField nombreJugador1;
    private final JTextField nombreJugador2;
    private final JComboBox<String> seleccionJugador1;
    private final JComboBox<String> seleccionJugador2;
    private final JComboBox<String> seleccionModalidad;
    private final JComboBox<ModoPartida> seleccionModo;
    private final JComboBox<PerfilMaquina> seleccionPerfil;
    private final JComboBox<String> seleccionResolucion;
    private final JSpinner duracion;
    private final JLabel progreso1;
    private final JLabel progreso2;
    private final RepositorioProgreso repositorio;

    public SeleccionPersonajes()
    {
        this(new RepositorioProgreso());
    }

    /**
     * Construye el selector con el repositorio de perfiles indicado.
     *
     * @param repositorio almacenamiento de perfiles.
     */
    public SeleccionPersonajes(RepositorioProgreso repositorio)
    {
        if (repositorio == null) {
            throw new IllegalArgumentException(
                "El repositorio de progreso es obligatorio."
            );
        }
        this.repositorio = repositorio;
        setTitle("DOPOSoccer - Configurar partido");
        setSize(930, 650);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel principal = new JPanel(new BorderLayout(14, 14));
        principal.setBackground(new Color(16, 43, 37));
        principal.setBorder(BorderFactory.createEmptyBorder(20, 24, 22, 24));

        JLabel titulo = new JLabel("PREPARA EL PARTIDO", SwingConstants.CENTER);
        titulo.setFont(new Font("Arial", Font.BOLD, 26));
        titulo.setForeground(Color.WHITE);
        principal.add(titulo, BorderLayout.NORTH);

        String[] personajes = {
            "Corea del Sur - Aura Azul", "Camerún - Rayo",
            "Nigeria - Tornado", "Estados Unidos - Ilusión"
        };
        nombreJugador1 = new JTextField("Jugador 1");
        nombreJugador2 = new JTextField("Jugador 2");
        seleccionJugador1 = new JComboBox<>(personajes);
        seleccionJugador2 = new JComboBox<>(personajes);
        progreso1 = new JLabel(" ");
        progreso2 = new JLabel(" ");

        JPanel jugadores = new JPanel(new GridLayout(1, 2, 14, 0));
        jugadores.setOpaque(false);
        jugadores.add(crearTarjetaJugador(
            "JUGADOR 1 · AZUL", nombreJugador1,
            seleccionJugador1, progreso1, 1
        ));
        jugadores.add(crearTarjetaJugador(
            "JUGADOR 2 · ROJO", nombreJugador2,
            seleccionJugador2, progreso2, 2
        ));

        seleccionModo = new JComboBox<>(ModoPartida.values());
        seleccionPerfil = new JComboBox<>(PerfilMaquina.values());
        seleccionModalidad = new JComboBox<>(new String[] {
            "Por tiempo", "Por goles"
        });
        seleccionResolucion = new JComboBox<>(new String[] {
            "800x400", "1000x500", "1200x600"
        });
        duracion = new JSpinner(new SpinnerNumberModel(1, 1, 30, 1));

        JPanel opciones = new JPanel(new GridLayout(2, 3, 12, 8));
        opciones.setOpaque(false);
        opciones.add(crearOpcion("Enfrentamiento", seleccionModo));
        opciones.add(crearOpcion("Perfil de maquina", seleccionPerfil));
        opciones.add(crearOpcion("Final del partido", seleccionModalidad));
        opciones.add(crearOpcion("Resolucion de cancha", seleccionResolucion));
        opciones.add(crearOpcion("Minutos / goles", duracion));
        JButton iniciar = crearBoton("Iniciar partido", new Color(47, 155, 79));
        opciones.add(iniciar);

        JPanel centro = new JPanel(new BorderLayout(12, 15));
        centro.setOpaque(false);
        centro.add(jugadores, BorderLayout.CENTER);
        centro.add(opciones, BorderLayout.SOUTH);
        principal.add(centro, BorderLayout.CENTER);

        JLabel controles = new JLabel(
            "Controles: P1 A/D mueve, W salta, S patea, Q poder  "
            + "|  P2 flechas, ↑ salta, ↓ patea, Ctrl poder  |  Esc pausa",
            SwingConstants.CENTER
        );
        controles.setForeground(new Color(205, 226, 215));
        controles.setFont(new Font("Arial", Font.PLAIN, 12));
        principal.add(controles, BorderLayout.SOUTH);
        add(principal);

        seleccionModalidad.addActionListener(e -> actualizarDuracion());
        seleccionModo.addActionListener(e -> actualizarModo());
        seleccionPerfil.addActionListener(e -> actualizarNombreMaquina());
        nombreJugador1.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent e)
            {
                actualizarResumen(1);
            }
        });
        nombreJugador2.addFocusListener(new java.awt.event.FocusAdapter() {
            public void focusLost(java.awt.event.FocusEvent e)
            {
                actualizarResumen(2);
            }
        });
        iniciar.addActionListener(e -> confirmarSeleccion());

        actualizarModo();
        actualizarDuracion();
        actualizarResumen(1);
        actualizarResumen(2);
    }

    private JPanel crearTarjetaJugador(String titulo, JTextField nombre,
        JComboBox<String> personaje, JLabel resumen, int numero)
    {
        JPanel tarjeta = new JPanel(new GridLayout(6, 1, 5, 8));
        tarjeta.setBackground(new Color(25, 66, 55));
        tarjeta.setBorder(BorderFactory.createCompoundBorder(
            BorderFactory.createLineBorder(new Color(91, 150, 111), 2),
            BorderFactory.createEmptyBorder(15, 18, 15, 18)
        ));
        JLabel encabezado = new JLabel(titulo, SwingConstants.CENTER);
        encabezado.setFont(new Font("Arial", Font.BOLD, 18));
        encabezado.setForeground(Color.WHITE);
        resumen.setFont(new Font("Arial", Font.PLAIN, 12));
        resumen.setForeground(new Color(219, 236, 223));
        JButton mejorar = crearBoton("Mejorar habilidades", new Color(70, 112, 150));
        mejorar.addActionListener(e -> abrirMejoras(numero));
        tarjeta.add(encabezado);
        tarjeta.add(crearFila("Nombre", nombre));
        tarjeta.add(crearFila("Personaje", personaje));
        tarjeta.add(resumen);
        tarjeta.add(mejorar);
        tarjeta.add(new JLabel(""));
        return tarjeta;
    }

    private JPanel crearFila(String texto, JComponent componente)
    {
        JPanel fila = new JPanel(new BorderLayout(7, 0));
        fila.setOpaque(false);
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setForeground(Color.WHITE);
        fila.add(etiqueta, BorderLayout.NORTH);
        fila.add(componente, BorderLayout.CENTER);
        return fila;
    }

    private JPanel crearOpcion(String texto, JComponent componente)
    {
        JPanel panel = new JPanel(new BorderLayout(4, 2));
        panel.setOpaque(false);
        JLabel etiqueta = new JLabel(texto);
        etiqueta.setForeground(Color.WHITE);
        panel.add(etiqueta, BorderLayout.NORTH);
        panel.add(componente, BorderLayout.CENTER);
        return panel;
    }

    private JButton crearBoton(String texto, Color fondo)
    {
        JButton boton = new JButton(texto);
        boton.setFont(new Font("Arial", Font.BOLD, 14));
        boton.setBackground(fondo);
        boton.setForeground(Color.WHITE);
        boton.setOpaque(true);
        boton.setFocusPainted(false);
        return boton;
    }

    private void actualizarModo()
    {
        boolean contraMaquina = seleccionModo.getSelectedItem()
            == ModoPartida.JUGADOR_VS_MAQUINA;
        seleccionPerfil.setEnabled(contraMaquina);
        nombreJugador2.setEditable(!contraMaquina);
        if (contraMaquina) {
            actualizarNombreMaquina();
        }
    }

    private void actualizarNombreMaquina()
    {
        if (seleccionModo.getSelectedItem()
            == ModoPartida.JUGADOR_VS_MAQUINA) {
            nombreJugador2.setText("CPU " + seleccionPerfil.getSelectedItem());
            actualizarResumen(2);
        }
    }

    private void actualizarDuracion()
    {
        ((javax.swing.SpinnerNumberModel) duracion.getModel()).setMaximum(
            seleccionModalidad.getSelectedIndex() == 0 ? 30 : 20
        );
        ((javax.swing.SpinnerNumberModel) duracion.getModel()).setMinimum(1);
        duracion.setToolTipText(seleccionModalidad.getSelectedIndex() == 0
            ? "Duracion en minutos" : "Goles necesarios para ganar");
    }

    private void actualizarResumen(int jugador)
    {
        JTextField campo = jugador == 1 ? nombreJugador1 : nombreJugador2;
        JLabel resumen = jugador == 1 ? progreso1 : progreso2;
        String nombre = campo.getText().trim();
        if (nombre.isEmpty()) {
            resumen.setText("Escribe un nombre para cargar el progreso.");
            return;
        }
        try {
            ProgresoJugador progreso = repositorio.cargar(nombre);
            Estadisticas s = progreso.getEstadisticas();
            resumen.setText(String.format(
                "Puntos %d  |  Speed %d  Kick %d  Jump %d  Survival %d",
                progreso.getPuntos(), s.getSpeed(), s.getKick(),
                s.getJump(), s.getSurvival()
            ));
        }
        catch (ErrorJuegoException error) {
            mostrarError(error);
        }
    }

    private void abrirMejoras(int numero)
    {
        JTextField campo = numero == 1 ? nombreJugador1 : nombreJugador2;
        String nombre = campo.getText().trim();
        if (nombre.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Escribe primero el nombre del jugador.");
            return;
        }
        try {
            ProgresoJugador progreso = repositorio.cargar(nombre);
            AtributoJugador atributo = (AtributoJugador) JOptionPane
                .showInputDialog(this,
                    "Puntos: " + progreso.getPuntos() + "\n"
                    + "Costo de la siguiente mejora: "
                    + progreso.getCostoSiguienteMejora(),
                    "Mejorar habilidades", JOptionPane.PLAIN_MESSAGE,
                    null, AtributoJugador.values(), AtributoJugador.SPEED);
            if (atributo == null) {
                return;
            }
            int nivel = progreso.getEstadisticas().getValor(atributo);
            if (!progreso.mejorar(atributo)) {
                JOptionPane.showMessageDialog(this,
                    progreso.getPuntos() < progreso.getCostoSiguienteMejora()
                    ? "No hay puntos suficientes para esta mejora."
                    : "La habilidad ya esta en su nivel maximo.");
                return;
            }
            repositorio.guardar(nombre, progreso);
            actualizarResumen(numero);
            JOptionPane.showMessageDialog(this,
                atributo + " mejoro de " + nivel + " a "
                + progreso.getEstadisticas().getValor(atributo) + ".");
        }
        catch (ErrorJuegoException error) {
            mostrarError(error);
        }
    }

    private void confirmarSeleccion()
    {
        String nombre1 = nombreJugador1.getText().trim();
        String nombre2 = nombreJugador2.getText().trim();
        if (nombre1.isEmpty() || nombre2.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "Escribe el nombre de ambos jugadores.");
            return;
        }
        if (seleccionModo.getSelectedItem() == ModoPartida.JUGADOR_VS_JUGADOR
            && nombre1.equalsIgnoreCase(nombre2)) {
            JOptionPane.showMessageDialog(this,
                "Cada jugador necesita un nombre distinto.");
            return;
        }

        try {
            ProgresoJugador perfil1 = repositorio.cargar(nombre1);
            ProgresoJugador perfil2 = repositorio.cargar(nombre2);
            Jugador jugador1 = new Jugador(nombre1,
                FabricaPersonajes.crear(seleccionJugador1.getSelectedIndex()),
                perfil1.getEstadisticas());
            Jugador jugador2 = new Jugador(nombre2,
                FabricaPersonajes.crear(seleccionJugador2.getSelectedIndex()),
                perfil2.getEstadisticas());
            jugador1.agregarPuntos(perfil1.getPuntos());
            jugador2.agregarPuntos(perfil2.getPuntos());

            String[] medidas = seleccionResolucion.getSelectedItem()
                .toString().split("x");
            int ancho = Integer.parseInt(medidas[0]);
            int alto = Integer.parseInt(medidas[1]);
            Cancha cancha = new Cancha(ancho, alto,
                seleccionResolucion.getSelectedItem().toString());
            Juego juego = new Juego(jugador1, jugador2, cancha);

            boolean porTiempo = seleccionModalidad.getSelectedIndex() == 0;
            int valor = (Integer) duracion.getValue();
            juego.setConfiguracion(new ConfiguracionPartido(
                porTiempo ? "TIEMPO" : "GOLES",
                porTiempo ? valor * 60 : 60,
                porTiempo ? 5 : valor,
                (ModoPartida) seleccionModo.getSelectedItem(),
                (PerfilMaquina) seleccionPerfil.getSelectedItem()
            ));

            VentanaPartido ventana = new VentanaPartido(juego, repositorio);
            ventana.setVisible(true);
            dispose();
        }
        catch (ErrorJuegoException | IllegalArgumentException error) {
            RegistroErrores.registrar("No se pudo crear la partida.", error);
            JOptionPane.showMessageDialog(this, error.getMessage(),
                "No se pudo iniciar", JOptionPane.ERROR_MESSAGE);
        }
    }

    private void mostrarError(ErrorJuegoException error)
    {
        RegistroErrores.registrar("Error en la pantalla de seleccion.", error);
        JOptionPane.showMessageDialog(this, error.getMessage(),
            "Error de progreso", JOptionPane.ERROR_MESSAGE);
    }
}
