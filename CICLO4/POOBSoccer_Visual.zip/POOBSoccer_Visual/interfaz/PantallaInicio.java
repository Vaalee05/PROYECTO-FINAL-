package interfaz;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.Image;
import java.awt.RenderingHints;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import javax.swing.BorderFactory;
import javax.swing.Box;
import javax.swing.BoxLayout;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.SwingConstants;

/**
 * Presenta la portada del juego con el estadio y los dos equipos.
 *
 * Diccionario de atributos:
 * fondo: imagen de la cancha usada como fondo.
 * botonIniciar: accion para abrir la configuracion del partido.
 * botonSalir: accion para cerrar la portada.
 * iniciar: operacion que se ejecuta al elegir iniciar.
 * salir: operacion que se ejecuta al elegir salir.
 */
public class PantallaInicio extends JPanel
{
    private static final Color VERDE = new Color(57, 201, 104);
    private static final Color TEXTO_SUAVE = new Color(216, 231, 226);
    private final Image fondo;
    private final JButton botonIniciar;
    private final JButton botonSalir;
    private final Runnable iniciar;
    private final Runnable salir;

    /**
     * Construye la portada y conecta sus botones con las ventanas llamantes.
     *
     * @param iniciar accion para comenzar la configuracion.
     * @param salir accion para cerrar la aplicacion.
     */
    public PantallaInicio(Runnable iniciar, Runnable salir)
    {
        if (iniciar == null || salir == null) {
            throw new IllegalArgumentException(
                "Las acciones de la portada son obligatorias."
            );
        }
        this.iniciar = iniciar;
        this.salir = salir;
        fondo = cargarImagen("imagenes/estadio.png");
        botonIniciar = crearBotonPrincipal();
        botonSalir = crearBotonSecundario();

        setLayout(new java.awt.GridBagLayout());
        setPreferredSize(new Dimension(1080, 680));
        setBorder(BorderFactory.createEmptyBorder(24, 18, 20, 18));

        java.awt.GridBagConstraints columna = new java.awt.GridBagConstraints();
        columna.gridy = 0;
        columna.anchor = java.awt.GridBagConstraints.CENTER;
        columna.insets = new java.awt.Insets(0, 2, 0, 2);

        JLabel jugadorAzul = crearJugador("imagenes/jugador_azul.png",
            "Jugador 1, uniforme azul");
        columna.gridx = 0;
        columna.weightx = 1.0;
        add(jugadorAzul, columna);

        JPanel tarjeta = crearTarjeta();
        columna.gridx = 1;
        columna.weightx = 0;
        columna.insets = new java.awt.Insets(0, 4, 0, 4);
        add(tarjeta, columna);

        JLabel jugadorRojo = crearJugador("imagenes/jugador_rojo.png",
            "Jugador 2, uniforme rojo");
        columna.gridx = 2;
        columna.weightx = 1.0;
        columna.insets = new java.awt.Insets(0, 2, 0, 2);
        add(jugadorRojo, columna);
    }

    /**
     * Obtiene el boton principal para integraciones y pruebas de interfaz.
     *
     * @return boton que inicia la configuracion.
     */
    public JButton getBotonIniciar()
    {
        return botonIniciar;
    }

    /**
     * Obtiene el boton secundario para integraciones y pruebas de interfaz.
     *
     * @return boton que cierra el juego.
     */
    public JButton getBotonSalir()
    {
        return botonSalir;
    }

    @Override
    protected void paintComponent(Graphics grafico)
    {
        super.paintComponent(grafico);
        Graphics2D g = (Graphics2D) grafico.create();
        g.setRenderingHint(RenderingHints.KEY_RENDERING,
            RenderingHints.VALUE_RENDER_QUALITY);

        if (fondo != null) {
            g.drawImage(fondo, 0, 0, getWidth(), getHeight(), this);
        }
        else {
            g.setPaint(new GradientPaint(0, 0, new Color(9, 34, 38),
                0, getHeight(), new Color(13, 93, 49)));
            g.fillRect(0, 0, getWidth(), getHeight());
        }

        g.setPaint(new GradientPaint(0, 0, new Color(3, 16, 24, 132),
            0, getHeight(), new Color(3, 20, 16, 118)));
        g.fillRect(0, 0, getWidth(), getHeight());
        g.setColor(new Color(61, 218, 119, 190));
        g.fillRect(0, 0, getWidth(), 5);
        g.dispose();
    }

    private JPanel crearTarjeta()
    {
        JPanel tarjeta = new PanelTarjeta();
        tarjeta.setLayout(new BoxLayout(tarjeta, BoxLayout.Y_AXIS));
        tarjeta.setBorder(BorderFactory.createEmptyBorder(30, 34, 26, 34));
        tarjeta.setPreferredSize(new Dimension(510, 450));

        JLabel insignia = crearEtiqueta("TEMPORADA 2026  ·  VERSIÓN 3",
            new Font("Segoe UI", Font.BOLD, 12), VERDE);
        tarjeta.add(insignia);
        tarjeta.add(Box.createVerticalStrut(19));

        JLabel titulo = crearEtiqueta("DOPOSOCCER",
            new Font("Segoe UI", Font.BOLD, 42), Color.WHITE);
        tarjeta.add(titulo);

        JLabel frase = crearEtiqueta("EL PARTIDO EMPIEZA AQUÍ",
            new Font("Segoe UI", Font.BOLD, 15),
            new Color(196, 221, 211));
        tarjeta.add(Box.createVerticalStrut(5));
        tarjeta.add(frase);

        JPanel separador = new JPanel();
        separador.setBackground(new Color(79, 210, 117));
        separador.setMaximumSize(new Dimension(74, 3));
        separador.setPreferredSize(new Dimension(74, 3));
        separador.setAlignmentX(CENTER_ALIGNMENT);
        tarjeta.add(Box.createVerticalStrut(21));
        tarjeta.add(separador);

        JLabel descripcion = crearEtiqueta(
            "Elige tu selección y demuestra quién domina la cancha.",
            new Font("Segoe UI", Font.PLAIN, 14), TEXTO_SUAVE);
        tarjeta.add(Box.createVerticalStrut(18));
        tarjeta.add(descripcion);
        tarjeta.add(Box.createVerticalStrut(27));

        botonIniciar.setAlignmentX(CENTER_ALIGNMENT);
        tarjeta.add(botonIniciar);
        tarjeta.add(Box.createVerticalStrut(10));
        botonSalir.setAlignmentX(CENTER_ALIGNMENT);
        tarjeta.add(botonSalir);
        tarjeta.add(Box.createVerticalGlue());

        JLabel controles = crearEtiqueta(
            "P1: A · D · W · S · Q        P2: FLECHAS · CTRL",
            new Font("Segoe UI", Font.BOLD, 11),
            new Color(168, 194, 184));
        tarjeta.add(controles);
        return tarjeta;
    }

    private JButton crearBotonPrincipal()
    {
        JButton boton = new JButton("INICIAR JUEGO  ›");
        boton.setFont(new Font("Segoe UI", Font.BOLD, 17));
        boton.setForeground(new Color(7, 35, 23));
        boton.setBackground(VERDE);
        boton.setOpaque(true);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder(14, 28, 14, 28));
        boton.setPreferredSize(new Dimension(330, 56));
        boton.setMaximumSize(new Dimension(330, 56));
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        boton.addActionListener(evento -> iniciar.run());
        boton.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseEntered(MouseEvent evento)
            {
                boton.setBackground(new Color(91, 226, 132));
            }

            @Override
            public void mouseExited(MouseEvent evento)
            {
                boton.setBackground(VERDE);
            }
        });
        return boton;
    }

    private JButton crearBotonSecundario()
    {
        JButton boton = new JButton("Salir del juego");
        boton.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        boton.setForeground(new Color(236, 242, 238));
        boton.setContentAreaFilled(false);
        boton.setFocusPainted(false);
        boton.setBorder(BorderFactory.createEmptyBorder(8, 18, 8, 18));
        boton.setPreferredSize(new Dimension(220, 40));
        boton.setMaximumSize(new Dimension(220, 40));
        boton.setCursor(new java.awt.Cursor(java.awt.Cursor.HAND_CURSOR));
        boton.addActionListener(evento -> salir.run());
        return boton;
    }

    private JLabel crearJugador(String ruta, String descripcion)
    {
        Image imagen = cargarImagen(ruta);
        JLabel jugador = new JLabel();
        jugador.setHorizontalAlignment(SwingConstants.CENTER);
        jugador.setVerticalAlignment(SwingConstants.CENTER);
        jugador.setPreferredSize(new Dimension(265, 330));
        jugador.setToolTipText(descripcion);
        if (imagen != null) {
            jugador.setIcon(new ImageIcon(imagen.getScaledInstance(
                265, 265, Image.SCALE_SMOOTH)));
        }
        return jugador;
    }

    private JLabel crearEtiqueta(String texto, Font fuente, Color color)
    {
        JLabel etiqueta = new JLabel(texto, SwingConstants.CENTER);
        etiqueta.setFont(fuente);
        etiqueta.setForeground(color);
        etiqueta.setAlignmentX(CENTER_ALIGNMENT);
        return etiqueta;
    }

    private Image cargarImagen(String ruta)
    {
        File archivo = new File(ruta);
        if (!archivo.isFile()) {
            return null;
        }
        ImageIcon icono = new ImageIcon(archivo.getPath());
        return icono.getIconWidth() > 0 ? icono.getImage() : null;
    }

    /**
     * Pinta la tarjeta oscura que mantiene legible el contenido.
     */
    private static class PanelTarjeta extends JPanel
    {
        @Override
        protected void paintComponent(Graphics grafico)
        {
            Graphics2D g = (Graphics2D) grafico.create();
            g.setRenderingHint(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
            g.setColor(new Color(8, 21, 27, 224));
            g.fillRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 26, 26);
            g.setColor(new Color(191, 225, 207, 95));
            g.drawRoundRect(0, 0, getWidth() - 1, getHeight() - 1, 26, 26);
            g.dispose();
            super.paintComponent(grafico);
        }

        @Override
        public boolean isOpaque()
        {
            return false;
        }
    }
}
