package juego;



/**
 * Define el comportamiento de los poderes especiales
 * de los personajes de DOPOSoccer.
 */
public interface Poder extends java.io.Serializable
{
    /**
     * Aplica el poder sobre un jugador objetivo.
     *
     * @param atacante jugador que utiliza el poder.
     * @param objetivo jugador que recibe el impacto.
     * @param administrador administrador de los efectos del objetivo.
     */
    void aplicar(Jugador atacante, Jugador objetivo,
                 AdministradorEfectos administrador);

    /**
     * Retorna el nombre del poder.
     *
     * @return nombre del poder.
     */
    String getNombre();

    /**
     * Retorna el daño base del poder.
     *
     * @return daño base.
     */
    int getDanoBase();

    /**
     * Retorna la duración del efecto.
     *
     * @return duración en segundos.
     */
    double getDuracion();

    /**
     * Define el impulso y el rebote del balon segun el poder.
     *
     * @param balon balon impulsado.
     * @param direccion direccion del disparo: 1 o -1.
     */
    void prepararDisparo(Balon balon, int direccion);
}
