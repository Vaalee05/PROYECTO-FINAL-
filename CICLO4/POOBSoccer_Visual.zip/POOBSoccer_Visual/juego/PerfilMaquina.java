package juego;

/**
 * Estrategias para el rival controlado por la maquina.
 * Cada perfil decide a que punto moverse y con que alcance
 * intenta patear el balon.
 *
 * Diccionario de atributos:
 * nombre: nombre visible del perfil seleccionado.
 */
public enum PerfilMaquina
{
    TORPE("Torpe") {
        public int decidirDireccion(Jugador jugador, Balon balon,
                                   Cancha cancha, int ciclo)
        {
            return java.util.concurrent.ThreadLocalRandom.current()
                .nextInt(-1, 2);
        }

        public int alcancePatada()
        {
            return 58;
        }
    },
    OFENSIVA("Ofensiva") {
        public int decidirDireccion(Jugador jugador, Balon balon,
                                   Cancha cancha, int ciclo)
        {
            return direccionHacia(jugador.getX(), balon.getX());
        }

        public int alcancePatada()
        {
            return 112;
        }
    },
    DEFENSIVA("Defensiva") {
        public int decidirDireccion(Jugador jugador, Balon balon,
                                   Cancha cancha, int ciclo)
        {
            int zona = (int) (cancha.getAncho() * 0.70);
            int objetivo = balon.getX() > zona
                ? balon.getX() : (int) (cancha.getAncho() * 0.82);
            return direccionHacia(jugador.getX(), objetivo);
        }

        public int alcancePatada()
        {
            return 88;
        }
    },
    EXPERTA("Experta") {
        public int decidirDireccion(Jugador jugador, Balon balon,
                                   Cancha cancha, int ciclo)
        {
            int anticipacion = Math.max(-100, Math.min(100,
                balon.getVx() * 4));
            int objetivo = Math.max(0, Math.min(cancha.getAncho(),
                balon.getX() + anticipacion));
            return direccionHacia(jugador.getX(), objetivo);
        }

        public int alcancePatada()
        {
            return 125;
        }
    };

    private final String nombre;

    PerfilMaquina(String nombre)
    {
        this.nombre = nombre;
    }

    public abstract int decidirDireccion(Jugador jugador, Balon balon,
                                         Cancha cancha, int ciclo);

    public abstract int alcancePatada();

    public boolean debeSaltar(Jugador jugador, Balon balon)
    {
        return balon.getY() < jugador.getY() - 35
            && Math.abs(balon.getX() - jugador.getX()) < 150
            && !jugador.estaSaltando();
    }

    private static int direccionHacia(int desde, int hasta)
    {
        if (Math.abs(hasta - desde) < 10) {
            return 0;
        }
        return hasta < desde ? -1 : 1;
    }

    public String toString()
    {
        return nombre;
    }
}
