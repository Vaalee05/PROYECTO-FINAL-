package juego;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.AtomicMoveNotSupportedException;
import java.util.Base64;
import java.util.Properties;

/**
 * Guarda los perfiles de jugadores en un archivo legible y editable.
 *
 * Diccionario de atributos:
 * archivo: ubicacion del archivo de progreso.
 *
 * Patron Repository: separa el acceso al archivo de las reglas del juego.
 */
public class RepositorioProgreso
{
    private final File archivo;

    public RepositorioProgreso()
    {
        this(new File("datos/progreso.properties"));
    }

    public RepositorioProgreso(File archivo)
    {
        if (archivo == null) {
            throw new IllegalArgumentException(
                "El archivo de progreso es obligatorio."
            );
        }
        this.archivo = archivo;
    }

    /**
     * Busca un perfil por el nombre normalizado del jugador.
     *
     * @param nombre identificador del perfil.
     * @return progreso recuperado o perfil inicial.
     * @throws ErrorJuegoException si el archivo esta dañado o no se lee.
     */
    public ProgresoJugador cargar(String nombre) throws ErrorJuegoException
    {
        String prefijo = crearClave(nombre);
        Properties datos = leer();
        ProgresoJugador perfil = new ProgresoJugador();
        try {
            Estadisticas estadisticas = new Estadisticas(
                entero(datos, prefijo + ".speed", 1),
                entero(datos, prefijo + ".kick", 1),
                entero(datos, prefijo + ".jump", 1),
                entero(datos, prefijo + ".survival", 1)
            );
            perfil.establecer(
                estadisticas,
                entero(datos, prefijo + ".points", 0),
                entero(datos, prefijo + ".nextCost", 500)
            );
        }
        catch (IllegalArgumentException error) {
            RegistroErrores.registrar(
                "El archivo de progreso tiene datos invalidos.", error
            );
            throw new ErrorJuegoException(
                "El progreso guardado para " + nombre
                + " esta dañado. Corrige o elimina datos/progreso.properties.",
                error
            );
        }
        return perfil;
    }

    /**
     * Conserva un perfil sin reemplazar los datos de otros jugadores.
     *
     * @param nombre identificador del perfil.
     * @param perfil progreso actualizado.
     * @throws ErrorJuegoException si no se puede escribir el archivo.
     */
    public void guardar(String nombre, ProgresoJugador perfil)
        throws ErrorJuegoException
    {
        if (perfil == null) {
            throw new ErrorJuegoException("El perfil no puede estar vacio.");
        }
        String prefijo = crearClave(nombre);
        Properties datos = leer();
        Estadisticas habilidades = perfil.getEstadisticas();
        datos.setProperty(prefijo + ".speed",
            Integer.toString(habilidades.getSpeed()));
        datos.setProperty(prefijo + ".kick",
            Integer.toString(habilidades.getKick()));
        datos.setProperty(prefijo + ".jump",
            Integer.toString(habilidades.getJump()));
        datos.setProperty(prefijo + ".survival",
            Integer.toString(habilidades.getSurvival()));
        datos.setProperty(prefijo + ".points",
            Integer.toString(perfil.getPuntos()));
        datos.setProperty(prefijo + ".nextCost",
            Integer.toString(perfil.getCostoSiguienteMejora()));

        File temporal = new File(archivo.getAbsolutePath() + ".tmp");
        try {
            File carpeta = archivo.getAbsoluteFile().getParentFile();
            if (carpeta != null && !carpeta.exists() && !carpeta.mkdirs()) {
                throw new IOException("No se pudo crear la carpeta de datos.");
            }
            try (FileOutputStream salida = new FileOutputStream(temporal)) {
                datos.store(salida, "Progreso de jugadores de DOPOSoccer");
            }
            try {
                Files.move(temporal.toPath(), archivo.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
            }
            catch (AtomicMoveNotSupportedException ignorada) {
                Files.move(temporal.toPath(), archivo.toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
            }
        }
        catch (IOException error) {
            temporal.delete();
            RegistroErrores.registrar("Error al guardar progreso.", error);
            throw new ErrorJuegoException(
                "No se pudo guardar el progreso en "
                + archivo.getAbsolutePath() + ". " + error.getMessage(), error
            );
        }
    }

    public void guardarJugador(String nombre, Estadisticas estadisticas,
                               int puntos) throws ErrorJuegoException
    {
        ProgresoJugador perfil = cargar(nombre);
        perfil.establecer(estadisticas, puntos,
                          perfil.getCostoSiguienteMejora());
        guardar(nombre, perfil);
    }

    private Properties leer() throws ErrorJuegoException
    {
        Properties datos = new Properties();
        if (!archivo.isFile()) {
            return datos;
        }
        try (FileInputStream entrada = new FileInputStream(archivo)) {
            datos.load(entrada);
            return datos;
        }
        catch (IOException error) {
            RegistroErrores.registrar("Error al leer progreso.", error);
            throw new ErrorJuegoException(
                "No se pudo leer " + archivo.getAbsolutePath()
                + ". " + error.getMessage(), error
            );
        }
    }

    private int entero(Properties datos, String clave, int defecto)
    {
        String texto = datos.getProperty(clave);
        return texto == null ? defecto : Integer.parseInt(texto);
    }

    private String crearClave(String nombre) throws ErrorJuegoException
    {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new ErrorJuegoException("El nombre del jugador esta vacio.");
        }
        String normalizado = nombre.trim().toLowerCase(java.util.Locale.ROOT);
        return "jugador." + Base64.getUrlEncoder().withoutPadding()
            .encodeToString(normalizado.getBytes(StandardCharsets.UTF_8));
    }
}
