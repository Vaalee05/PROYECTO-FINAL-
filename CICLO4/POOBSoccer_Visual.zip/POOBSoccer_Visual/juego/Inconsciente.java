package juego;



/**
 * Representa el efecto Inconsciente producido
 * por el poder Tornado de Nigeria.
 *
 * Mientras esta activo, el jugador no puede
 * moverse, saltar ni patear.
 *
 * Diccionario de atributos:
 * duracion: tiempo que permanece activo el efecto.
 */
public class Inconsciente implements Efecto
{
    private double duracion;

    /**
     * Construye el efecto Inconsciente.
     */
    public Inconsciente()
    {
        duracion = 3.0;
    }

    /**
     * Activa el efecto sobre el jugador.
     *
     * @param objetivo jugador que recibe el efecto.
     */
    @Override
    public void iniciar(Jugador objetivo)
    {
        objetivo.setInconsciente(true);
    }

    /**
     * Finaliza el efecto sobre el jugador.
     *
     * @param objetivo jugador al que se le retira el efecto.
     */
    @Override
    public void finalizar(Jugador objetivo)
    {
        objetivo.setInconsciente(false);
    }

    /**
     * Retorna la duracion del efecto.
     *
     * @return duracion en segundos.
     */
    @Override
    public double getDuracion()
    {
        return duracion;
    }
}
