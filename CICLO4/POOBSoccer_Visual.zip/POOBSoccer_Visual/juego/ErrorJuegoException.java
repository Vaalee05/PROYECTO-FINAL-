package juego;

/**
 * Error especifico del juego con un mensaje entendible para la interfaz.
 * Permite conservar la causa tecnica para el registro de errores.
 */
public class ErrorJuegoException extends Exception
{
    private static final long serialVersionUID = 1L;

    public ErrorJuegoException(String mensaje, Throwable causa)
    {
        super(mensaje, causa);
    }

    public ErrorJuegoException(String mensaje)
    {
        super(mensaje);
    }
}
