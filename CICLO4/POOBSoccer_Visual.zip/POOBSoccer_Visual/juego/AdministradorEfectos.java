package juego;



/**
 * Administra los efectos temporales que recibe un jugador.
 *
 * Permite activar, reemplazar, actualizar y finalizar
 * los efectos especiales durante un partido.
 *
 * Solo puede existir un efecto especial activo
 * por jugador al mismo tiempo.
 *
 * Diccionario de atributos:
 * objetivo: jugador que recibe los efectos.
 * efectoActivo: efecto que se encuentra activo.
 * tiempoTranscurrido: tiempo transcurrido del efecto.
 */
public class AdministradorEfectos implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;
    private Jugador objetivo;
    private Efecto efectoActivo;
    private double tiempoTranscurrido;

    /**
     * Construye un administrador para un jugador.
     *
     * @param objetivo jugador cuyos efectos serán administrados.
     * @throws IllegalArgumentException si el jugador es null.
     */
    public AdministradorEfectos(Jugador objetivo)
    {
        if (objetivo == null) {
            throw new IllegalArgumentException(
                "El jugador no puede ser null."
            );
        }

        this.objetivo = objetivo;
        efectoActivo = null;
        tiempoTranscurrido = 0;
    }

    /**
     * Activa un efecto sobre el jugador.
     *
     * Si existe otro efecto activo, lo finaliza
     * antes de activar el nuevo.
     *
     * @param nuevoEfecto efecto que se desea activar.
     * @throws IllegalArgumentException si el efecto es null
     * o tiene una duración no válida.
     */
    public void activar(Efecto nuevoEfecto)
    {
        if (nuevoEfecto == null || nuevoEfecto.getDuracion() <= 0) {
            throw new IllegalArgumentException(
                "El efecto no es válido."
            );
        }

        if (efectoActivo != null) {
            efectoActivo.finalizar(objetivo);
        }

        efectoActivo = nuevoEfecto;
        tiempoTranscurrido = 0;

        efectoActivo.iniciar(objetivo);
    }

    /**
     * Actualiza el tiempo del efecto activo.
     *
     * Cuando se cumple su duración, el efecto finaliza
     * automáticamente.
     *
     * @param segundos tiempo transcurrido desde la última actualización.
     * @throws IllegalArgumentException si el tiempo es negativo.
     */
    public void actualizar(double segundos)
    {
        if (segundos < 0) {
            throw new IllegalArgumentException(
                "El tiempo no puede ser negativo."
            );
        }

        if (efectoActivo == null) {
            return;
        }

        tiempoTranscurrido += segundos;

        if (tiempoTranscurrido >= efectoActivo.getDuracion()) {
            finalizar();
        }
    }

    /**
     * Finaliza el efecto que se encuentra activo.
     */
    public void finalizar()
    {
        if (efectoActivo != null) {
            efectoActivo.finalizar(objetivo);
            efectoActivo = null;
            tiempoTranscurrido = 0;
        }
    }

    /**
     * Indica si existe un efecto activo.
     *
     * @return true si hay un efecto activo.
     */
    public boolean tieneEfectoActivo()
    {
        return efectoActivo != null;
    }

    /**
     * Retorna el efecto que está activo.
     *
     * @return efecto activo o null si no existe.
     */
    public Efecto getEfectoActivo()
    {
        return efectoActivo;
    }

    /**
     * Retorna el tiempo transcurrido del efecto.
     *
     * @return tiempo transcurrido en segundos.
     */
    public double getTiempoTranscurrido()
    {
        return tiempoTranscurrido;
    }
}
