package juego;

import java.io.File;
import java.io.IOException;
import java.util.logging.FileHandler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

/**
 * Registra errores de ejecucion en el directorio de datos del juego.
 *
 * Diccionario de atributos:
 * REGISTRO: escritor central para el archivo de errores.
 * configurado: evita crear multiples manejadores para el mismo archivo.
 */
public final class RegistroErrores
{
    private static final Logger REGISTRO = Logger.getLogger("doposoccer");
    private static File archivoLog =
        new File("datos/logs/doposoccer.log");
    private static boolean configurado;

    private RegistroErrores()
    {
    }

    /**
     * Cambia el destino del registro y cierra los escritores anteriores.
     *
     * @param destino archivo donde se guardan los mensajes.
     * @throws IllegalArgumentException si el archivo es nulo.
     */
    public static synchronized void configurarArchivo(File destino)
    {
        if (destino == null) {
            throw new IllegalArgumentException(
                "El archivo de registro es obligatorio."
            );
        }
        for (java.util.logging.Handler manejador : REGISTRO.getHandlers()) {
            manejador.close();
            REGISTRO.removeHandler(manejador);
        }
        archivoLog = destino;
        configurado = false;
        REGISTRO.setUseParentHandlers(false);
    }

    public static synchronized void registrar(String mensaje,
                                               Throwable error)
    {
        if (!configurado) {
            try {
                File carpeta = archivoLog.getAbsoluteFile().getParentFile();
                if (!carpeta.exists() && !carpeta.mkdirs()) {
                    throw new IOException(
                        "No se pudo crear " + carpeta.getAbsolutePath()
                    );
                }
                FileHandler archivo = new FileHandler(archivoLog.getPath(), true);
                archivo.setFormatter(new SimpleFormatter());
                REGISTRO.addHandler(archivo);
                REGISTRO.setUseParentHandlers(false);
                configurado = true;
            }
            catch (IOException problemaRegistro) {
                REGISTRO.log(Level.SEVERE,
                    "No se pudo crear el archivo de errores.",
                    problemaRegistro);
            }
        }

        if (error == null) {
            REGISTRO.severe(mensaje);
        }
        else {
            REGISTRO.log(Level.SEVERE, mensaje, error);
        }
    }
}
