package juego;

/**
 * Modos disponibles para disputar un partido.
 *
 * Diccionario de atributos:
 * nombre: texto mostrado al usuario para cada modalidad.
 */
public enum ModoPartida
{
    JUGADOR_VS_JUGADOR("Jugador contra jugador"),
    JUGADOR_VS_MAQUINA("Jugador contra maquina");

    private final String nombre;

    ModoPartida(String nombre)
    {
        this.nombre = nombre;
    }

    public String toString()
    {
        return nombre;
    }
}
