package juego;

/**
 * Copia visual temporal creada por el poder Ilusion.
 * No tiene colision ni puede marcar goles.
 *
 * Diccionario de atributos:
 * x, y: posicion de la copia.
 * vx, vy: velocidad visual.
 * vida: segundos hasta desaparecer.
 */
public class BalonFantasma implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;

    private double x;
    private double y;
    private double vx;
    private double vy;
    private double vida;

    public BalonFantasma(int x, int y, int vx, int vy, double vida)
    {
        this.x = x;
        this.y = y;
        this.vx = vx;
        this.vy = vy;
        this.vida = vida;
    }

    public void actualizar(double segundos, Cancha cancha)
    {
        double fotogramas = segundos * 60;
        x += vx * fotogramas;
        y += vy * fotogramas;
        vy += fotogramas;
        vida -= segundos;

        if (y < 12) {
            y = 12;
            vy = Math.abs(vy) * 0.7;
        }
        if (y > cancha.getSueloY() - 12) {
            y = cancha.getSueloY() - 12;
            vy = -Math.abs(vy) * 0.7;
        }
    }

    public boolean estaActivo()
    {
        return vida > 0;
    }

    public int getX()
    {
        return (int) Math.round(x);
    }

    public int getY()
    {
        return (int) Math.round(y);
    }

    public double getVida()
    {
        return Math.max(0, vida);
    }
}
