package juego;


/**
 * Representa las estadisticas y habilidades de un jugador
 * dentro del videojuego DOPOSoccer.
 *
 * Cada habilidad empieza en 1 y puede mejorarse hasta 10.
 *
 * Diccionario de atributos:
 * speed: velocidad de movimiento del jugador.
 * kick: potencia de las patadas.
 * jump: capacidad de salto.
 * survival: resistencia del jugador.
 * MAXIMO: valor maximo permitido para cada habilidad.
 * MINIMO: valor minimo permitido para cada habilidad.
 */
public class Estadisticas implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;
    private static final int MAXIMO = 10;
    private static final int MINIMO = 1;

    private int speed;
    private int kick;
    private int jump;
    private int survival;

    /**
     * Construye las estadisticas iniciales del jugador.
     * Todas las habilidades comienzan en 1.
     */
    public Estadisticas()
    {
        speed = MINIMO;
        kick = MINIMO;
        jump = MINIMO;
        survival = MINIMO;
    }

    /**
     * Construye estadisticas recuperadas del progreso del jugador.
     *
     * @param speed velocidad entre 1 y 10.
     * @param kick patada entre 1 y 10.
     * @param jump salto entre 1 y 10.
     * @param survival supervivencia entre 1 y 10.
     */
    public Estadisticas(int speed, int kick, int jump, int survival)
    {
        validar(speed, "Speed");
        validar(kick, "Kick");
        validar(jump, "Jump");
        validar(survival, "Survival");

        this.speed = speed;
        this.kick = kick;
        this.jump = jump;
        this.survival = survival;
    }

    private void validar(int valor, String nombre)
    {
        if (valor < MINIMO || valor > MAXIMO) {
            throw new IllegalArgumentException(
                nombre + " debe estar entre " + MINIMO + " y " + MAXIMO + "."
            );
        }
    }

    /**
     * Calcula el multiplicador correspondiente a una habilidad.
     *
     * @param valor nivel actual de la habilidad.
     * @return multiplicador con un aumento del 10 por ciento por nivel.
     */
    private double multiplicador(int valor)
    {
        return 1 + 0.10 * (valor - MINIMO);
    }

    public double getMultiplicadorSpeed()
    {
        return multiplicador(speed);
    }

    public double getMultiplicadorKick()
    {
        return multiplicador(kick);
    }

    public double getMultiplicadorJump()
    {
        return multiplicador(jump);
    }

    public double getMultiplicadorSurvival()
    {
        return multiplicador(survival);
    }

    public int getVidaMaxima()
    {
        return (int) Math.round(100 * getMultiplicadorSurvival());
    }

    /**
     * Consulta la velocidad del jugador.
     *
     * @return valor actual de velocidad.
     */
    public int getSpeed()
    {
        return speed;
    }

    /**
     * Consulta la potencia de patada del jugador.
     *
     * @return valor actual de patada.
     */
    public int getKick()
    {
        return kick;
    }

    /**
     * Consulta la capacidad de salto del jugador.
     *
     * @return valor actual de salto.
     */
    public int getJump()
    {
        return jump;
    }

    /**
     * Consulta la resistencia del jugador.
     *
     * @return valor actual de resistencia.
     */
    public int getSurvival()
    {
        return survival;
    }

    /**
     * Aumenta en un punto la velocidad si no ha alcanzado
     * el valor maximo permitido.
     *
     * @return true si la mejora se realizo, false si
     * ya alcanzo el limite.
     */
    public boolean mejorarSpeed()
    {
        if (speed < MAXIMO) {
            speed++;
            return true;
        }
        return false;
    }

    /**
     * Aumenta en un punto la potencia de patada.
     *
     * @return true si la mejora se realizo, false si
     * ya alcanzo el limite.
     */
    public boolean mejorarKick()
    {
        if (kick < MAXIMO) {
            kick++;
            return true;
        }
        return false;
    }

    /**
     * Aumenta en un punto la capacidad de salto.
     *
     * @return true si la mejora se realizo, false si
     * ya alcanzo el limite.
     */
    public boolean mejorarJump()
    {
        if (jump < MAXIMO) {
            jump++;
            return true;
        }
        return false;
    }

    /**
     * Aumenta en un punto la resistencia del jugador.
     *
     * @return true si la mejora se realizo, false si
     * ya alcanzo el limite.
     */
    public boolean mejorarSurvival()
    {
        if (survival < MAXIMO) {
            survival++;
            return true;
        }
        return false;
    }

    /**
     * Consulta el valor de una habilidad.
     *
     * @param atributo habilidad que se consulta.
     * @return nivel actual de la habilidad.
     */
    public int getValor(AtributoJugador atributo)
    {
        if (atributo == null) {
            throw new IllegalArgumentException(
                "La habilidad no puede ser nula."
            );
        }

        switch (atributo) {
            case SPEED:
                return speed;
            case KICK:
                return kick;
            case JUMP:
                return jump;
            case SURVIVAL:
                return survival;
            default:
                throw new IllegalArgumentException(
                    "La habilidad no esta reconocida."
                );
        }
    }

    /**
     * Mejora una habilidad si todavia no alcanzo su limite.
     *
     * @param atributo habilidad que se mejora.
     * @return true si subio un nivel.
     */
    public boolean mejorar(AtributoJugador atributo)
    {
        if (atributo == null) {
            throw new IllegalArgumentException(
                "La habilidad no puede ser nula."
            );
        }

        switch (atributo) {
            case SPEED:
                return mejorarSpeed();
            case KICK:
                return mejorarKick();
            case JUMP:
                return mejorarJump();
            case SURVIVAL:
                return mejorarSurvival();
            default:
                return false;
        }
    }
}

