package juego;




/**
 * Representa la estructura general de los poderes
 * especiales de DOPOSoccer.
 *
 * Centraliza la informacion compartida por todos
 * los poderes y permite asociarles un efecto.
 *
 * Diccionario de atributos:
 * nombre: nombre identificador del poder.
 * danoBase: daño base del poder.
 * duracion: duración del efecto en segundos.
 * efecto: efecto especial producido por el poder.
 */
public abstract class PoderBase implements Poder
{
    private static final long serialVersionUID = 1L;
    private String nombre;
    private int danoBase;
    private double duracion;
    private Efecto efecto;

    /**
     * Construye un poder con sus características generales.
     *
     * @param nombre nombre del poder.
     * @param danoBase daño base del poder.
     * @param duracion duración del efecto en segundos.
     * @param efecto efecto especial del poder.
     */
    public PoderBase(String nombre, int danoBase,
                     double duracion, Efecto efecto)
    {
        if (nombre == null || nombre.trim().isEmpty()
            || danoBase <= 0 || duracion <= 0 || efecto == null
            || Math.abs(duracion - efecto.getDuracion()) > 0.000001) {
            throw new IllegalArgumentException(
                "Los datos del poder no son validos."
            );
        }

        this.nombre = nombre;
        this.danoBase = danoBase;
        this.duracion = duracion;
        this.efecto = efecto;
    }

    /**
     * Retorna el nombre del poder.
     *
     * @return nombre del poder.
     */
    public String getNombre()
    {
        return nombre;
    }

    /**
     * Retorna el daño base del poder.
     *
     * @return daño base.
     */
    public int getDanoBase()
    {
        return danoBase;
    }

    /**
     * Retorna la duración del efecto.
     *
     * @return duración en segundos.
     */
    public double getDuracion()
    {
        return duracion;
    }

    /**
     * Retorna el efecto asociado al poder.
     *
     * @return efecto especial.
     */
    public Efecto getEfecto()
    {
        return efecto;
    }

    /**
     * Aplica un disparo especial horizontal con un rebote moderado.
     * Las subclases ajustan su trayectoria para distinguir cada poder.
     *
     * @param balon balon que recibe el disparo.
     * @param direccion sentido del disparo.
     */
    public void prepararDisparo(Balon balon, int direccion)
    {
        validarDisparo(balon, direccion);
        balon.setVelocidad(18 * direccion, -2);
        balon.setRebote(0.9);
    }

    protected void validarDisparo(Balon balon, int direccion)
    {
        if (balon == null || (direccion != 1 && direccion != -1)) {
            throw new IllegalArgumentException(
                "El balon y la direccion del disparo son obligatorios."
            );
        }
    }

    /**
     * Aplica el poder sobre un jugador objetivo.
     *
     * @param atacante jugador que utiliza el poder.
     * @param objetivo jugador que recibe el poder.
     */
    public abstract void aplicar(Jugador atacante, Jugador objetivo,
                             AdministradorEfectos administrador);
}
