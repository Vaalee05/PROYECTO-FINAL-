package juego;




/**
 * Representa un personaje seleccionable dentro del videojuego
 * DOPOSoccer.
 *
 * Cada personaje representa un pais y tiene asociado
 * un poder especial.
 *
 * Diccionario de atributos:
 * pais: pais al que pertenece el personaje.
 * nombre: nombre identificador del personaje.
 * imagen: ruta de la imagen que lo representa.
 * poder: habilidad especial del personaje.
 */
public class Personaje implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;
    private String pais;
    private String nombre;
    private String imagen;
    private Poder poder;

    /**
     * Construye un personaje con sus datos principales.
     *
     * Este constructor permite crear personajes sin asignar
     * un poder, por ejemplo durante algunas pruebas.
     *
     * @param pais pais del personaje.
     * @param nombre nombre identificador.
     * @param imagen ruta de la imagen.
     */
    public Personaje(String pais, String nombre, String imagen)
    {
        this(pais, nombre, imagen, null);
    }

    /**
     * Construye un personaje con su poder especial.
     *
     * @param pais pais del personaje.
     * @param nombre nombre identificador.
     * @param imagen ruta de la imagen.
     * @param poder habilidad especial.
     */
    public Personaje(String pais, String nombre,
                     String imagen, Poder poder)
    {
        if (pais == null || pais.trim().isEmpty()
            || nombre == null || nombre.trim().isEmpty()
            || imagen == null || imagen.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "Los datos del personaje no son validos."
            );
        }

        this.pais = pais;
        this.nombre = nombre;
        this.imagen = imagen;
        this.poder = poder;
    }

    /**
     * Obtiene el pais del personaje.
     *
     * @return pais al que pertenece.
     */
    public String getPais()
    {
        return pais;
    }

    /**
     * Obtiene el nombre del personaje.
     *
     * @return nombre del personaje.
     */
    public String getNombre()
    {
        return nombre;
    }

    /**
     * Obtiene la ruta de la imagen.
     *
     * @return ruta de la imagen.
     */
    public String getImagen()
    {
        return imagen;
    }

    /**
     * Obtiene el poder especial del personaje.
     *
     * @return poder asociado o null si no se ha asignado.
     */
    public Poder getPoder()
    {
        return poder;
    }
}

