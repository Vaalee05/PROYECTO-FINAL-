package juego;



/**
 * Representa la configuración de una partida.
 * Permite establecer si el partido se juega por tiempo
 * o por una cantidad determinada de goles, el tipo de rival
 * y el perfil de la maquina.
 *
 * Diccionario de atributos:
 * modalidad: final por tiempo o por goles.
 * tiempoLimite: duracion maxima expresada en segundos.
 * golesParaGanar: goles necesarios para terminar.
 * modo: enfrentamiento entre dos personas o contra la maquina.
 * perfilMaquina: comportamiento del oponente automatico.
 */
public class ConfiguracionPartido implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;
    private String modalidad;
    private int tiempoLimite;
    private int golesParaGanar;
    private ModoPartida modo;
    private PerfilMaquina perfilMaquina;

    /**
     * Construye una configuración para una partida.
     *
     * @param modalidad modalidad del partido: "TIEMPO" o "GOLES".
     * @param tiempoLimite duración del partido en segundos.
     * @param golesParaGanar cantidad de goles necesarios para ganar.
     */
    public ConfiguracionPartido(String modalidad, int tiempoLimite,
                                int golesParaGanar)
    {
        this(modalidad, tiempoLimite, golesParaGanar,
             ModoPartida.JUGADOR_VS_JUGADOR, PerfilMaquina.OFENSIVA);
    }

    /**
     * Construye una configuracion completa de partido.
     *
     * @param modalidad "TIEMPO" o "GOLES".
     * @param tiempoLimite duracion en segundos.
     * @param golesParaGanar goles para ganar.
     * @param modo modalidad de enfrentamiento.
     * @param perfilMaquina comportamiento del rival automatico.
     */
    public ConfiguracionPartido(String modalidad, int tiempoLimite,
                                int golesParaGanar, ModoPartida modo,
                                PerfilMaquina perfilMaquina)
    {
        if (modalidad == null ||
            (!modalidad.equals("TIEMPO") && !modalidad.equals("GOLES"))) {
            throw new IllegalArgumentException("Modalidad no válida.");
        }

        if (tiempoLimite <= 0 || golesParaGanar <= 0
            || modo == null || perfilMaquina == null) {
            throw new IllegalArgumentException("Los valores deben ser positivos.");
        }

        this.modalidad = modalidad;
        this.tiempoLimite = tiempoLimite;
        this.golesParaGanar = golesParaGanar;
        this.modo = modo;
        this.perfilMaquina = perfilMaquina;
    }

    /**
     * Obtiene la modalidad del partido.
     *
     * @return modalidad seleccionada.
     */
    public String getModalidad()
    {
        return modalidad;
    }

    /**
     * Obtiene el tiempo límite del partido.
     *
     * @return tiempo en segundos.
     */
    public int getTiempoLimite()
    {
        return tiempoLimite;
    }

    /**
     * Obtiene la cantidad de goles necesarios para ganar.
     *
     * @return cantidad de goles.
     */
    public int getGolesParaGanar()
    {
        return golesParaGanar;
    }

    /**
     * Indica si el partido se juega por tiempo.
     *
     * @return true si la modalidad es por tiempo.
     */
    public boolean esPorTiempo()
    {
        return modalidad.equals("TIEMPO");
    }

    /**
     * Indica si el partido se juega por goles.
     *
     * @return true si la modalidad es por goles.
     */
    public boolean esPorGoles()
    {
        return modalidad.equals("GOLES");
    }

    public ModoPartida getModo()
    {
        return modo;
    }

    public PerfilMaquina getPerfilMaquina()
    {
        return perfilMaquina;
    }
}
