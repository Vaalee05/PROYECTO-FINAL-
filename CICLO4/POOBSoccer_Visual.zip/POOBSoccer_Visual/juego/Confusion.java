package juego;



/**
 * Representa el efecto Confusion producido
 * por el poder Ilusion de Estados Unidos.
 *
 * Mientras esta activo, el rival no puede identificar
 * cual de los ocho balones es el verdadero.
 *
 * Diccionario de atributos:
 * duracion: tiempo que permanece activo el efecto.
 * cantidadBalones: cantidad de balones visualizados.
 */
public class Confusion implements Efecto
{
    private double duracion;
    private int cantidadBalones;

    /**
     * Construye el efecto Confusion.
     */
    public Confusion()
    {
        duracion = 2.5;
        cantidadBalones = 8;
    }

    /**
     * Activa el efecto de confusion.
     *
     * @param objetivo jugador que recibe el efecto.
     */
    @Override
    public void iniciar(Jugador objetivo)
    {
        objetivo.setConfundido(true);
    }

    /**
     * Finaliza el efecto de confusion.
     *
     * @param objetivo jugador al que se le retira el efecto.
     */
    @Override
    public void finalizar(Jugador objetivo)
    {
        objetivo.setConfundido(false);
    }

    /**
     * Retorna la duracion del efecto.
     *
     * @return duracion en segundos.
     */
    @Override
    public double getDuracion()
    {
        return duracion;
    }

    /**
     * Retorna la cantidad de balones visualizados.
     *
     * @return cantidad de balones.
     */
    public int getCantidadBalones()
    {
        return cantidadBalones;
    }
}
