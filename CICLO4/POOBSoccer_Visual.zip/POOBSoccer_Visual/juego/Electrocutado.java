package juego;



/**
 * Representa el efecto de electrocucion producido
 * por el poder Rayo de Camerun.
 *
 * Mientras esta activo, el jugador no puede saltar
 * y su velocidad se reduce a la mitad.
 *
 * Diccionario de atributos:
 * duracion: tiempo que permanece activo el efecto.
 */
public class Electrocutado implements Efecto
{
    private double duracion;

    /**
     * Construye el efecto de electrocucion.
     */
    public Electrocutado()
    {
        duracion = 3.0;
    }

    /**
     * Activa el efecto de electrocucion.
     *
     * @param objetivo jugador que recibe el efecto.
     */
    @Override
    public void iniciar(Jugador objetivo)
    {
        objetivo.setElectrocutado(true);
    }

    /**
     * Finaliza el efecto de electrocucion.
     *
     * @param objetivo jugador al que se le retira el efecto.
     */
    @Override
    public void finalizar(Jugador objetivo)
    {
        objetivo.setElectrocutado(false);
    }

    /**
     * Retorna la duracion del efecto.
     *
     * @return duracion en segundos.
     */
    @Override
    public double getDuracion()
    {
        return duracion;
    }
}
