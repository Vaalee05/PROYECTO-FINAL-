package juego;





/**
 * Representa el poder especial Ilusion
 * del personaje de Estados Unidos.
 *
 * Este poder divide visualmente el balon en ocho
 * balones identicos, siete de ellos falsos.
 */
public class Ilusion extends PoderBase
{
    private int cantidadBalones;

    @Override
    public void prepararDisparo(Balon balon, int direccion)
    {
        validarDisparo(balon, direccion);
        balon.setVelocidad(17 * direccion, -2);
        balon.setRebote(0.92);
    }

    /**
     * Construye el poder Ilusion.
     */
    public Ilusion()
    {
        super("Ilusion", 6, 2.5, new Confusion());
        cantidadBalones = 8;
    }

    /**
     * Aplica el daño y el efecto Confusion.
     *
     * @param atacante jugador que utiliza el poder.
     * @param objetivo jugador que recibe el impacto.
     * @param administrador administrador de efectos del objetivo.
     */
    @Override
    public void aplicar(Jugador atacante, Jugador objetivo,
                        AdministradorEfectos administrador)
    {
        if (atacante == null || objetivo == null || administrador == null) {
            throw new IllegalArgumentException(
                "Los jugadores y el administrador son obligatorios."
            );
        }

        double multiplicador = atacante.getEstadisticas()
            .getMultiplicadorKick();

        int dano = (int) Math.round(getDanoBase() * 5 * multiplicador);

        objetivo.recibirDanio(dano);
        administrador.activar(getEfecto());
    }

    /**
     * Retorna la cantidad de balones visualizados.
     *
     * @return cantidad de balones.
     */
    public int getCantidadBalones()
    {
        return cantidadBalones;
    }
}

