package juego;

/**
 * Crea personajes y poderes a partir del indice del selector.
 *
 * Patron Factory: concentra la creacion de los personajes disponibles
 * y evita repartir sus constructores por las ventanas.
 *
 * Diccionario de atributos:
 * No mantiene estado; los personajes se construyen al solicitarlos.
 */
public final class FabricaPersonajes
{
    private FabricaPersonajes()
    {
    }

    /**
     * Construye el personaje que corresponde a una opcion del selector.
     *
     * @param seleccion indice del personaje, de cero a tres.
     * @return personaje con su habilidad especial.
     */
    public static Personaje crear(int seleccion)
    {
        switch (seleccion) {
            case 0:
                return new Personaje(
                    "Corea del Sur", "Aura Azul", "auraAzul.png",
                    new AuraAzul()
                );
            case 1:
                return new Personaje(
                    "Camerún", "Rayo", "rayo.png", new Rayo()
                );
            case 2:
                return new Personaje(
                    "Nigeria", "Tornado", "tornado.png", new Tornado()
                );
            case 3:
                return new Personaje(
                    "Estados Unidos", "Ilusión", "ilusion.png",
                    new Ilusion()
                );
            default:
                throw new IllegalArgumentException(
                    "Seleccion de personaje no valida."
                );
        }
    }
}
