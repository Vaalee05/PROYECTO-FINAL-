package juego;




/**
 * Representa una patada normal dentro de DOPOSoccer.
 *
 * Permite atacar al rival o impulsar el balon,
 * dependiendo del objeto que se encuentre en el alcance.
 *
 * Diccionario de atributos:
 * ALCANCE_PIE: alcance del hitbox del pie durante la patada.
 * ALCANCE_RIVAL: alcance para golpear al jugador contrario.
 * IMPULSO: fuerza aplicada al balon.
 * IMPULSO_VERTICAL: elevacion inicial del balon.
 * DANIO_BASE: daño inicial de una patada.
 */
public class Patada implements java.io.Serializable
{
    private static final long serialVersionUID = 1L;
    private static final int ALCANCE_PIE = 36;
    private static final int ALCANCE_RIVAL = 75;
    private static final int IMPULSO = 13;
    private static final int IMPULSO_VERTICAL = 14;
    private static final int DANIO_BASE = 10;

    /**
     * Ejecuta una patada en la direccion indicada.
     *
     * Si el balon esta al alcance, lo impulsa en un arco para
     * que pueda rebotar al tocar el suelo u otro jugador.
     * De lo contrario, si el rival esta al alcance,
     * le aplica daño.
     *
     * @param atacante jugador que realiza la patada.
     * @param rival jugador contrario.
     * @param balon balon del partido.
     * @param direccion direccion del ataque: 1 derecha, -1 izquierda.
     * @return true si la patada alcanza un objetivo.
     */
    public boolean ejecutar(Jugador atacante, Jugador rival,
                            Balon balon, int direccion)
    {
        if (atacante == null || rival == null || balon == null) {
            throw new IllegalArgumentException(
                "Los participantes y el balon son obligatorios."
            );
        }

        if (direccion != 1 && direccion != -1) {
            throw new IllegalArgumentException(
                "La direccion debe ser 1 o -1."
            );
        }

        // El hitbox del pie existe solo durante esta accion de patada.
        int posicionPieX = atacante.getX() + direccion * 25;
        int posicionPieY = atacante.getY() + 5;

        if (estaAlcance(posicionPieX, posicionPieY,
                        balon.getX(), balon.getY(), ALCANCE_PIE)) {

            balon.setVelocidad(
                IMPULSO * direccion,
                -IMPULSO_VERTICAL
            );
            return true;
        }

        // Comprobar si alcanza al jugador contrario.
        if (estaAlcance(atacante.getX(), atacante.getY(),
                        rival.getX(), rival.getY(), ALCANCE_RIVAL)) {

            double multiplicadorKick = atacante.getEstadisticas()
                .getMultiplicadorKick();
                
            int dano = (int) Math.round(DANIO_BASE * multiplicadorKick);

            rival.recibirDanio(dano);
            return true;
        }

        return false;
    }

    /**
     * Comprueba si dos posiciones estan dentro del alcance.
     *
     * @param x1 posicion horizontal inicial.
     * @param y1 posicion vertical inicial.
     * @param x2 posicion horizontal del objetivo.
     * @param y2 posicion vertical del objetivo.
     * @param alcance distancia maxima entre las posiciones.
     * @return true si el objetivo esta al alcance.
     */
    private boolean estaAlcance(int x1, int y1, int x2, int y2,
                                int alcance)
    {
        int diferenciaX = x2 - x1;
        int diferenciaY = y2 - y1;

        return Math.sqrt(
            diferenciaX * diferenciaX + diferenciaY * diferenciaY
        ) <= alcance;
    }
}
