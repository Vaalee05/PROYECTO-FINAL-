package juego;



/**
 * Representa el efecto Empuje producido
 * por el poder Aura Azul de Corea del Sur.
 *
 * Este efecto lanza al rival hacia su propio arco
 * durante un segundo y medio.
 *
 * Diccionario de atributos:
 * duracion: tiempo que permanece activo el efecto.
 */
public class Empuje implements Efecto
{
    private double duracion;

    /**
     * Construye el efecto Empuje.
     */
    public Empuje()
    {
        duracion = 1.5;
    }

    /**
     * Activa el efecto Empuje sobre el jugador.
     *
     * @param objetivo jugador que recibe el efecto.
     */
    @Override
    public void iniciar(Jugador objetivo)
    {
        objetivo.setEmpujado(true);
    }

    /**
     * Finaliza el efecto Empuje.
     *
     * @param objetivo jugador al que se le retira el efecto.
     */
    @Override
    public void finalizar(Jugador objetivo)
    {
        objetivo.setEmpujado(false);
        objetivo.setDireccionEmpuje(0);
    }

    /**
     * Retorna la duración del efecto.
     *
     * @return duración en segundos.
     */
    @Override
    public double getDuracion()
    {
        return duracion;
    }
}
