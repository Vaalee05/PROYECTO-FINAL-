package juego;

/**
 * Perfil persistente con estadisticas, puntos y coste de mejora.
 *
 * Diccionario de atributos:
 * estadisticas: niveles actuales del jugador.
 * puntos: moneda acumulada para comprar mejoras.
 * costoSiguienteMejora: precio de la proxima mejora.
 */
public class ProgresoJugador
{
    private Estadisticas estadisticas;
    private int puntos;
    private int costoSiguienteMejora;

    public ProgresoJugador()
    {
        estadisticas = new Estadisticas();
        puntos = 0;
        costoSiguienteMejora = 500;
    }

    public Estadisticas getEstadisticas()
    {
        return estadisticas;
    }

    public int getPuntos()
    {
        return puntos;
    }

    public int getCostoSiguienteMejora()
    {
        return costoSiguienteMejora;
    }

    public void establecer(Estadisticas estadisticas, int puntos,
                           int costoSiguienteMejora)
    {
        if (estadisticas == null || puntos < 0 || costoSiguienteMejora < 500) {
            throw new IllegalArgumentException(
                "Los datos del progreso no son validos."
            );
        }
        this.estadisticas = estadisticas;
        this.puntos = puntos;
        this.costoSiguienteMejora = costoSiguienteMejora;
    }

    public void agregarPuntos(int cantidad)
    {
        if (cantidad < 0) {
            throw new IllegalArgumentException(
                "Los puntos no pueden ser negativos."
            );
        }
        puntos += cantidad;
    }

    public boolean mejorar(AtributoJugador atributo)
    {
        if (atributo == null || puntos < costoSiguienteMejora
            || estadisticas.getValor(atributo) >= 10) {
            return false;
        }
        estadisticas.mejorar(atributo);
        puntos -= costoSiguienteMejora;
        costoSiguienteMejora = costoSiguienteMejora > Integer.MAX_VALUE / 2
            ? Integer.MAX_VALUE : costoSiguienteMejora * 2;
        return true;
    }
}
