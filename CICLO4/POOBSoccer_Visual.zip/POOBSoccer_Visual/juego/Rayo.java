package juego;





/**
 * Representa el poder especial Rayo
 * del personaje de Camerun.
 *
 * Este poder cubre el tiro con electricidad; al impactar
 * causa daño y electrocuta al rival.
 */
public class Rayo extends PoderBase
{
    @Override
    public void prepararDisparo(Balon balon, int direccion)
    {
        validarDisparo(balon, direccion);
        balon.setVelocidad(22 * direccion, -2);
        balon.setRebote(0.82);
    }

    /**
     * Construye el poder Rayo.
     */
    public Rayo()
    {
        super("Rayo", 12, 3.0, new Electrocutado());
    }

    /**
     * Aplica el daño y el efecto de electrocucion.
     *
     * @param atacante jugador que utiliza el poder.
     * @param objetivo jugador que recibe el impacto.
     * @param administrador administrador de efectos del objetivo.
     */
    @Override
    public void aplicar(Jugador atacante, Jugador objetivo,
                        AdministradorEfectos administrador)
    {
        if (atacante == null || objetivo == null || administrador == null) {
            throw new IllegalArgumentException(
                "Los jugadores y el administrador son obligatorios."
            );
        }

        double multiplicador = atacante.getEstadisticas()
            .getMultiplicadorKick();

        int dano = (int) Math.round(getDanoBase() * 5 * multiplicador);

        objetivo.recibirDanio(dano);
        administrador.activar(getEfecto());
    }
}

