package juego;





/**
 * Representa el poder especial Tornado
 * del personaje de Nigeria.
 *
 * Este poder genera un remolino a ras del suelo
 * que lanza al rival por el aire y lo deja inconsciente.
 */
public class Tornado extends PoderBase
{
    @Override
    public void prepararDisparo(Balon balon, int direccion)
    {
        validarDisparo(balon, direccion);
        balon.setVelocidad(15 * direccion, -3);
        balon.setRebote(1.05);
    }

    /**
     * Construye el poder Tornado.
     */
    public Tornado()
    {
        super("Tornado", 8, 3.0, new Inconsciente());
    }

    /**
     * Aplica el daño y el efecto Inconsciente.
     *
     * @param atacante jugador que utiliza el poder.
     * @param objetivo jugador que recibe el impacto.
     * @param administrador administrador de efectos del objetivo.
     */
    @Override
    public void aplicar(Jugador atacante, Jugador objetivo,
                        AdministradorEfectos administrador)
    {
        if (atacante == null || objetivo == null || administrador == null) {
            throw new IllegalArgumentException(
                "Los jugadores y el administrador son obligatorios."
            );
        }

        double multiplicador = atacante.getEstadisticas()
            .getMultiplicadorKick();

        int dano = (int) Math.round(getDanoBase() * 5 * multiplicador);

        objetivo.recibirDanio(dano);
        administrador.activar(getEfecto());
    }
}


