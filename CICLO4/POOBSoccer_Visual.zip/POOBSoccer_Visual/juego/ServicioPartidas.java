package juego;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputFilter;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.nio.file.Files;
import java.nio.file.StandardCopyOption;
import java.nio.file.AtomicMoveNotSupportedException;

/**
 * Guarda y recupera el estado completo de un partido.
 *
 * Diccionario de atributos:
 * Esta clase es un servicio sin estado; opera sobre archivos elegidos
 * por la persona desde la interfaz.
 */
public final class ServicioPartidas
{
    private ServicioPartidas()
    {
    }

    /**
     * Escribe el estado del partido en un archivo temporal y lo reemplaza.
     *
     * @param juego estado que se conserva.
     * @param destino archivo elegido en el menu.
     * @throws ErrorJuegoException si ocurre un problema de escritura.
     */
    public static void guardar(Juego juego, File destino)
        throws ErrorJuegoException
    {
        if (juego == null || destino == null) {
            throw new ErrorJuegoException(
                "El partido y el archivo de destino son obligatorios."
            );
        }

        File temporal = new File(destino.getAbsolutePath() + ".tmp");
        try {
            File carpeta = destino.getAbsoluteFile().getParentFile();
            if (carpeta != null && !carpeta.exists() && !carpeta.mkdirs()) {
                throw new IOException("No se pudo crear la carpeta destino.");
            }

            try (ObjectOutputStream salida = new ObjectOutputStream(
                    new FileOutputStream(temporal))) {
                salida.writeObject(juego);
                salida.flush();
            }

            try {
                Files.move(temporal.toPath(), destino.toPath(),
                    StandardCopyOption.REPLACE_EXISTING,
                    StandardCopyOption.ATOMIC_MOVE);
            }
            catch (AtomicMoveNotSupportedException ignorada) {
                Files.move(temporal.toPath(), destino.toPath(),
                    StandardCopyOption.REPLACE_EXISTING);
            }
        }
        catch (IOException | SecurityException error) {
            temporal.delete();
            RegistroErrores.registrar("Error al guardar un partido.", error);
            throw new ErrorJuegoException(
                "No se pudo guardar el partido en "
                + destino.getAbsolutePath() + ". " + error.getMessage(), error
            );
        }
    }

    /**
     * Recupera un partido y limita las clases admitidas al leerlo.
     *
     * @param origen archivo de partida.
     * @return estado recuperado.
     * @throws ErrorJuegoException si el archivo no puede recuperarse.
     */
    public static Juego abrir(File origen) throws ErrorJuegoException
    {
        if (origen == null || !origen.isFile()) {
            throw new ErrorJuegoException(
                "Selecciona un archivo de partido existente."
            );
        }

        try {
            long tamano = Files.size(origen.toPath());
            if (tamano <= 0 || tamano > 20_000_000) {
                throw new ErrorJuegoException(
                    "El archivo esta vacio o supera el tamano permitido."
                );
            }

            try (ObjectInputStream entrada = new ObjectInputStream(
                    new FileInputStream(origen))) {
                entrada.setObjectInputFilter(ServicioPartidas::filtrarClase);
                Object objeto = entrada.readObject();
                if (!(objeto instanceof Juego)) {
                    throw new ErrorJuegoException(
                        "El archivo no contiene una partida de DOPOSoccer."
                    );
                }
                return (Juego) objeto;
            }
        }
        catch (ErrorJuegoException error) {
            throw error;
        }
        catch (java.io.StreamCorruptedException error) {
            RegistroErrores.registrar(
                "El archivo de partida tiene un formato invalido.", error
            );
            throw new ErrorJuegoException(
                "El archivo no es una partida valida o esta danado. "
                + "Guarda una partida nueva y vuelve a intentarlo.", error
            );
        }
        catch (IOException | ClassNotFoundException | SecurityException error) {
            RegistroErrores.registrar("Error al abrir un partido.", error);
            throw new ErrorJuegoException(
                "No se pudo abrir el partido: " + error.getMessage(), error
            );
        }
    }

    private static ObjectInputFilter.Status filtrarClase(
        ObjectInputFilter.FilterInfo datos)
    {
        if (datos.depth() > 60 || datos.references() > 20000
            || datos.streamBytes() > 20_000_000) {
            return ObjectInputFilter.Status.REJECTED;
        }

        Class<?> tipo = datos.serialClass();
        if (tipo == null) {
            return ObjectInputFilter.Status.UNDECIDED;
        }
        while (tipo.isArray()) {
            tipo = tipo.getComponentType();
        }
        if (tipo.isPrimitive()) {
            return ObjectInputFilter.Status.ALLOWED;
        }

        String nombre = tipo.getName();
        if (nombre.startsWith("juego.")
            || nombre.equals("java.lang.String")
            || nombre.equals("java.lang.Enum")
            || nombre.startsWith("java.util.ArrayList")) {
            return ObjectInputFilter.Status.ALLOWED;
        }
        return ObjectInputFilter.Status.REJECTED;
    }
}
