package juego;

/**
 * Habilidades que el jugador puede mejorar con puntos.
 *
 * Diccionario de valores:
 * SPEED: velocidad de movimiento.
 * KICK: multiplicador de dano.
 * JUMP: altura del salto.
 * SURVIVAL: vida maxima.
 */
public enum AtributoJugador
{
    SPEED("Speed"),
    KICK("Kick"),
    JUMP("Jump"),
    SURVIVAL("Survival");

    private final String nombreVisible;

    AtributoJugador(String nombreVisible)
    {
        this.nombreVisible = nombreVisible;
    }

    public String toString()
    {
        return nombreVisible;
    }
}
