
package interfaz;

import juego.*;
import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

/**
 * Representa la ventana donde se desarrolla el partido.
 * Muestra la cancha, los jugadores, el balon y el marcador.
 */
public class VentanaPartido extends JFrame
{
    private Juego juego;
    private PanelCancha panelCancha;
    private Timer temporizador;

    /**
     * Construye la ventana del partido.
     *
     * @param juego partida que se va a representar.
     */
    public VentanaPartido(Juego juego)
    {
        if (juego == null) {
            throw new IllegalArgumentException(
                "El juego no puede ser nulo."
            );
        }

        this.juego = juego;

        setTitle("DOPOSoccer - Partido");
        setSize(950, 580);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        panelCancha = new PanelCancha();
        add(panelCancha);

        configurarControles();

        juego.iniciarPartido();

        temporizador = new Timer(16, e -> {
            juego.actualizar();
            panelCancha.repaint();
        });

        temporizador.start();
    }

    /**
     * Configura los controles de los dos jugadores.
     */
    private void configurarControles()
    {
        panelCancha.setFocusable(true);

        panelCancha.addKeyListener(new KeyAdapter() {
            public void keyPressed(KeyEvent e)
            {
                int tecla = e.getKeyCode();

                if (tecla == KeyEvent.VK_A) {
                    juego.moverJugador1Izquierda();
                }
                else if (tecla == KeyEvent.VK_D) {
                    juego.moverJugador1Derecha();
                }
                else if (tecla == KeyEvent.VK_W) {
                    juego.saltarJugador1();
                }
                else if (tecla == KeyEvent.VK_SPACE) {
                    juego.patadaJugador1();
                }
                else if (tecla == KeyEvent.VK_F) {
                    juego.lanzarPoderJugador1();
                }

                if (tecla == KeyEvent.VK_LEFT) {
                    juego.moverJugador2Izquierda();
                }
                else if (tecla == KeyEvent.VK_RIGHT) {
                    juego.moverJugador2Derecha();
                }
                else if (tecla == KeyEvent.VK_UP) {
                    juego.saltarJugador2();
                }
                else if (tecla == KeyEvent.VK_ENTER) {
                    juego.patadaJugador2();
                }
                else if (tecla == KeyEvent.VK_L) {
                    juego.lanzarPoderJugador2();
                }
            }
        });

        panelCancha.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e)
            {
                panelCancha.requestFocusInWindow();
            }
        });

        panelCancha.requestFocusInWindow();
    }

    /**
     * Panel encargado de dibujar los elementos del partido.
     */
    private class PanelCancha extends JPanel
    {
        /**
         * Dibuja la cancha y los elementos del partido.
         *
         * @param g contexto grafico.
         */
        protected void paintComponent(Graphics g)
        {
            super.paintComponent(g);

            Graphics2D dibujo = (Graphics2D) g;

            int ancho = getWidth();
            int alto = getHeight();

            dibujo.setColor(new Color(35, 135, 65));
            dibujo.fillRect(0, 0, ancho, alto);

            dibujo.setColor(Color.WHITE);
            dibujo.setStroke(new BasicStroke(3));

            dibujo.drawRect(20, 20, ancho - 40, alto - 40);
            dibujo.drawLine(ancho / 2, 20, ancho / 2, alto - 20);

            dibujo.drawOval(
                ancho / 2 - 70,
                alto / 2 - 70,
                140,
                140
            );

            dibujo.drawRect(20, alto / 2 - 90, 100, 180);
            dibujo.drawRect(ancho - 120, alto / 2 - 90, 100, 180);

            dibujarMarcador(dibujo, ancho);

            dibujarJugador(
                dibujo,
                juego.getJugador1(),
                Color.BLUE
            );

            dibujarJugador(
                dibujo,
                juego.getJugador2(),
                Color.RED
            );

            Balon balon = juego.getBalon();

            dibujo.setColor(Color.WHITE);
            dibujo.fillOval(
                balon.getX() - balon.getRadio(),
                balon.getY() - balon.getRadio(),
                balon.getRadio() * 2,
                balon.getRadio() * 2
            );

            dibujarProyectiles(dibujo);
        }

        /**
         * Dibuja el marcador del partido.
         *
         * @param g contexto grafico.
         * @param ancho ancho del panel.
         */
        private void dibujarMarcador(Graphics2D g, int ancho)
        {
            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 24));

            String texto =
                juego.getJugador1().getNombre() + "  "
                + juego.getMarcador().getGolesJugador1()
                + " - "
                + juego.getMarcador().getGolesJugador2()
                + "  "
                + juego.getJugador2().getNombre();

            FontMetrics medidas = g.getFontMetrics();

            g.drawString(
                texto,
                (ancho - medidas.stringWidth(texto)) / 2,
                55
            );
        }

        /**
         * Dibuja un jugador en su posicion actual.
         *
         * @param g contexto grafico.
         * @param jugador jugador que se dibuja.
         * @param color color identificador.
         */
        private void dibujarJugador(
            Graphics2D g, Jugador jugador, Color color)
        {
            int x = jugador.getX();
            int y = jugador.getY();

            g.setColor(color);
            g.fillOval(x - 20, y - 30, 40, 40);

            g.setColor(Color.WHITE);
            g.setFont(new Font("Arial", Font.BOLD, 12));

            g.drawString(
                jugador.getNombre(),
                x - 30,
                y - 40
            );

            g.setColor(Color.RED);
            g.fillRect(x - 20, y - 50, 40, 6);

            g.setColor(Color.GREEN);
            int vida = (int) (
                40.0 * jugador.getVidaActual()
                / jugador.getVidaMaxima()
            );

            g.fillRect(x - 20, y - 50, vida, 6);
        }

        /**
         * Dibuja los proyectiles especiales activos.
         *
         * @param g contexto grafico.
         */
        private void dibujarProyectiles(Graphics2D g)
        {
            Proyectil p1 = juego.getProyectilJugador1();
            Proyectil p2 = juego.getProyectilJugador2();

            g.setColor(Color.CYAN);

            if (p1 != null) {
                g.fillOval(p1.getX() - 10, p1.getY() - 10, 20, 20);
            }

            if (p2 != null) {
                g.fillOval(p2.getX() - 10, p2.getY() - 10, 20, 20);
            }
        }
    }
}
