package interfaz;

import javax.swing.*;
import java.awt.*;
import juego.*;

/**
 * Permite ingresar los nombres y seleccionar
 * los personajes de los dos jugadores.
 */
public class SeleccionPersonajes extends JFrame
{
    private JTextField nombreJugador1;
    private JTextField nombreJugador2;

    private JComboBox<String> seleccionJugador1;
    private JComboBox<String> seleccionJugador2;

    /**
     * Construye la ventana de seleccion de personajes.
     */
    public SeleccionPersonajes()
    {
        setTitle("Seleccion de personajes - DOPOSoccer");
        setSize(650, 400);
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        setLocationRelativeTo(null);
        setResizable(false);

        JPanel panel = new JPanel(new GridLayout(6, 1, 10, 10));
        panel.setBorder(
            BorderFactory.createEmptyBorder(20, 40, 20, 40)
        );

        JLabel titulo = new JLabel(
            "Configuracion de jugadores",
            SwingConstants.CENTER
        );

        titulo.setFont(new Font("Arial", Font.BOLD, 24));

        String[] personajes = {
            "Corea del Sur - Aura Azul",
            "Camerun - Rayo",
            "Nigeria - Tornado",
            "Estados Unidos - Ilusion"
        };

        nombreJugador1 = new JTextField();
        nombreJugador2 = new JTextField();

        seleccionJugador1 = new JComboBox<>(personajes);
        seleccionJugador2 = new JComboBox<>(personajes);

        JButton botonContinuar = new JButton("Continuar");

        panel.add(titulo);
        panel.add(crearPanel("Nombre del jugador 1:", nombreJugador1));
        panel.add(crearPanel("Personaje del jugador 1:", seleccionJugador1));
        panel.add(crearPanel("Nombre del jugador 2:", nombreJugador2));
        panel.add(crearPanel("Personaje del jugador 2:", seleccionJugador2));
        panel.add(botonContinuar);

        add(panel);

        botonContinuar.addActionListener(e -> confirmarSeleccion());
    }

    /**
     * Crea una fila con una etiqueta y un componente.
     *
     * @param texto texto descriptivo.
     * @param componente componente de entrada.
     * @return panel creado.
     */
    private JPanel crearPanel(String texto, JComponent componente)
    {
        JPanel panel = new JPanel(new GridLayout(1, 2, 10, 5));

        panel.add(new JLabel(texto));
        panel.add(componente);

        return panel;
    }

    /**
     * Comprueba los datos y construye la partida.
     */
    private void confirmarSeleccion()
    {
        String nombre1 = nombreJugador1.getText().trim();
        String nombre2 = nombreJugador2.getText().trim();
    
        if (nombre1.isEmpty() || nombre2.isEmpty()) {
            JOptionPane.showMessageDialog(
                this,
                "Ambos jugadores deben ingresar su nombre."
            );
            return;
        }
    
        Personaje personaje1 = crearPersonaje(
            seleccionJugador1.getSelectedIndex()
        );
    
        Personaje personaje2 = crearPersonaje(
            seleccionJugador2.getSelectedIndex()
        );
    
        Jugador jugador1 = new Jugador(
            nombre1, personaje1, new Estadisticas()
        );
    
        Jugador jugador2 = new Jugador(
            nombre2, personaje2, new Estadisticas()
        );
    
        Cancha cancha = new Cancha(
            900, 500, "900x500"
        );
    
        Juego juego = new Juego(
            jugador1, jugador2, cancha
        );
    
        VentanaPartido ventana = new VentanaPartido(juego);
        ventana.setVisible(true);
    
        dispose();
    }
    
    /**
     * Construye el personaje correspondiente a la seleccion.
     *
     * @param seleccion indice del personaje seleccionado.
     * @return personaje con su poder especial.
     */
    private Personaje crearPersonaje(int seleccion)
    {
        switch (seleccion) {
            case 0:
                return new Personaje(
                    "Corea del Sur",
                    "Aura Azul",
                    "auraAzul.png",
                    new AuraAzul()
                );
    
            case 1:
                return new Personaje(
                    "Camerun",
                    "Rayo",
                    "rayo.png",
                    new Rayo()
                );
    
            case 2:
                return new Personaje(
                    "Nigeria",
                    "Tornado",
                    "tornado.png",
                    new Tornado()
                );
    
            case 3:
                return new Personaje(
                    "Estados Unidos",
                    "Ilusion",
                    "ilusion.png",
                    new Ilusion()
                );
    
            default:
                throw new IllegalArgumentException(
                    "Seleccion de personaje no valida."
                );
        }
    }

}