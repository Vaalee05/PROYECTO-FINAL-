package juego;





/**
 * Representa el poder especial Aura Azul
 * del personaje de Corea del Sur.
 *
 * Este poder produce un proyectil horizontal
 * que empuja al rival hacia su propio arco.
 */
public class AuraAzul extends PoderBase
{
    /**
     * Construye el poder Aura Azul.
     */
    public AuraAzul()
    {
        super("Aura Azul", 8, 1.5, new Empuje());
    }

    /**
     * Aplica el daño y el efecto Empuje al rival.
     *
     * @param atacante jugador que utiliza el poder.
     * @param objetivo jugador que recibe el impacto.
     * @param administrador administrador de efectos del objetivo.
     */
    @Override
    public void aplicar(Jugador atacante, Jugador objetivo,
                        AdministradorEfectos administrador)
    {
        if (atacante == null || objetivo == null || administrador == null) {
            throw new IllegalArgumentException(
                "Los jugadores y el administrador son obligatorios."
            );
        }

        double multiplicador =
            1 + 0.10 * (atacante.getEstadisticas().getKick() - 1);

        int dano = (int) Math.round(getDanoBase() * multiplicador);

        objetivo.recibirDanio(dano);
        administrador.activar(getEfecto());
    }
}
