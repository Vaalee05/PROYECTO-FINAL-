package juego;




/**
 * Representa el terreno de juego del videojuego DOPOSoccer.
 *
 * Administra las dimensiones, los limites y la ubicacion
 * de las porterias.
 *
 * Diccionario de atributos:
 * ancho: dimension horizontal de la cancha.
 * alto: dimension vertical de la cancha.
 * resolucion: nombre de la resolucion seleccionada.
 * anchoPorteria: ancho de cada porteria.
 * altoPorteria: alto de cada porteria.
 * posicionPorteriaIzquierda: posicion horizontal izquierda.
 * posicionPorteriaDerecha: posicion horizontal derecha.
 * posicionPorteriaY: posicion vertical superior de las porterias.
 */
public class Cancha
{
    private int ancho;
    private int alto;
    private String resolucion;
    private int anchoPorteria;
    private int altoPorteria;
    private int posicionPorteriaIzquierda;
    private int posicionPorteriaDerecha;
    private int posicionPorteriaY;

    /**
     * Construye una cancha con las dimensiones indicadas.
     *
     * @param ancho dimension horizontal.
     * @param alto dimension vertical.
     * @param resolucion nombre de la resolucion.
     * @throws IllegalArgumentException si los datos son invalidos.
     */
    public Cancha(int ancho, int alto, String resolucion)
    {
        if (ancho <= 120 || alto <= 100
            || resolucion == null || resolucion.trim().isEmpty()) {
            throw new IllegalArgumentException(
                "Las dimensiones o la resolucion no son validas."
            );
        }

        this.ancho = ancho;
        this.alto = alto;
        this.resolucion = resolucion;

        anchoPorteria = 60;
        altoPorteria = 100;

        posicionPorteriaIzquierda = 0;
        posicionPorteriaDerecha = ancho - anchoPorteria;
        posicionPorteriaY = (alto - altoPorteria) / 2;
    }

    public int getAncho()
    {
        return ancho;
    }

    public int getAlto()
    {
        return alto;
    }

    public String getResolucion()
    {
        return resolucion;
    }

    public int getAnchoPorteria()
    {
        return anchoPorteria;
    }

    public int getAltoPorteria()
    {
        return altoPorteria;
    }

    public int getPosicionPorteriaIzquierda()
    {
        return posicionPorteriaIzquierda;
    }

    public int getPosicionPorteriaDerecha()
    {
        return posicionPorteriaDerecha;
    }

    public int getPosicionPorteriaY()
    {
        return posicionPorteriaY;
    }

    /**
     * Comprueba si una coordenada horizontal esta dentro
     * de los limites de la cancha.
     *
     * @param x coordenada horizontal.
     * @return true si esta dentro de la cancha.
     */
    public boolean estaDentroHorizontal(int x)
    {
        return x >= 0 && x <= ancho;
    }

    /**
     * Comprueba si una coordenada vertical esta dentro
     * de los limites de la cancha.
     *
     * @param y coordenada vertical.
     * @return true si esta dentro de la cancha.
     */
    public boolean estaDentroVertical(int y)
    {
        return y >= 0 && y <= alto;
    }

    /**
     * Comprueba si una coordenada vertical esta dentro
     * de la abertura de la porteria.
     *
     * @param y coordenada vertical.
     * @return true si esta dentro de la porteria.
     */
    public boolean estaEnZonaPorteria(int y)
    {
        return y >= posicionPorteriaY
            && y <= posicionPorteriaY + altoPorteria;
    }
}
