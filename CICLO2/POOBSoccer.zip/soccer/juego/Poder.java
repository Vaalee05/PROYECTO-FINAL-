package juego;



/**
 * Define el comportamiento de los poderes especiales
 * de los personajes de DOPOSoccer.
 */
public interface Poder
{
    /**
     * Aplica el poder sobre un jugador objetivo.
     *
     * @param atacante jugador que utiliza el poder.
     * @param objetivo jugador que recibe el impacto.
     * @param administrador administrador de los efectos del objetivo.
     */
    void aplicar(Jugador atacante, Jugador objetivo,
                 AdministradorEfectos administrador);

    /**
     * Retorna el nombre del poder.
     *
     * @return nombre del poder.
     */
    String getNombre();

    /**
     * Retorna el daño base del poder.
     *
     * @return daño base.
     */
    int getDanoBase();

    /**
     * Retorna la duración del efecto.
     *
     * @return duración en segundos.
     */
    double getDuracion();
}
