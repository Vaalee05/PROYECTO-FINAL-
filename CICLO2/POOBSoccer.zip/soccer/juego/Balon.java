package juego;




/**
 * Representa el balon utilizado durante los partidos
 * del videojuego DOPOSoccer.
 *
 * Administra su posicion, velocidad, movimiento y rebotes.
 *
 * Diccionario de atributos:
 * x: posicion horizontal del balon.
 * y: posicion vertical del balon.
 * vx: velocidad horizontal del balon.
 * vy: velocidad vertical del balon.
 * radio: radio del balon.
 * GRAVEDAD: aceleracion vertical aplicada al balon.
 * REBOTE: factor de conservacion de velocidad al rebotar.
 */
public class Balon
{
    private static final int GRAVEDAD = 1;
    private static final double REBOTE = 0.8;

    private int x;
    private int y;
    private int vx;
    private int vy;
    private int radio;

    /**
     * Construye un balon en una posicion determinada.
     *
     * @param x posicion horizontal inicial.
     * @param y posicion vertical inicial.
     * @param radio radio del balon.
     * @throws IllegalArgumentException si el radio no es valido.
     */
    public Balon(int x, int y, int radio)
    {
        if (radio <= 0) {
            throw new IllegalArgumentException(
                "El radio debe ser mayor que cero."
            );
        }

        this.x = x;
        this.y = y;
        this.radio = radio;
        vx = 0;
        vy = 0;
    }

    public int getX()
    {
        return x;
    }

    public int getY()
    {
        return y;
    }

    public int getVx()
    {
        return vx;
    }

    public int getVy()
    {
        return vy;
    }

    public int getRadio()
    {
        return radio;
    }

    /**
     * Establece la velocidad horizontal y vertical.
     *
     * @param vx nueva velocidad horizontal.
     * @param vy nueva velocidad vertical.
     */
    public void setVelocidad(int vx, int vy)
    {
        this.vx = vx;
        this.vy = vy;
    }

    /**
     * Actualiza la posicion usando las velocidades actuales.
     */
    public void actualizar()
    {
        x += vx;
        y += vy;
    }

    /**
     * Actualiza el movimiento del balon dentro de la cancha.
     *
     * Aplica gravedad y rebotes en el techo, suelo y laterales.
     * Permite que el balon atraviese los laterales cuando
     * se encuentra en la zona vertical de una porteria.
     *
     * @param cancha cancha donde se mueve el balon.
     * @throws IllegalArgumentException si la cancha es nula.
     */
    public void actualizar(Cancha cancha)
    {
        if (cancha == null) {
            throw new IllegalArgumentException(
                "La cancha no puede ser nula."
            );
        }

        // Aplicar gravedad.
        vy += GRAVEDAD;

        // Actualizar posicion.
        x += vx;
        y += vy;

        // Rebote contra el techo.
        if (y - radio < 0) {
            y = radio;
            vy = (int) (Math.abs(vy) * REBOTE);
        }

        // Rebote contra el suelo.
        if (y + radio > cancha.getAlto()) {
            y = cancha.getAlto() - radio;
            vy = -(int) (Math.abs(vy) * REBOTE);

            if (Math.abs(vy) < 1) {
                vy = 0;
            }
        }

        // Comprobar si el balon esta en la zona de porteria.
        boolean enPorteria = cancha.estaEnZonaPorteria(y);

        // Rebote contra el lateral izquierdo.
        if (x - radio < 0 && !enPorteria) {
            x = radio;
            vx = Math.abs(vx);
        }

        // Rebote contra el lateral derecho.
        if (x + radio > cancha.getAncho() && !enPorteria) {
            x = cancha.getAncho() - radio;
            vx = -Math.abs(vx);
        }
    }

    /**
     * Reinicia el balon en una posicion determinada
     * y detiene su movimiento.
     *
     * @param x nueva posicion horizontal.
     * @param y nueva posicion vertical.
     */
    public void reiniciar(int x, int y)
    {
        this.x = x;
        this.y = y;
        vx = 0;
        vy = 0;
    }

    /**
     * Detiene completamente el movimiento del balon.
     */
    public void detener()
    {
        vx = 0;
        vy = 0;
    }
}