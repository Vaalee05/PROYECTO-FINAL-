package juego;



/**
 * Representa la configuración de una partida.
 * Permite establecer si el partido se juega por tiempo
 * o por una cantidad determinada de goles.
 */
public class ConfiguracionPartido
{
    private String modalidad;
    private int tiempoLimite;
    private int golesParaGanar;

    /**
     * Construye una configuración para una partida.
     *
     * @param modalidad modalidad del partido: "TIEMPO" o "GOLES".
     * @param tiempoLimite duración del partido en segundos.
     * @param golesParaGanar cantidad de goles necesarios para ganar.
     */
    public ConfiguracionPartido(String modalidad, int tiempoLimite,
                                int golesParaGanar)
    {
        if (modalidad == null ||
            (!modalidad.equals("TIEMPO") && !modalidad.equals("GOLES"))) {
            throw new IllegalArgumentException("Modalidad no válida.");
        }

        if (tiempoLimite <= 0 || golesParaGanar <= 0) {
            throw new IllegalArgumentException("Los valores deben ser positivos.");
        }

        this.modalidad = modalidad;
        this.tiempoLimite = tiempoLimite;
        this.golesParaGanar = golesParaGanar;
    }

    /**
     * Obtiene la modalidad del partido.
     *
     * @return modalidad seleccionada.
     */
    public String getModalidad()
    {
        return modalidad;
    }

    /**
     * Obtiene el tiempo límite del partido.
     *
     * @return tiempo en segundos.
     */
    public int getTiempoLimite()
    {
        return tiempoLimite;
    }

    /**
     * Obtiene la cantidad de goles necesarios para ganar.
     *
     * @return cantidad de goles.
     */
    public int getGolesParaGanar()
    {
        return golesParaGanar;
    }

    /**
     * Indica si el partido se juega por tiempo.
     *
     * @return true si la modalidad es por tiempo.
     */
    public boolean esPorTiempo()
    {
        return modalidad.equals("TIEMPO");
    }

    /**
     * Indica si el partido se juega por goles.
     *
     * @return true si la modalidad es por goles.
     */
    public boolean esPorGoles()
    {
        return modalidad.equals("GOLES");
    }
}
