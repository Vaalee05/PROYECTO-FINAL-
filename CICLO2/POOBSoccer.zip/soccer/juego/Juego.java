package juego;





/**
 * Representa y coordina el desarrollo de un partido
 * del videojuego DOPOSoccer.
 *
 * Administra los jugadores, el balon, la cancha,
 * el marcador y el estado de la partida.
 *
 * Diccionario de atributos:
 * jugador1: primer jugador del partido.
 * jugador2: segundo jugador del partido.
 * balon: balon utilizado durante el partido.
 * cancha: terreno donde se desarrolla el partido.
 * marcador: resultado actual del partido.
 * partidoActivo: indica si el partido esta activo.
 * golesParaGanar: cantidad de goles necesarios para ganar.
 */
public class Juego
{
    private Jugador jugador1;
    private Jugador jugador2;
    private Balon balon;
    private Cancha cancha;
    private Marcador marcador;
    private boolean partidoActivo;
    private int golesParaGanar;
    private Patada patada;
    private Poder poderJugador1;
    private Poder poderJugador2;
    private AdministradorEfectos efectosJugador1;
    private AdministradorEfectos efectosJugador2;
    private Proyectil proyectilJugador1;
    private Proyectil proyectilJugador2;  
    private ConfiguracionPartido configuracion;
    private double tiempoTranscurrido;
    private boolean muerteSubita;


    /**
     * Construye un partido con dos jugadores y una cancha.
     *
     * @param jugador1 primer jugador.
     * @param jugador2 segundo jugador.
     * @param cancha terreno de juego.
     * @throws IllegalArgumentException si algun dato es invalido.
     */
    public Juego(Jugador jugador1, Jugador jugador2, Cancha cancha)
    {
        if (jugador1 == null || jugador2 == null || cancha == null
            || jugador1 == jugador2) {
            throw new IllegalArgumentException(
                "Los jugadores y la cancha deben ser validos."
            );
        }

        this.jugador1 = jugador1;
        this.jugador2 = jugador2;
        this.cancha = cancha;
        // Ubicar los jugadores en lados opuestos de la cancha.
        jugador1.establecerPosicion(
            cancha.getAncho() / 4,
            cancha.getAlto() / 2
        );
        
        jugador2.establecerPosicion(
            (cancha.getAncho() * 3) / 4,
            cancha.getAlto() / 2
        );

        balon = new Balon(
            cancha.getAncho() / 2,
            cancha.getAlto() / 2,
            15
        );

        marcador = new Marcador();
        partidoActivo = false;
        golesParaGanar = 5;
        patada = new Patada();
        // Obtener los poderes de los personajes seleccionados.
        poderJugador1 = jugador1.getPersonaje().getPoder();
        poderJugador2 = jugador2.getPersonaje().getPoder();
        
        // Crear un administrador de efectos para cada jugador.
        efectosJugador1 = new AdministradorEfectos(jugador1);
        efectosJugador2 = new AdministradorEfectos(jugador2);
    }

    public Jugador getJugador1()
    {
        return jugador1;
    }

    public Jugador getJugador2()
    {
        return jugador2;
    }

    public Balon getBalon()
    {
        return balon;
    }

    public Cancha getCancha()
    {
        return cancha;
    }

    public Marcador getMarcador()
    {
        return marcador;
    }

    public boolean isPartidoActivo()
    {
        return partidoActivo;
    }

    public int getGolesParaGanar()
    {
        return golesParaGanar;
    }

    /**
     * Configura la cantidad de goles necesarios para ganar.
     *
     * @param cantidad cantidad de goles.
     */
    public void setGolesParaGanar(int cantidad)
    {
        if (cantidad <= 0) {
            throw new IllegalArgumentException(
                "La cantidad de goles debe ser positiva."
            );
        }

        if (partidoActivo) {
            throw new IllegalStateException(
                "No se puede cambiar durante un partido."
            );
        }

        golesParaGanar = cantidad;
    }

    /**
     * Inicia el partido y reinicia el control del tiempo.
     */
    public void iniciarPartido()
    {
        if (partidoActivo) {
            return;
        }
    
        if (configuracion != null) {
            tiempoTranscurrido = 0;
            muerteSubita = false;
        }
    
        if (!haTerminado()) {
            partidoActivo = true;
        }
    }

    /**
     * Finaliza el partido.
     */
    public void finalizarPartido()
    {
        partidoActivo = false;
        balon.detener();
    }

    /**
     * Actualiza el estado general del partido.
     */
    public void actualizar()
    {
        if (!partidoActivo) {
            return;
        }
    
        balon.actualizar(cancha);
    
        jugador1.actualizarSalto(cancha.getAlto());
        jugador2.actualizarSalto(cancha.getAlto());
    
        actualizarProyectiles();
    
        actualizarEfectos(0.016);
    
        detectarGol();
    }
    
    /**
     * Actualiza los proyectiles y comprueba sus impactos.
     */
    private void actualizarProyectiles()
    {
        if (proyectilJugador1 != null
            && proyectilJugador1.isActivo()) {
    
            proyectilJugador1.actualizar();
    
            if (proyectilJugador1.impactar(efectosJugador2)) {
                proyectilJugador1 = null;
            }
            else if (!cancha.estaDentroHorizontal(
                proyectilJugador1.getX())) {
                proyectilJugador1.desactivar();
                proyectilJugador1 = null;
            }
        }
    
        if (proyectilJugador2 != null
            && proyectilJugador2.isActivo()) {
    
            proyectilJugador2.actualizar();
    
            if (proyectilJugador2.impactar(efectosJugador1)) {
                proyectilJugador2 = null;
            }
            else if (!cancha.estaDentroHorizontal(
                proyectilJugador2.getX())) {
                proyectilJugador2.desactivar();
                proyectilJugador2 = null;
            }
        }
    }

    /**
     * Detecta si el balon ha atravesado alguna porteria.
     *
     * Si sale por la izquierda, anota el jugador 2.
     * Si sale por la derecha, anota el jugador 1.
     */
    private void detectarGol()
    {
        if (!cancha.estaEnZonaPorteria(balon.getY())) {
            return;
        }

        if (balon.getX() + balon.getRadio() < 0) {
            anotarGolJugador2();
        }
        else if (balon.getX() - balon.getRadio()
            > cancha.getAncho()) {
            anotarGolJugador1();
        }
    }

    /**
     * Registra un gol para el primer jugador.
     */
    public void anotarGolJugador1()
    {
        if (!partidoActivo) {
            return;
        }

        marcador.anotarGolJugador1();
        reiniciarBalon();
        comprobarFinalPartido();
    }

    /**
     * Registra un gol para el segundo jugador.
     */
    public void anotarGolJugador2()
    {
        if (!partidoActivo) {
            return;
        }

        marcador.anotarGolJugador2();
        reiniciarBalon();
        comprobarFinalPartido();
    }

    /**
     * Reinicia el balon en el centro de la cancha.
     */
    private void reiniciarBalon()
    {
        balon.reiniciar(
            cancha.getAncho() / 2,
            cancha.getAlto() / 2
        );
    }

    /**
     * Comprueba si el partido ha terminado.
     *
     * @return true si existe un ganador y el partido terminó.
     */
    public boolean haTerminado()
    {
        if (configuracion == null || configuracion.esPorGoles()) {
            return marcador.getGolesJugador1() >= golesParaGanar
                || marcador.getGolesJugador2() >= golesParaGanar;
        }
    
        return !partidoActivo && !marcador.estaEmpatado();
    }

    /**
     * Comprueba si se debe finalizar el partido.
     */
    private void comprobarFinalPartido()
    {
        if (configuracion == null || configuracion.esPorGoles()) {
            if (haTerminado()) {
                finalizarPartido();
            }
        }
        else if (muerteSubita && !marcador.estaEmpatado()) {
            finalizarPartido();
        }
    }

    /**
     * Obtiene el ganador del partido.
     *
     * @return jugador ganador o null si no hay ganador.
     */
    public Jugador getGanador()
    {
        if (!haTerminado()) {
            return null;
        }

        if (marcador.getGolesJugador1()
            > marcador.getGolesJugador2()) {
            return jugador1;
        }

        if (marcador.getGolesJugador2()
            > marcador.getGolesJugador1()) {
            return jugador2;
        }

        return null;
    }
    
    /**
     * Ejecuta una patada del primer jugador hacia la derecha.
     *
     * @return true si la patada alcanza un objetivo.
     */
    public boolean patadaJugador1()
    {
        if (!partidoActivo) {
            return false;
        }
    
        return patada.ejecutar(
            jugador1, jugador2, balon, 1
        );
    }
    
    /**
     * Ejecuta una patada del segundo jugador hacia la izquierda.
     *
     * @return true si la patada alcanza un objetivo.
     */
    public boolean patadaJugador2()
    {
        if (!partidoActivo) {
            return false;
        }
    
        return patada.ejecutar(
            jugador2, jugador1, balon, -1
        );
    }
    
    
    /**
     * Mueve al primer jugador hacia la izquierda.
     */
    public void moverJugador1Izquierda()
    {
        if (partidoActivo) {
            jugador1.moverIzquierda();
            ajustarPosicion(jugador1);
        }
    }
    
    /**
     * Mueve al primer jugador hacia la derecha.
     */
    public void moverJugador1Derecha()
    {
        if (partidoActivo) {
            jugador1.moverDerecha();
            ajustarPosicion(jugador1);
        }
    }
    
    /**
     * Mueve al segundo jugador hacia la izquierda.
     */
    public void moverJugador2Izquierda()
    {
        if (partidoActivo) {
            jugador2.moverIzquierda();
            ajustarPosicion(jugador2);
        }
    }
    
    /**
     * Mueve al segundo jugador hacia la derecha.
     */
    public void moverJugador2Derecha()
    {
        if (partidoActivo) {
            jugador2.moverDerecha();
            ajustarPosicion(jugador2);
        }
    }
    
    /**
     * Mantiene al jugador dentro de los limites horizontales
     * de la cancha.
     *
     * @param jugador jugador cuya posicion se ajusta.
     */
    private void ajustarPosicion(Jugador jugador)
    {
        int nuevaX = jugador.getX();
    
        if (nuevaX < 0) {
            nuevaX = 0;
        }
    
        if (nuevaX > cancha.getAncho()) {
            nuevaX = cancha.getAncho();
        }
    
        jugador.establecerPosicion(nuevaX, jugador.getY());
    }
    
    /**
     * Aplica el poder del primer jugador sobre el segundo.
     *
     * Este metodo se utilizara cuando el proyectil especial
     * del primer jugador alcance al segundo.
     */
    public void impactarPoderJugador1()
    {
        if (!partidoActivo || poderJugador1 == null) {
            return;
        }
    
        poderJugador1.aplicar(
            jugador1,
            jugador2,
            efectosJugador2
        );
    }
    
    /**
     * Aplica el poder del segundo jugador sobre el primero.
     *
     * Este metodo se utilizara cuando el proyectil especial
     * del segundo jugador alcance al primero.
     */
    public void impactarPoderJugador2()
    {
        if (!partidoActivo || poderJugador2 == null) {
            return;
        }
    
        poderJugador2.aplicar(
            jugador2,
            jugador1,
            efectosJugador1
        );
    }
    
    /**
     * Actualiza la duracion de los efectos especiales.
     *
     * @param segundos tiempo transcurrido.
     */
    public void actualizarEfectos(double segundos)
    {
        if (!partidoActivo) {
            return;
        }
    
        efectosJugador1.actualizar(segundos);
        efectosJugador2.actualizar(segundos);
    }
    
    /**
     * Obtiene el administrador de efectos del primer jugador.
     *
     * @return administrador de efectos.
     */
    public AdministradorEfectos getEfectosJugador1()
    {
        return efectosJugador1;
    }
    
    /**
     * Obtiene el administrador de efectos del segundo jugador.
     *
     * @return administrador de efectos.
     */
    public AdministradorEfectos getEfectosJugador2()
    {
        return efectosJugador2;
    }

    /**
     * Permite que el primer jugador lance su poder especial.
     *
     * @return true si se pudo lanzar el proyectil.
     */
    public boolean lanzarPoderJugador1()
    {
        if (!partidoActivo || poderJugador1 == null
            || proyectilJugador1 != null
            || !jugador1.estaVivo()) {
            return false;
        }
    
        proyectilJugador1 = new Proyectil(
            jugador1, jugador2, poderJugador1, 12
        );
    
        return true;
    }
    
    /**
     * Permite que el segundo jugador lance su poder especial.
     *
     * @return true si se pudo lanzar el proyectil.
     */
    public boolean lanzarPoderJugador2()
    {
        if (!partidoActivo || poderJugador2 == null
            || proyectilJugador2 != null
            || !jugador2.estaVivo()) {
            return false;
        }
    
        proyectilJugador2 = new Proyectil(
            jugador2, jugador1, poderJugador2, 12
        );
    
        return true;
    }
    
    /**
     * Obtiene el proyectil del primer jugador.
     *
     * @return proyectil del jugador 1.
     */
    public Proyectil getProyectilJugador1()
    {
        return proyectilJugador1;
    }
    
    /**
     * Obtiene el proyectil del segundo jugador.
     *
     * @return proyectil del jugador 2.
     */
    public Proyectil getProyectilJugador2()
    {
        return proyectilJugador2;
    }
    
    /**
     * Establece la configuración de la partida.
     *
     * @param configuracion configuración del partido.
     */
    public void setConfiguracion(ConfiguracionPartido configuracion)
    {
        if (configuracion == null) {
            throw new IllegalArgumentException(
                "La configuración no puede ser nula."
            );
        }
    
        if (partidoActivo) {
            throw new IllegalStateException(
                "No se puede cambiar la configuración durante el partido."
            );
        }
    
        this.configuracion = configuracion;
        this.tiempoTranscurrido = 0;
        this.muerteSubita = false;
    
        if (configuracion.esPorGoles()) {
            this.golesParaGanar = configuracion.getGolesParaGanar();
        }
    }
    
    /**
     * Actualiza el tiempo transcurrido del partido.
     *
     * @param segundos tiempo transcurrido desde la actualización anterior.
     */
    public void actualizarTiempo(double segundos)
    {
        if (segundos < 0) {
            throw new IllegalArgumentException(
                "El tiempo no puede ser negativo."
            );
        }
    
        if (!partidoActivo || configuracion == null
            || !configuracion.esPorTiempo()) {
            return;
        }
    
        tiempoTranscurrido += segundos;
    
        if (tiempoTranscurrido >= configuracion.getTiempoLimite()) {
            if (marcador.estaEmpatado()) {
                muerteSubita = true;
            }
            else {
                finalizarPartido();
            }
        }
    }
    
    /**
     * Comprueba si el partido se encuentra en muerte súbita.
     *
     * @return true si el partido continúa después de un empate por tiempo.
     */
    public boolean estaEnMuerteSubita()
    {
        return muerteSubita;
    }
    
    /**
     * Obtiene el tiempo transcurrido del partido.
     *
     * @return tiempo transcurrido en segundos.
     */
    public double getTiempoTranscurrido()
    {
        return tiempoTranscurrido;
    }
    
    /**
     * Permite que el primer jugador salte.
     */
    public void saltarJugador1()
    {
        if (partidoActivo) {
            jugador1.saltar();
        }
    }
    
    /**
     * Permite que el segundo jugador salte.
     */
    public void saltarJugador2()
    {
        if (partidoActivo) {
            jugador2.saltar();
        }
    }
    
}