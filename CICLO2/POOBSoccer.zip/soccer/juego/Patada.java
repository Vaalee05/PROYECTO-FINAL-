package juego;




/**
 * Representa una patada normal dentro de DOPOSoccer.
 *
 * Permite atacar al rival o impulsar el balon,
 * dependiendo del objeto que se encuentre en el alcance.
 *
 * Diccionario de atributos:
 * ALCANCE: distancia maxima de la patada.
 * IMPULSO: fuerza aplicada al balon.
 * DANIO_BASE: daño inicial de una patada.
 */
public class Patada
{
    private static final int ALCANCE = 30;
    private static final int IMPULSO = 8;
    private static final int DANIO_BASE = 10;

    /**
     * Ejecuta una patada en la direccion indicada.
     *
     * Si el balon esta al alcance, lo impulsa.
     * De lo contrario, si el rival esta al alcance,
     * le aplica daño.
     *
     * @param atacante jugador que realiza la patada.
     * @param rival jugador contrario.
     * @param balon balon del partido.
     * @param direccion direccion del ataque: 1 derecha, -1 izquierda.
     * @return true si la patada alcanza un objetivo.
     */
    public boolean ejecutar(Jugador atacante, Jugador rival,
                            Balon balon, int direccion)
    {
        if (atacante == null || rival == null || balon == null) {
            throw new IllegalArgumentException(
                "Los participantes y el balon son obligatorios."
            );
        }

        if (direccion != 1 && direccion != -1) {
            throw new IllegalArgumentException(
                "La direccion debe ser 1 o -1."
            );
        }

        // Comprobar primero si la patada alcanza el balon.
        if (estaAlcance(atacante.getX(), atacante.getY(),
                       balon.getX(), balon.getY())) {

            balon.setVelocidad(IMPULSO * direccion, -2);
            return true;
        }

        // Comprobar si alcanza al jugador contrario.
        if (estaAlcance(atacante.getX(), atacante.getY(),
                       rival.getX(), rival.getY())) {

            double multiplicadorKick =
                    1 + 0.10 * (atacante.getEstadisticas().getKick() - 1);
                
            int dano = (int) Math.round(DANIO_BASE * multiplicadorKick);

            rival.recibirDanio(dano);
            return true;
        }

        return false;
    }

    /**
     * Comprueba si dos posiciones estan dentro del alcance.
     *
     * @param x1 posicion horizontal del atacante.
     * @param y1 posicion vertical del atacante.
     * @param x2 posicion horizontal del objetivo.
     * @param y2 posicion vertical del objetivo.
     * @return true si el objetivo esta al alcance.
     */
    private boolean estaAlcance(int x1, int y1, int x2, int y2)
    {
        int diferenciaX = x2 - x1;
        int diferenciaY = y2 - y1;

        return Math.sqrt(
            diferenciaX * diferenciaX + diferenciaY * diferenciaY
        ) <= ALCANCE;
    }
}
