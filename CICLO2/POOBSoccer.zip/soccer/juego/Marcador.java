package juego;




/**
 * Representa el marcador de un partido de DOPOSoccer.
 *
 * Almacena y actualiza los goles conseguidos por
 * cada jugador durante el partido.
 *
 * Diccionario de atributos:
 * golesJugador1: cantidad de goles del primer jugador.
 * golesJugador2: cantidad de goles del segundo jugador.
 */
public class Marcador
{
    private int golesJugador1;
    private int golesJugador2;

    /**
     * Construye un marcador con ambos jugadores
     * comenzando con cero goles.
     */
    public Marcador()
    {
        golesJugador1 = 0;
        golesJugador2 = 0;
    }

    /**
     * Obtiene los goles del primer jugador.
     *
     * @return cantidad de goles del jugador 1.
     */
    public int getGolesJugador1()
    {
        return golesJugador1;
    }

    /**
     * Obtiene los goles del segundo jugador.
     *
     * @return cantidad de goles del jugador 2.
     */
    public int getGolesJugador2()
    {
        return golesJugador2;
    }

    /**
     * Registra un gol para el primer jugador.
     */
    public void anotarGolJugador1()
    {
        golesJugador1++;
    }

    /**
     * Registra un gol para el segundo jugador.
     */
    public void anotarGolJugador2()
    {
        golesJugador2++;
    }

    /**
     * Comprueba si el marcador esta empatado.
     *
     * @return true si ambos jugadores tienen los mismos goles.
     */
    public boolean estaEmpatado()
    {
        return golesJugador1 == golesJugador2;
    }

    /**
     * Reinicia el marcador dejando ambos resultados en cero.
     */
    public void reiniciar()
    {
        golesJugador1 = 0;
        golesJugador2 = 0;
    }
}