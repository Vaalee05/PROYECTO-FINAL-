package juego;



/**
 * Representa un proyectil especial utilizado por los jugadores.
 *
 * Administra su posicion, velocidad, atacante y poder.
 * Cuando alcanza al jugador contrario, aplica el poder.
 *
 * Diccionario de atributos:
 * x: posicion horizontal del proyectil.
 * y: posicion vertical del proyectil.
 * vx: velocidad horizontal.
 * vy: velocidad vertical.
 * radio: radio del proyectil.
 * atacante: jugador que lanza el proyectil.
 * objetivo: jugador que recibe el impacto.
 * poder: habilidad especial utilizada.
 * activo: indica si el proyectil sigue en movimiento.
 */
public class Proyectil
{
    private int x;
    private int y;
    private int vx;
    private int vy;
    private int radio;

    private Jugador atacante;
    private Jugador objetivo;
    private Poder poder;
    private boolean activo;

    /**
     * Construye un proyectil especial.
     *
     * @param atacante jugador que lanza el proyectil.
     * @param objetivo jugador contrario.
     * @param poder habilidad especial utilizada.
     * @param velocidad velocidad horizontal.
     * @throws IllegalArgumentException si algun dato es invalido.
     */
    public Proyectil(Jugador atacante, Jugador objetivo,
                     Poder poder, int velocidad)
    {
        if (atacante == null || objetivo == null || poder == null
            || atacante == objetivo || velocidad <= 0) {
            throw new IllegalArgumentException(
                "Los datos del proyectil no son validos."
            );
        }

        this.atacante = atacante;
        this.objetivo = objetivo;
        this.poder = poder;

        x = atacante.getX();
        y = atacante.getY();
        radio = 10;

        vx = atacante.getX() < objetivo.getX()
            ? velocidad : -velocidad;

        vy = 0;
        activo = true;
    }

    /**
     * Obtiene la posicion horizontal.
     *
     * @return coordenada horizontal.
     */
    public int getX()
    {
        return x;
    }

    /**
     * Obtiene la posicion vertical.
     *
     * @return coordenada vertical.
     */
    public int getY()
    {
        return y;
    }

    /**
     * Indica si el proyectil sigue activo.
     *
     * @return true si esta activo.
     */
    public boolean isActivo()
    {
        return activo;
    }

    /**
     * Actualiza la posicion del proyectil.
     */
    public void actualizar()
    {
        if (activo) {
            x += vx;
            y += vy;
        }
    }

    /**
     * Comprueba si el proyectil alcanza al objetivo.
     *
     * @return true si existe impacto.
     */
    public boolean comprobarImpacto()
    {
        if (!activo) {
            return false;
        }

        int diferenciaX = objetivo.getX() - x;
        int diferenciaY = objetivo.getY() - y;

        double distancia = Math.sqrt(
            diferenciaX * diferenciaX
            + diferenciaY * diferenciaY
        );

        if (distancia <= radio + 15) {
            return true;
        }

        return false;
    }

    /**
     * Aplica el poder cuando el proyectil alcanza al objetivo.
     *
     * @param administrador administrador de efectos del objetivo.
     * @return true si se produjo el impacto.
     */
    public boolean impactar(AdministradorEfectos administrador)
    {
        if (administrador == null) {
            throw new IllegalArgumentException(
                "El administrador no puede ser null."
            );
        }

        if (!comprobarImpacto()) {
            return false;
        }

        poder.aplicar(atacante, objetivo, administrador);
        activo = false;

        return true;
    }

    /**
     * Desactiva el proyectil.
     */
    public void desactivar()
    {
        activo = false;
    }
}
