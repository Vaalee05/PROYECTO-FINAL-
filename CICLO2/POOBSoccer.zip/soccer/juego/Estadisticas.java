package juego;


/**
 * Representa las estadisticas y habilidades de un jugador
 * dentro del videojuego DOPOSoccer.
 *
 * Cada habilidad comienza en 1 y puede mejorarse
 * hasta alcanzar un valor maximo de 10.
 *
 * Diccionario de atributos:
 * speed: velocidad de movimiento del jugador.
 * kick: potencia de las patadas.
 * jump: capacidad de salto.
 * survival: resistencia del jugador.
 * MAXIMO: valor maximo permitido para cada habilidad.
 * MINIMO: valor minimo permitido para cada habilidad.
 */
public class Estadisticas
{
    private static final int MAXIMO = 10;
    private static final int MINIMO = 1;

    private int speed;
    private int kick;
    private int jump;
    private int survival;

    /**
     * Construye las estadisticas iniciales del jugador.
     * Todas las habilidades comienzan con un valor de 1.
     */
    public Estadisticas()
    {
        speed = MINIMO;
        kick = MINIMO;
        jump = MINIMO;
        survival = MINIMO;
    }

    /**
     * Consulta la velocidad del jugador.
     *
     * @return valor actual de velocidad.
     */
    public int getSpeed()
    {
        return speed;
    }

    /**
     * Consulta la potencia de patada del jugador.
     *
     * @return valor actual de patada.
     */
    public int getKick()
    {
        return kick;
    }

    /**
     * Consulta la capacidad de salto del jugador.
     *
     * @return valor actual de salto.
     */
    public int getJump()
    {
        return jump;
    }

    /**
     * Consulta la resistencia del jugador.
     *
     * @return valor actual de resistencia.
     */
    public int getSurvival()
    {
        return survival;
    }

    /**
     * Aumenta en un punto la velocidad si no ha alcanzado
     * el valor maximo permitido.
     *
     * @return true si la mejora se realizo, false si
     * ya alcanzo el limite.
     */
    public boolean mejorarSpeed()
    {
        if (speed < MAXIMO) {
            speed++;
            return true;
        }
        return false;
    }

    /**
     * Aumenta en un punto la potencia de patada.
     *
     * @return true si la mejora se realizo, false si
     * ya alcanzo el limite.
     */
    public boolean mejorarKick()
    {
        if (kick < MAXIMO) {
            kick++;
            return true;
        }
        return false;
    }

    /**
     * Aumenta en un punto la capacidad de salto.
     *
     * @return true si la mejora se realizo, false si
     * ya alcanzo el limite.
     */
    public boolean mejorarJump()
    {
        if (jump < MAXIMO) {
            jump++;
            return true;
        }
        return false;
    }

    /**
     * Aumenta en un punto la resistencia del jugador.
     *
     * @return true si la mejora se realizo, false si
     * ya alcanzo el limite.
     */
    public boolean mejorarSurvival()
    {
        if (survival < MAXIMO) {
            survival++;
            return true;
        }
        return false;
    }
}

