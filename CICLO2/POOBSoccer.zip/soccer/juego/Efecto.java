package juego;



/**
 * Define el comportamiento general de los efectos
 * especiales que pueden recibir los jugadores.
 *
 * Cada efecto debe implementar su activacion,
 * finalizacion y duracion.
 */
public interface Efecto
{
    /**
     * Activa el efecto sobre un jugador.
     *
     * @param objetivo jugador que recibe el efecto.
     */
    void iniciar(Jugador objetivo);

    /**
     * Finaliza el efecto aplicado al jugador.
     *
     * @param objetivo jugador al que se le retira el efecto.
     */
    void finalizar(Jugador objetivo);

    /**
     * Retorna la duracion del efecto en segundos.
     *
     * @return duracion del efecto.
     */
    double getDuracion();
}
