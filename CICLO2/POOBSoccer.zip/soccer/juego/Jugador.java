package juego;




/**
 * Representa a un jugador que participa en una partida
 * del videojuego DOPOSoccer.
 *
 * Administra la posicion, el movimiento, la vida,
 * las estadisticas y los estados especiales del jugador.
 *
 * Diccionario de atributos:
 * nombre: nombre que identifica al jugador.
 * x: posicion horizontal del jugador.
 * y: posicion vertical del jugador.
 * vidaActual: cantidad de vida actual.
 * vidaMaxima: cantidad maxima de vida.
 * saltando: indica si el jugador esta saltando.
 * aturdido: indica si el jugador esta aturdido.
 * personaje: personaje seleccionado.
 * estadisticas: habilidades del jugador.
 * electrocutado: indica si esta electrocutado.
 * inconsciente: indica si esta inconsciente.
 * confundido: indica si esta confundido.
 * empujado: indica si esta siendo empujado.
 * tiempoAturdido: tiempo transcurrido del aturdimiento.
 * VIDA_INICIAL: vida base del jugador.
 * DURACION_ATURDIMIENTO: duracion del aturdimiento.
 */
public class Jugador
{
    private static final int VIDA_INICIAL = 100;
    private static final double DURACION_ATURDIMIENTO = 3.0;

    private String nombre;
    private int x;
    private int y;
    private int vidaActual;
    private int vidaMaxima;
    private boolean saltando;
    private boolean aturdido;
    private Personaje personaje;
    private Estadisticas estadisticas;

    private boolean electrocutado;
    private boolean inconsciente;
    private boolean confundido;
    private boolean empujado;

    private double tiempoAturdido;
    private int velocidadSalto;

    /**
     * Construye un jugador con su nombre, personaje
     * y estadisticas.
     *
     * La vida maxima depende de la estadistica Survival.
     *
     * @param nombre nombre del jugador.
     * @param personaje personaje seleccionado.
     * @param estadisticas habilidades del jugador.
     * @throws IllegalArgumentException si algun dato es invalido.
     */
    public Jugador(String nombre, Personaje personaje,
                   Estadisticas estadisticas)
    {
        if (nombre == null || nombre.trim().isEmpty()
            || personaje == null || estadisticas == null) {
            throw new IllegalArgumentException(
                "Los datos del jugador no son validos."
            );
        }

        this.nombre = nombre;
        this.personaje = personaje;
        this.estadisticas = estadisticas;

        x = 0;
        y = 0;
        vidaMaxima = VIDA_INICIAL
            + 10 * (estadisticas.getSurvival() - 1);
        vidaActual = vidaMaxima;

        saltando = false;
        aturdido = false;
        electrocutado = false;
        inconsciente = false;
        confundido = false;
        empujado = false;
        tiempoAturdido = 0;
        velocidadSalto = 0;
    }

    /**
     * Obtiene el nombre del jugador.
     *
     * @return nombre del jugador.
     */
    public String getNombre()
    {
        return nombre;
    }

    /**
     * Obtiene la posicion horizontal.
     *
     * @return coordenada horizontal.
     */
    public int getX()
    {
        return x;
    }

    /**
     * Obtiene la posicion vertical.
     *
     * @return coordenada vertical.
     */
    public int getY()
    {
        return y;
    }

    /**
     * Obtiene la vida actual.
     *
     * @return vida disponible.
     */
    public int getVidaActual()
    {
        return vidaActual;
    }

    /**
     * Obtiene la vida maxima.
     *
     * @return vida maxima.
     */
    public int getVidaMaxima()
    {
        return vidaMaxima;
    }

    /**
     * Obtiene el personaje seleccionado.
     *
     * @return personaje del jugador.
     */
    public Personaje getPersonaje()
    {
        return personaje;
    }

    /**
     * Obtiene las estadisticas del jugador.
     *
     * @return estadisticas actuales.
     */
    public Estadisticas getEstadisticas()
    {
        return estadisticas;
    }

    /**
     * Indica si el jugador esta saltando.
     *
     * @return true si esta saltando.
     */
    public boolean estaSaltando()
    {
        return saltando;
    }

    /**
     * Indica si el jugador esta aturdido.
     *
     * @return true si esta aturdido.
     */
    public boolean estaAturdido()
    {
        return aturdido;
    }

    /**
     * Mueve al jugador hacia la izquierda.
     *
     * Durante la electrocucion su velocidad se reduce
     * al 50 por ciento.
     */
    public void moverIzquierda()
    {
        if (puedeActuar()) {
            x -= obtenerVelocidadMovimiento();
        }
    }

    /**
     * Mueve al jugador hacia la derecha.
     *
     * Durante la electrocucion su velocidad se reduce
     * al 50 por ciento.
     */
    public void moverDerecha()
    {
        if (puedeActuar()) {
            x += obtenerVelocidadMovimiento();
        }
    }

    /**
     * Calcula la velocidad de desplazamiento actual.
     *
     * @return velocidad normal o reducida.
     */
    private int obtenerVelocidadMovimiento()
    {
        int velocidad = estadisticas.getSpeed();

        if (electrocutado) {
            return Math.max(1, (int) Math.ceil(velocidad * 0.5));
        }

        return velocidad;
    }

    /**
     * Inicia el salto si el jugador puede realizarlo.
     *
     * El jugador no puede saltar si esta electrocutado.
     */
    public void saltar()
    {
        if (puedeActuar() && !saltando && !electrocutado) {
            saltando = true;
            velocidadSalto = -12;
        }
    }

    /**
     * Finaliza el salto del jugador.
     */
    public void aterrizar()
    {
        saltando = false;
    }

    /**
     * Aplica daño al jugador.
     *
     * Cuando la vida llega a cero comienza el aturdimiento.
     *
     * @param dano cantidad de daño recibido.
     */
    public void recibirDanio(int dano)
    {
        if (dano <= 0 || aturdido || vidaActual <= 0) {
            return;
        }

        vidaActual = Math.max(0, vidaActual - dano);

        if (vidaActual == 0) {
            setAturdido(true);
        }
    }

    /**
     * Recupera vida sin superar la vida maxima.
     *
     * @param cantidad cantidad de vida que se recupera.
     */
    public void recuperarVida(int cantidad)
    {
        if (cantidad <= 0 || aturdido || vidaActual <= 0) {
            return;
        }

        vidaActual = Math.min(vidaMaxima, vidaActual + cantidad);
    }

    /**
     * Establece el estado de aturdimiento.
     *
     * @param aturdido true para activar el aturdimiento.
     */
    public void setAturdido(boolean aturdido)
    {
        this.aturdido = aturdido;
        tiempoAturdido = 0;

        if (aturdido) {
            vidaActual = 0;
            saltando = false;
        }
    }

    /**
     * Actualiza el tiempo del aturdimiento.
     *
     * Al completar tres segundos, el jugador recupera
     * su vida maxima y puede volver a actuar.
     *
     * @param segundos tiempo transcurrido.
     * @throws IllegalArgumentException si el tiempo es negativo.
     */
    public void actualizarAturdimiento(double segundos)
    {
        if (segundos < 0) {
            throw new IllegalArgumentException(
                "El tiempo no puede ser negativo."
            );
        }

        if (!aturdido) {
            return;
        }

        tiempoAturdido += segundos;

        if (tiempoAturdido >= DURACION_ATURDIMIENTO) {
            aturdido = false;
            tiempoAturdido = 0;
            vidaActual = vidaMaxima;
        }
    }

    /**
     * Indica si el jugador tiene vida disponible.
     *
     * @return true si tiene vida.
     */
    public boolean estaVivo()
    {
        return vidaActual > 0;
    }

    /**
     * Comprueba si puede realizar acciones.
     *
     * @return true si esta vivo y no esta incapacitado.
     */
    private boolean puedeActuar()
    {
        return estaVivo() && !aturdido && !inconsciente;
    }

    /**
     * Establece el estado de electrocucion.
     *
     * @param electrocutado estado del efecto.
     */
    public void setElectrocutado(boolean electrocutado)
    {
        this.electrocutado = electrocutado;
    }

    /**
     * Indica si esta electrocutado.
     *
     * @return true si esta electrocutado.
     */
    public boolean isElectrocutado()
    {
        return electrocutado;
    }

    /**
     * Establece el estado de inconsciencia.
     *
     * @param inconsciente estado del efecto.
     */
    public void setInconsciente(boolean inconsciente)
    {
        this.inconsciente = inconsciente;

        if (inconsciente) {
            saltando = false;
        }
    }

    /**
     * Indica si esta inconsciente.
     *
     * @return true si esta inconsciente.
     */
    public boolean isInconsciente()
    {
        return inconsciente;
    }

    /**
     * Establece el estado de confusion.
     *
     * @param confundido estado del efecto.
     */
    public void setConfundido(boolean confundido)
    {
        this.confundido = confundido;
    }

    /**
     * Indica si esta confundido.
     *
     * @return true si esta confundido.
     */
    public boolean isConfundido()
    {
        return confundido;
    }

    /**
     * Establece el estado de empuje.
     *
     * @param empujado estado del efecto.
     */
    public void setEmpujado(boolean empujado)
    {
        this.empujado = empujado;
    }

    /**
     * Indica si esta siendo empujado.
     *
     * @return true si esta empujado.
     */
    public boolean isEmpujado()
    {
        return empujado;
    }
    
    /**
     * Establece la posicion del jugador en la cancha.
     *
     * @param x coordenada horizontal.
     * @param y coordenada vertical.
     */
    public void establecerPosicion(int x, int y)
    {
        this.x = x;
        this.y = y;
    }
    
    
    /**
     * Actualiza el movimiento vertical del jugador.
     *
     * @param altoCancha altura maxima de la cancha.
     */
    public void actualizarSalto(int altoCancha)
    {
        if (!saltando) {
            return;
        }
    
        y += velocidadSalto;
        velocidadSalto += 1;
    
        if (y >= altoCancha / 2) {
            y = altoCancha / 2;
            aterrizar();
        }
    }
    
    /**
     * Obtiene la velocidad vertical del salto.
     *
     * @return velocidad vertical actual.
     */
    public int getVelocidadSalto()
    {
        return velocidadSalto;
    }

    
}

